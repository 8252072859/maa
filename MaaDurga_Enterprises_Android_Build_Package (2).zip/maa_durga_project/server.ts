import express, { Request, Response } from 'express';
import crypto from 'crypto';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// ADMIN RESTRICTION
const ADMIN_MOBILE_RAW = "8252072859";
const ADMIN_MOBILE_FULL = "+918252072859";

interface OtpRecord {
  phone: string;
  hashedOtp: string;
  salt: string;
  expiresAt: number; // timestamp
  attempts: number;
  lastRequestedAt: number;
  channel: 'whatsapp' | 'sms';
}

interface AdminSession {
  token: string;
  phone: string;
  role: 'admin';
  createdAt: number;
  expiresAt: number;
}

// In-memory server-side secure store
const otpStore = new Map<string, OtpRecord>();
const sessionStore = new Map<string, AdminSession>();
const requestHistory = new Map<string, number[]>(); // rate limit timestamps

// Helper to normalize phone
function normalizePhone(input: string): string {
  const cleaned = input.replace(/[^0-9+]/g, '');
  if (cleaned.startsWith('+91') && cleaned.length === 13) {
    return cleaned;
  }
  if (cleaned.startsWith('91') && cleaned.length === 12) {
    return `+${cleaned}`;
  }
  if (cleaned.length === 10) {
    return `+91${cleaned}`;
  }
  return cleaned;
}

// Hash OTP with salt using SHA-256
function hashOtp(otp: string, salt: string): string {
  return crypto.createHmac('sha256', salt).update(otp).digest('hex');
}

export interface SimulatedWhatsAppMessage {
  id: string;
  recipient: string;
  senderName: string;
  otp: string;
  body: string;
  status: 'sent' | 'delivered' | 'read';
  provider: string;
  timestamp: number;
  timeFormatted: string;
  whatsappUrl: string;
  webhookDispatched: boolean;
  webhookResult?: {
    url?: string;
    status?: number;
    responseSnippet?: string;
    error?: string;
  };
}

interface WebhookConfig {
  webhookUrl: string;
  webhookSecret: string;
  twilioSid: string;
  twilioToken: string;
  twilioFrom: string;
  metaToken: string;
  metaPhoneId: string;
}

const activeWebhookConfig: WebhookConfig = {
  webhookUrl: process.env.WHATSAPP_WEBHOOK_URL || '',
  webhookSecret: process.env.WHATSAPP_WEBHOOK_SECRET || '',
  twilioSid: process.env.TWILIO_ACCOUNT_SID || '',
  twilioToken: process.env.TWILIO_AUTH_TOKEN || '',
  twilioFrom: process.env.TWILIO_WHATSAPP_NUMBER || '',
  metaToken: process.env.WHATSAPP_API_TOKEN || '',
  metaPhoneId: process.env.WHATSAPP_PHONE_ID || ''
};

// In-Memory Simulated WhatsApp Inbox for real-time frontend simulation
const simulatedWhatsAppInbox: SimulatedWhatsAppMessage[] = [];

// Enhanced WhatsApp OTP Dispatch with External Webhook, Twilio API, and Simulated Gateway
async function sendWhatsAppOtp(phone: string, otp: string): Promise<{ 
  success: boolean; 
  provider: string; 
  message: string; 
  whatsappUrl: string; 
  simulatedMessage?: SimulatedWhatsAppMessage;
  webhookDispatched: boolean;
  webhookResult?: any;
}> {
  const cleanNumber = phone.replace('+', '');
  const messageText = `🔱 *MAA DURGA ENTERPRISES*\n*ADMIN LOGIN VERIFICATION OTP*\n\nYour 6-Digit Admin Security OTP is: *${otp}*\n\n⏰ Valid for: 5 Minutes\n🔒 Do not share this verification code with anyone.\n📱 Mobile Showroom ERP Access`;
  const whatsappUrl = `https://api.whatsapp.com/send?phone=${cleanNumber}&text=${encodeURIComponent(messageText)}`;

  let providerName = 'No real WhatsApp provider configured';
  let delivered = false;
  let webhookDispatched = false;
  let webhookResult: any = null;

  // 1. External Generic Webhook Integration (e.g. Zapier, Make, n8n, Custom WhatsApp Gateway)
  if (activeWebhookConfig.webhookUrl) {
    try {
      const webhookPayload = {
        event: 'whatsapp.otp_sent',
        recipient: phone,
        cleanRecipient: cleanNumber,
        otp: otp,
        code: otp,
        message: messageText,
        timestamp: Date.now(),
        sender: 'MAA DURGA ENTERPRISES',
        channel: 'whatsapp'
      };

      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'X-ERP-App': 'MaaDurgaEnterprises',
        'User-Agent': 'MaaDurgaERP-WhatsAppService/1.0'
      };

      if (activeWebhookConfig.webhookSecret) {
        const signature = crypto.createHmac('sha256', activeWebhookConfig.webhookSecret)
          .update(JSON.stringify(webhookPayload))
          .digest('hex');
        headers['X-WhatsApp-Signature'] = `sha256=${signature}`;
      }

      console.log(`📡 [DISPATCHING EXTERNAL WHATSAPP WEBHOOK] -> ${activeWebhookConfig.webhookUrl}`);
      const response = await fetch(activeWebhookConfig.webhookUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(webhookPayload)
      });

      const responseText = await response.text();
      webhookDispatched = true;
      webhookResult = {
        url: activeWebhookConfig.webhookUrl,
        status: response.status,
        responseSnippet: responseText.slice(0, 150)
      };

      if (response.ok) {
        providerName = 'External WhatsApp Webhook';
        delivered = true;
        console.log(`✅ Webhook accepted successfully with status ${response.status}`);
      } else {
        console.warn(`⚠️ Webhook responded with status ${response.status}: ${responseText.slice(0, 100)}`);
      }
    } catch (err: any) {
      console.error('❌ External Webhook network error:', err);
      webhookResult = {
        url: activeWebhookConfig.webhookUrl,
        error: err.message || 'Webhook network failure'
      };
    }
  }

  // 2. Twilio WhatsApp API Integration
  if (activeWebhookConfig.twilioSid && activeWebhookConfig.twilioToken && activeWebhookConfig.twilioFrom) {
    try {
      const auth = Buffer.from(`${activeWebhookConfig.twilioSid}:${activeWebhookConfig.twilioToken}`).toString('base64');
      const body = new URLSearchParams({
        To: `whatsapp:${phone}`,
        From: activeWebhookConfig.twilioFrom,
        Body: messageText
      });

      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${activeWebhookConfig.twilioSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: body.toString()
      });

      if (response.ok) {
        providerName = 'Twilio WhatsApp API';
        delivered = true;
        console.log(`✅ Twilio WhatsApp message dispatched to ${phone}`);
      } else {
        const errText = await response.text();
        console.error('Twilio WhatsApp error:', errText);
      }
    } catch (err) {
      console.error('Twilio WhatsApp network error:', err);
    }
  }

  // 3. Meta WhatsApp Cloud API Integration
  if (activeWebhookConfig.metaToken && activeWebhookConfig.metaPhoneId) {
    try {
      const response = await fetch(`https://graph.facebook.com/v19.0/${activeWebhookConfig.metaPhoneId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${activeWebhookConfig.metaToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: cleanNumber,
          type: 'text',
          text: { body: messageText }
        })
      });
      if (response.ok) {
        providerName = 'Meta WhatsApp Cloud API';
        delivered = true;
      }
    } catch (err) {
      console.error('WhatsApp Cloud API error:', err);
    }
  }

  // 4. Record to Simulated WhatsApp Inbox
  const simMsg: SimulatedWhatsAppMessage = {
    id: `wa_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    recipient: phone,
    senderName: 'Maa Durga Security 🛡️',
    otp,
    body: messageText,
    status: 'delivered',
    provider: providerName,
    timestamp: Date.now(),
    timeFormatted: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }),
    whatsappUrl,
    webhookDispatched,
    webhookResult
  };

  if (delivered) {
    simulatedWhatsAppInbox.unshift(simMsg);
    if (simulatedWhatsAppInbox.length > 25) simulatedWhatsAppInbox.pop();
  }

  console.log(`\n======================================================`);
  console.log(`📲 [MAA DURGA ENTERPRISES WHATSAPP OTP DISPATCH]`);
  console.log(`📱 Target Mobile: ${phone}`);
  console.log(`🏢 Provider: ${providerName}`);
  if (webhookDispatched) {
    console.log(`📡 Webhook Status: ${webhookResult?.status || 'dispatched'}`);
  }
  console.log(`⏳ Valid For: 5 Minutes (Expires at: ${new Date(Date.now() + 5 * 60 * 1000).toLocaleTimeString()})`);
  console.log(`======================================================\n`);

  return {
    success: delivered,
    provider: providerName,
    message: delivered ? `WhatsApp OTP submitted to ${providerName}.` : 'No real WhatsApp delivery provider is configured. Configure a WhatsApp API or secure webhook before using OTP login.',
    whatsappUrl,
    webhookDispatched,
    webhookResult
  };
}

// SMS Fallback Dispatch Function
async function sendSmsOtp(phone: string, otp: string): Promise<{ success: boolean; provider: string; message: string }> {
  const cleanNumber = phone.replace('+91', '');

  // Check Fast2SMS
  const fast2smsKey = process.env.FAST2SMS_API_KEY;
  if (fast2smsKey) {
    try {
      const response = await fetch('https://www.fast2sms.com/dev/bulkV2', {
        method: 'POST',
        headers: {
          'authorization': fast2smsKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          variables_values: otp,
          route: 'otp',
          numbers: cleanNumber
        })
      });
      const data = await response.json();
      if (data.return) {
        return { success: true, provider: 'Fast2SMS', message: 'SMS delivered to ' + phone };
      }
    } catch (err) {
      console.error('Fast2SMS network error:', err);
    }
  }

  return {
    success: false,
    provider: fast2smsKey ? 'Fast2SMS' : 'Not configured',
    message: 'Real SMS OTP could not be sent. Configure a valid Fast2SMS API key and approved OTP template.'
  };
}

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

// Route: Send OTP (WhatsApp or SMS)
app.post('/api/auth/send-otp', async (req: Request, res: Response) => {
  const { phone, channel = 'whatsapp' } = req.body;

  if (!phone) {
    return res.status(400).json({ error: 'Mobile number is required.' });
  }

  const normalized = normalizePhone(phone);

  // STRICT ADMIN AUTHORIZATION CHECK
  if (normalized !== ADMIN_MOBILE_FULL && normalized.replace('+91', '') !== ADMIN_MOBILE_RAW) {
    return res.status(403).json({
      error: 'Unauthorized Mobile Number. Access to MAA DURGA ENTERPRISES ERP is restricted exclusively to the Admin mobile number (+91 8252072859).'
    });
  }

  const now = Date.now();

  // Cooldown rate limiting (30 seconds between requests)
  const existing = otpStore.get(normalized);
  if (existing && now - existing.lastRequestedAt < 30000) {
    const waitSec = Math.ceil((30000 - (now - existing.lastRequestedAt)) / 1000);
    return res.status(429).json({
      error: `Please wait ${waitSec} seconds before requesting a new OTP.`
    });
  }

  // Hourly rate limit (Max 15 requests per hour)
  const history = requestHistory.get(normalized) || [];
  const recentHistory = history.filter(ts => now - ts < 3600000);
  if (recentHistory.length >= 15) {
    return res.status(429).json({
      error: 'Too many OTP requests. Please try again after 1 hour.'
    });
  }
  recentHistory.push(now);
  requestHistory.set(normalized, recentHistory);

  // Generate cryptographically secure 6-digit OTP
  const rawOtp = crypto.randomInt(100000, 999999).toString();
  const salt = crypto.randomBytes(16).toString('hex');
  const hashedOtp = hashOtp(rawOtp, salt);
  const expiresAt = now + 5 * 60 * 1000; // 5 minutes

  // Store hashed OTP
  otpStore.set(normalized, {
    phone: normalized,
    hashedOtp,
    salt,
    expiresAt,
    attempts: 0,
    lastRequestedAt: now,
    channel: channel === 'sms' ? 'sms' : 'whatsapp'
  });

  // Dispatch via chosen channel (default WhatsApp)
  if (channel === 'sms') {
    const result = await sendSmsOtp(normalized, rawOtp);
    if (!result.success) return res.status(503).json({ error: result.message });
    return res.json({
      success: true,
      channel: 'sms',
      message: result.message,
      expiresInSeconds: 300,
      resendCooldown: 30
    });
  } else {
    const result = await sendWhatsAppOtp(normalized, rawOtp);
    if (!result.success) return res.status(503).json({ error: result.message });
    return res.json({
      success: true,
      channel: 'whatsapp',
      message: result.message,
      whatsappUrl: result.whatsappUrl,
      expiresInSeconds: 300,
      resendCooldown: 30
    });
  }
});

// Route: Verify OTP
app.post('/api/auth/verify-otp', async (req: Request, res: Response) => {
  const { phone, otp } = req.body;

  if (!phone || !otp) {
    return res.status(400).json({ error: 'Phone and 6-digit OTP are required.' });
  }

  const normalized = normalizePhone(phone);

  if (normalized !== ADMIN_MOBILE_FULL && normalized.replace('+91', '') !== ADMIN_MOBILE_RAW) {
    return res.status(403).json({
      error: 'Unauthorized Mobile Number. Access to MAA DURGA ENTERPRISES ERP is restricted exclusively to the Admin mobile number (+91 8252072859).'
    });
  }

  const record = otpStore.get(normalized);
  if (!record) {
    return res.status(400).json({
      error: 'No active OTP request found. Please click "Send OTP on WhatsApp".'
    });
  }

  const now = Date.now();

  // Check Expiry (5 minutes)
  if (now > record.expiresAt) {
    otpStore.delete(normalized);
    return res.status(400).json({
      error: 'OTP has expired (validity is 5 minutes). Please request a new OTP on WhatsApp.'
    });
  }

  // Check Brute Force Attempt Limit (Max 5 attempts)
  if (record.attempts >= 5) {
    otpStore.delete(normalized);
    return res.status(429).json({
      error: 'Too many incorrect attempts. This OTP has been invalidated for security. Please request a fresh OTP on WhatsApp.'
    });
  }

  // Verify hash
  const testHash = hashOtp(otp.trim(), record.salt);
  if (testHash !== record.hashedOtp) {
    record.attempts += 1;
    otpStore.set(normalized, record);
    return res.status(400).json({
      error: `Invalid OTP entered. ${5 - record.attempts} attempts remaining.`
    });
  }

  // Successful verification - clear single-use OTP
  otpStore.delete(normalized);

  // Issue secure 64-char random session token
  const sessionToken = crypto.randomBytes(32).toString('hex');
  const sessionExpiry = now + 8 * 60 * 60 * 1000; // 8 hours session

  sessionStore.set(sessionToken, {
    token: sessionToken,
    phone: normalized,
    role: 'admin',
    createdAt: now,
    expiresAt: sessionExpiry
  });

  return res.json({
    success: true,
    message: 'WhatsApp OTP verified successfully. Admin session granted.',
    token: sessionToken,
    expiresAt: sessionExpiry,
    user: {
      phone: normalized,
      role: 'admin',
      shopName: 'MAA DURGA ENTERPRISES'
    }
  });
});

// Route: Validate Session
app.get('/api/auth/session', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ authenticated: false });
  }

  const token = authHeader.split(' ')[1];
  const session = sessionStore.get(token);

  if (!session || Date.now() > session.expiresAt) {
    if (session) sessionStore.delete(token);
    return res.status(401).json({ authenticated: false, error: 'Session expired' });
  }

  return res.json({
    authenticated: true,
    user: {
      phone: session.phone,
      role: session.role,
      shopName: 'MAA DURGA ENTERPRISES'
    }
  });
});

// Route: Logout
app.post('/api/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    sessionStore.delete(token);
  }
  return res.json({ success: true, message: 'Logged out successfully' });
});

// A real APK must be produced by the Android Gradle build workflow.
// Never serve the old placeholder ZIP as if it were an installable APK.
app.get(['/download-apk', '/MaaDurga_Enterprises.apk'], (_req: Request, res: Response) => {
  return res.status(404).json({ error: 'Android APK has not been built yet. Use the Android build workflow in .github/workflows/build-android.yml.' });
});

// ----------------------------------------------------
// VITE DEV SERVER OR PRODUCTION STATIC SERVING
// ----------------------------------------------------
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`🚀 Maa Durga Enterprises Server running on port ${PORT}`);
  });
}

startServer();
