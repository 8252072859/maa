console.error('This script cannot create a valid Android APK. Use the GitHub Actions workflow at .github/workflows/build-android.yml to build with the Android SDK and Gradle.');
process.exit(1);
