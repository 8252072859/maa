const fs = require('fs');
const zlib = require('zlib');
const path = require('path');

function createPng(width, height, isMaskable = false) {
  // RGBA buffer: 4 bytes per pixel + 1 filter byte per row
  const rowStride = 1 + width * 4;
  const rawData = Buffer.alloc(rowStride * height);

  const cx = width / 2;
  const cy = height / 2;
  const radius = isMaskable ? width * 0.38 : width * 0.44;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowStride;
    rawData[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Deep Black / Navy Background
      let r = 7, g = 11, b = 20, a = 255;

      // Outer gold circle/border
      if (Math.abs(dist - radius) <= width * 0.02) {
        // Gold border
        r = 245; g = 158; b = 11;
      } else if (dist < radius) {
        // Inner royal blue gradient
        const t = dist / radius;
        r = Math.round(15 + t * 10);
        g = Math.round(25 + t * 15);
        b = Math.round(50 + t * 40);

        // Trishul Center Column
        if (Math.abs(dx) <= width * 0.035 && dy >= -radius * 0.7 && dy <= radius * 0.6) {
          r = 251; g = 191; b = 36;
        }

        // Trishul prongs
        const prongDist = Math.sqrt(dx * dx + (dy + radius * 0.1) * (dy + radius * 0.1));
        if (Math.abs(prongDist - radius * 0.4) <= width * 0.03 && dy <= 0) {
          r = 251; g = 191; b = 36;
        }

        // Cross guard
        if (Math.abs(dy - radius * 0.2) <= width * 0.02 && Math.abs(dx) <= radius * 0.4) {
          r = 245; g = 158; b = 11;
        }
      }

      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR Chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // 8-bit depth
  ihdr[9] = 6; // RGBA color type
  ihdr[10] = 0; // Compression (deflate)
  ihdr[11] = 0; // Filter
  ihdr[12] = 0; // Interlace
  const ihdrChunk = makeChunk('IHDR', ihdr);

  // IDAT Chunk
  const compressed = zlib.deflateSync(rawData);
  const idatChunk = makeChunk('IDAT', compressed);

  // IEND Chunk
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function makeChunk(type, data) {
  const len = data.length;
  const buf = Buffer.alloc(12 + len);
  buf.writeUInt32BE(len, 0);
  buf.write(type, 4, 4, 'ascii');
  data.copy(buf, 8);

  // CRC32 of type + data
  const crc = crc32(buf.subarray(4, 8 + len));
  buf.writeInt32BE(crc, 8 + len);
  return buf;
}

// Simple CRC32 implementation
function crc32(buf) {
  let c = ~0;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) {
      c = (c >>> 1) ^ (c & 1 ? 0xEDB88320 : 0);
    }
  }
  return ~c;
}

// Ensure public dir exists
const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'icon-192.png'), createPng(192, 192, false));
fs.writeFileSync(path.join(publicDir, 'icon-512.png'), createPng(512, 512, false));
fs.writeFileSync(path.join(publicDir, 'icon-maskable-512.png'), createPng(512, 512, true));

console.log('✅ Generated PWA Icons: icon-192.png, icon-512.png, icon-maskable-512.png');
