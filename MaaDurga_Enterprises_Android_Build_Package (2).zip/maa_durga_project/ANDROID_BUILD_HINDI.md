# MAA DURGA ENTERPRISES — Android APK बनाना (मोबाइल से)

## जरूरी बात
`public/MaaDurga_Enterprises.apk` वाली पुरानी फाइल असली Android APK नहीं थी; वह ZIP-जैसा placeholder था। उसे हटाया गया है ताकि उसे इंस्टॉल करने की कोशिश न हो। इस प्रोजेक्ट में अब GitHub Actions का build workflow है जो Android SDK/Gradle से वास्तविक debug APK बनाता है।

## A. पहले backend deploy करें (OTP के लिए जरूरी)
1. इस ZIP को extract करके GitHub repository में upload करें।
2. Render पर `render.yaml` से Web Service deploy करें।
3. Render Environment में वास्तविक SMS provider का `FAST2SMS_API_KEY` या WhatsApp provider की आवश्यक credentials सेट करें।
4. Provider के dashboard में OTP template/WhatsApp template और sender configuration पूरी करें।
5. Deploy होने के बाद backend URL नोट करें, उदाहरण: `https://your-service.onrender.com`।

**सुरक्षा:** OTP provider की API key किसी chat, frontend code या GitHub source में न डालें; केवल Render Environment Secrets में डालें। बिना वास्तविक provider credentials के OTP जानबूझकर fail होगा—ऐप कोई fake OTP नहीं दिखाएगा।

## B. GitHub से APK बनाएं
1. GitHub पर repository बनाएं और इस project की सभी files upload करें।
2. Repository → Settings → Secrets and variables → Actions → Variables में जाएं।
3. `API_BASE_URL` नाम की Repository Variable बनाकर Render backend URL डालें (आखिर में `/` न लगाएं)।
4. Actions tab खोलें → **Build MAA DURGA ENTERPRISES Android APK** चुनें → **Run workflow** दबाएं।
5. Build पूरा होने पर उसी workflow run के नीचे **Artifacts** में `MaaDurga-Enterprises-APK` डाउनलोड करें।
6. ZIP artifact को Android मोबाइल में extract करें और `app-debug.apk` इंस्टॉल करें। केवल भरोसेमंद अपने build को इंस्टॉल करें।

## C. सीमाएं
- यह workflow debug APK बनाता है, Play Store release-signed APK नहीं। Public distribution के लिए release signing key सुरक्षित रूप से configure करनी होगी।
- OTP तभी आएगा जब backend deploy हो और SMS/WhatsApp provider सही तरह configured हो।
- ERP डेटा फिलहाल IndexedDB में स्थानीय डिवाइस पर सेव होता है; अलग-अलग मोबाइलों में साझा डेटा/क्लाउड sync के लिए अलग database integration की जरूरत है।
- Android APK build के लिए GitHub account और internet जरूरी हैं; इस रनटाइम में Android SDK उपलब्ध नहीं है, इसलिए यहां सीधे compiled APK बनाना संभव नहीं था।
