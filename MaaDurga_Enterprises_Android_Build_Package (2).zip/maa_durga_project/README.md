# 🔱 MAA DURGA ENTERPRISES
## ULTIMATE MOBILE BILLING ERP & SHOWROOM MANAGEMENT APP

A production-grade, offline-capable Mobile Showroom Billing ERP built with **React 19, TypeScript, Tailwind CSS, and IndexedDB**. Designed in a **Royal Black + Royal Blue + Deep Gold** theme specifically tailored for Indian mobile showrooms and electronics retailers.

---

### 🌟 Key Highlights & Features

0. **Admin Mobile OTP Authentication Guard**
   - **Shop Name**: MAA DURGA ENTERPRISES
   - **Authorized Admin Phone**: `+91 8252072859` (Strictly restricted; unauthorized mobile numbers are rejected)
   - **6-Digit Dynamic OTP Verification**: Cryptographically generated on backend (`server.ts`) with HMAC-SHA256 salted storage; real delivery requires configured SMS/WhatsApp provider
   - **5-Minute OTP Expiry**: Live countdown timer with automatic invalidation after 300 seconds
   - **Resend Cooldown Timer**: 45-second lockout preventing spam
   - **Rate Limiting & Anti-Brute-Force**: Maximum 5 attempts per OTP before invalidation
   - **Session Token**: Secure 64-character bearer token with 8-hour validity and instant Logout in Navbar
   - OTP is never returned to the browser as a debug code; login fails clearly when no real provider is configured

1. **Smart Dashboard (12 Live Financial & Inventory Metric Cards)**
   - Today's Total Sales & Net Profit (Selling Price - Purchase Cost - Overheads)
   - Total Purchases, Customers, Mobile Stock count & Valuation at purchase cost
   - Total Outstanding Udhaar (Credit) receivable
   - Today's Received Payment (Cash/UPI/Bank)
   - Pending EMI Installment Tracker
   - Active Warranty Handsets
   - Pending Mobile Repairs
   - Low Stock Reorder Alerts

2. **Advanced POS Bill Book (`New Bill` / F2 Shortcut)**
   - Fast billing with dual IMEI tracking (`IMEI 1` & `IMEI 2`)
   - **Duplicate Sale Prevention**: An IMEI cannot be sold twice
   - Automatic customer autocomplete from existing Khata
   - GST Regular (18% HSN 8517) with auto CGST 9% + SGST 9% vs Non-GST Retail
   - Payment modes: Cash, UPI, Card, Bank Transfer, Udhar, Split
   - Dynamic balance auto-added to customer's Udhaar Khata
   - Stock auto-decremented & celebration sound effects

3. **Professional Multi-Format Bill Printing**
   - **A4 Showroom Tax Invoice**: Logo, GSTIN, HSN 8517, dual IMEI details, amount in words, dynamic UPI QR code, customer/shop signatures & terms
   - **80mm Thermal Receipt**: Fast POS roll receipt for thermal printers
   - **58mm Mini Receipt**: Compact format for handheld Bluetooth printers
   - **WhatsApp Instant Share**: Encoded link with customer invoice summary

4. **Stock & Dual IMEI Management**
   - Catalog smartphones, keypad phones, used phones, smartwatches, earbuds & accessories
   - Filter by Brand (Apple, Samsung, Vivo, Oppo, OnePlus, Realme, Xiaomi, etc.)
   - Real-time stock valuation cards & sold handset history audit
   - Stock adjustment (damaged, showroom demo display, supplier returns)

5. **Purchases & Supplier Ledger**
   - Inward new shipments with multiple IMEI scans/entries
   - Automatically increments current stock and catalog items
   - Tracks wholesale payments & pending supplier payables

6. **Customer Udhaar Khata**
   - Individual customer ledgers with running balance
   - Receive payment (उधार जमा) with instant balance reduction
   - **WhatsApp Payment Reminder** (तगादा संदेश) with shop UPI QR

7. **EMI & Mobile Finance Management**
   - Integrations for Bajaj Finserv, TVS Credit, IDFC First Bank, Home Credit, DMI Finance & Shop Finance
   - Down payment receipt & monthly installment tracker with due dates

8. **Exchange & Used Mobile Management**
   - Evaluates old handsets (condition & bonus) and auto-catalogs into Used Mobile Stock for resale

9. **Mobile Repair Service Center**
   - Job sheet ticketing, reported problems checklist, estimated charges & advance tracking
   - Service status pipeline: `Received` → `In Progress` → `Parts Pending` → `Ready` → `Delivered`
   - Print Repair Job Token with terms

10. **Shop Expenses & Net Profit**
    - Logs Rent, Electricity, Staff Salaries, Courier, Tools & Spares
    - Exact calculation of Net Realized Profit

11. **Security & Offline Storage**
    - 4-digit POS PIN Lock screen (default: `1234`)
    - IndexedDB local storage: all data persists across browser refreshes and offline reloads
    - JSON backup download and restore

---

### ⌨️ Keyboard Shortcuts
- `F2`: Instantly open New Bill book
- `Esc`: Close modals


## Android APK build

The APK previously included in `public/` was only a placeholder ZIP and was removed. Use `.github/workflows/build-android.yml` to build a real debug APK with Android SDK and Gradle. See `ANDROID_BUILD_HINDI.md` for the mobile-friendly steps and backend OTP configuration.
