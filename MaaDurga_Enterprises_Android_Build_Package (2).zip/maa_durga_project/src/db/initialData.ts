import { Product, Customer, Supplier, RepairJob, EMIRecord, Expense, ShopSettings, Invoice } from '../types/erp';

export const defaultSettings: ShopSettings = {
  shopName: "MAA DURGA ENTERPRISES",
  shopTagline: "COMPLETE MOBILE SHOWROOM, ACCESSORIES & REPAIR CENTER",
  ownerName: "Rajeev Kumar",
  phone: "9876543210",
  altPhone: "9123456780",
  email: "maadurgaenterprises@gmail.com",
  address: "Main Market, Station Road, Opp. SBI Bank",
  city: "Patna",
  state: "Bihar",
  pincode: "800001",
  gstin: "10ABCDE1234F1Z5",
  upiId: "maadurga@okaxis",
  invoicePrefix: "MDE-2026-",
  nextInvoiceSeq: 104,
  invoiceTerms: "1. Warranty will be provided by respective Authorized Service Center.\n2. No replacement without original bill and box.\n3. Water damage and physical damage are not covered under warranty.\n4. Goods once sold will not be taken back or refunded.",
  repairTerms: "1. Handset must be collected within 30 days of repair readiness.\n2. Shop is not responsible for data loss during repair or software flashing.\n3. No warranty on water-damaged motherboards.",
  currencySymbol: "₹",
  defaultGstRate: 18,
  pinLockEnabled: false,
  pinCode: "1234",
  userRole: "admin",
  language: "hi",
  themeMode: "dark",
  autoBackupPrompt: true
};

export const initialProducts: Product[] = [
  {
    id: "prod-1",
    name: "iPhone 16 Pro",
    brand: "Apple",
    model: "A3293 (128GB)",
    ram: "8GB",
    storage: "128GB",
    color: "Desert Titanium",
    imeiList: [
      "354892110482910",
      "354892110482911"
    ],
    serialNumber: "F2LX90J1PQ",
    category: "smartphone",
    purchasePrice: 109900,
    sellingPrice: 119900,
    currentStock: 2,
    minStockAlert: 1,
    warrantyMonths: 12,
    createdAt: "2026-10-01",
    updatedAt: "2026-10-01"
  },
  {
    id: "prod-2",
    name: "Galaxy S25 Ultra 5G",
    brand: "Samsung",
    model: "SM-S928B (256GB)",
    ram: "12GB",
    storage: "256GB",
    color: "Titanium Gray",
    imeiList: [
      "864920048123901",
      "864920048123902",
      "864920048123903"
    ],
    serialNumber: "R5CW109KLL",
    category: "smartphone",
    purchasePrice: 112000,
    sellingPrice: 124999,
    currentStock: 3,
    minStockAlert: 2,
    warrantyMonths: 12,
    createdAt: "2026-10-02",
    updatedAt: "2026-10-02"
  },
  {
    id: "prod-3",
    name: "Vivo V40 5G",
    brand: "Vivo",
    model: "V2348 (8/256)",
    ram: "8GB",
    storage: "256GB",
    color: "Lotus Purple",
    imeiList: [
      "867491049281044",
      "867491049281045",
      "867491049281046",
      "867491049281047"
    ],
    category: "smartphone",
    purchasePrice: 31200,
    sellingPrice: 34999,
    currentStock: 4,
    minStockAlert: 2,
    warrantyMonths: 12,
    createdAt: "2026-10-05",
    updatedAt: "2026-10-05"
  },
  {
    id: "prod-4",
    name: "OnePlus 13 5G",
    brand: "OnePlus",
    model: "CPH2653 (12/256)",
    ram: "12GB",
    storage: "256GB",
    color: "Arctic Dawn",
    imeiList: [
      "869201948271033",
      "869201948271034"
    ],
    category: "smartphone",
    purchasePrice: 58500,
    sellingPrice: 64999,
    currentStock: 2,
    minStockAlert: 1,
    warrantyMonths: 12,
    createdAt: "2026-10-06",
    updatedAt: "2026-10-06"
  },
  {
    id: "prod-5",
    name: "Redmi Note 14 Pro+ 5G",
    brand: "Xiaomi",
    model: "24090RA29C",
    ram: "8GB",
    storage: "256GB",
    color: "Mirror Porcelain",
    imeiList: [
      "865192049182051",
      "865192049182052",
      "865192049182053"
    ],
    category: "smartphone",
    purchasePrice: 24200,
    sellingPrice: 27999,
    currentStock: 3,
    minStockAlert: 2,
    warrantyMonths: 12,
    createdAt: "2026-10-08",
    updatedAt: "2026-10-08"
  },
  {
    id: "prod-6",
    name: "Realme 13 Pro 5G",
    brand: "Realme",
    model: "RMX3989",
    ram: "8GB",
    storage: "128GB",
    color: "Monet Gold",
    imeiList: [
      "864192049812909"
    ],
    category: "smartphone",
    purchasePrice: 21500,
    sellingPrice: 24499,
    currentStock: 1, // LOW STOCK TRIGGER
    minStockAlert: 2,
    warrantyMonths: 12,
    createdAt: "2026-10-09",
    updatedAt: "2026-10-09"
  },
  {
    id: "prod-7",
    name: "iPhone 13 (Refurbished/Used)",
    brand: "Apple",
    model: "A2633 (128GB)",
    ram: "4GB",
    storage: "128GB",
    color: "Midnight Blue",
    imeiList: [
      "359281049281720"
    ],
    category: "used_phone",
    purchasePrice: 26000,
    sellingPrice: 32500,
    currentStock: 1,
    minStockAlert: 1,
    isUsed: true,
    warrantyMonths: 3,
    notes: "Condition: Very Clean 9/10, Battery Health 88%",
    createdAt: "2026-10-10",
    updatedAt: "2026-10-10"
  },
  {
    id: "prod-8",
    name: "Apple 20W USB-C Power Adapter",
    brand: "Apple",
    model: "MHJE3HN/A",
    imeiList: [],
    category: "charger_cable",
    purchasePrice: 1350,
    sellingPrice: 1900,
    currentStock: 14,
    minStockAlert: 5,
    warrantyMonths: 6,
    createdAt: "2026-10-01",
    updatedAt: "2026-10-01"
  },
  {
    id: "prod-9",
    name: "boAt Airdopes 141 ANC",
    brand: "boAt",
    model: "141 ANC Bluetooth Earbuds",
    imeiList: [],
    category: "audio",
    purchasePrice: 950,
    sellingPrice: 1499,
    currentStock: 8,
    minStockAlert: 3,
    warrantyMonths: 12,
    createdAt: "2026-10-02",
    updatedAt: "2026-10-02"
  },
  {
    id: "prod-10",
    name: "Noise ColorFit Pulse 3",
    brand: "Noise",
    model: "Pulse 3 Smartwatch (BT Calling)",
    imeiList: [],
    category: "smartwatch",
    purchasePrice: 1100,
    sellingPrice: 1799,
    currentStock: 5,
    minStockAlert: 2,
    warrantyMonths: 12,
    createdAt: "2026-10-03",
    updatedAt: "2026-10-03"
  }
];

export const initialCustomers: Customer[] = [
  {
    id: "cust-1",
    name: "Ramesh Sharma",
    phone: "9835012345",
    address: "Boring Road, Patna",
    totalPurchases: 34999,
    totalPaid: 30000,
    currentUdhaar: 4999,
    createdAt: "2026-09-15",
    lastPurchaseDate: "2026-10-11",
    notes: "Regular customer, promise to pay on 20th"
  },
  {
    id: "cust-2",
    name: "Pooja Verma",
    phone: "9431098765",
    address: "Kankarbagh, Patna",
    totalPurchases: 64999,
    totalPaid: 64999,
    currentUdhaar: 0,
    createdAt: "2026-09-20",
    lastPurchaseDate: "2026-10-12"
  },
  {
    id: "cust-3",
    name: "Vikash Kumar Gupta",
    phone: "9122345678",
    address: "Danapur Cantt, Patna",
    totalPurchases: 27999,
    totalPaid: 20000,
    currentUdhaar: 7999,
    createdAt: "2026-09-28",
    lastPurchaseDate: "2026-10-10",
    notes: "Balance pending on Redmi Note 14 Pro+"
  },
  {
    id: "cust-4",
    name: "Amitabh Sen",
    phone: "7004123890",
    address: "Bailey Road, Patna",
    totalPurchases: 119900,
    totalPaid: 119900,
    currentUdhaar: 0,
    createdAt: "2026-10-02",
    lastPurchaseDate: "2026-10-08"
  }
];

export const initialSuppliers: Supplier[] = [
  {
    id: "supp-1",
    name: "Patliputra Telecom Distributors",
    phone: "9835112233",
    address: "Fraser Road, Patna",
    gstin: "10AABCP9871P1Z2",
    totalPurchased: 450000,
    totalPaid: 400000,
    pendingBalance: 50000,
    createdAt: "2026-08-01"
  },
  {
    id: "supp-2",
    name: "Shree Ganesh Mobile Wholesale",
    phone: "9431223344",
    address: "Chandni Chowk, Delhi / Patna Branch",
    gstin: "07AAACS5512N1Z4",
    totalPurchased: 320000,
    totalPaid: 320000,
    pendingBalance: 0,
    createdAt: "2026-08-15"
  }
];

export const initialInvoices: Invoice[] = [
  {
    id: "inv-101",
    invoiceNumber: "MDE-2026-0101",
    date: "2026-10-12",
    time: "11:45 AM",
    customerId: "cust-2",
    customerName: "Pooja Verma",
    customerPhone: "9431098765",
    customerAddress: "Kankarbagh, Patna",
    items: [
      {
        productId: "prod-4",
        productName: "OnePlus 13 5G",
        brand: "OnePlus",
        model: "CPH2653 (12/256)",
        ramStorage: "12GB / 256GB",
        color: "Arctic Dawn",
        imei1: "869201948271099",
        quantity: 1,
        rate: 64999,
        discount: 0,
        amount: 64999,
        purchasePrice: 58500,
        gstRate: 18,
        category: "smartphone"
      }
    ],
    subtotal: 55083.9,
    gstType: "gst",
    gstRate: 18,
    cgst: 4957.55,
    sgst: 4957.55,
    igst: 0,
    totalDiscount: 0,
    roundOff: 0,
    grandTotal: 64999,
    paymentMode: "upi",
    paidAmount: 64999,
    dueAmount: 0,
    createdBy: "Admin",
    createdAt: "2026-10-12T11:45:00"
  },
  {
    id: "inv-102",
    invoiceNumber: "MDE-2026-0102",
    date: "2026-10-13",
    time: "02:15 PM",
    customerId: "cust-1",
    customerName: "Ramesh Sharma",
    customerPhone: "9835012345",
    customerAddress: "Boring Road, Patna",
    items: [
      {
        productId: "prod-3",
        productName: "Vivo V40 5G",
        brand: "Vivo",
        model: "V2348 (8/256)",
        ramStorage: "8GB / 256GB",
        color: "Lotus Purple",
        imei1: "867491049281001",
        quantity: 1,
        rate: 34999,
        discount: 0,
        amount: 34999,
        purchasePrice: 31200,
        gstRate: 18,
        category: "smartphone"
      }
    ],
    subtotal: 29660.17,
    gstType: "gst",
    gstRate: 18,
    cgst: 2669.41,
    sgst: 2669.41,
    igst: 0,
    totalDiscount: 0,
    roundOff: 0,
    grandTotal: 34999,
    paymentMode: "udhar",
    paidAmount: 30000,
    dueAmount: 4999,
    createdBy: "Admin",
    createdAt: "2026-10-13T14:15:00"
  },
  {
    id: "inv-103",
    invoiceNumber: "MDE-2026-0103",
    date: "2026-10-13",
    time: "05:30 PM",
    customerId: "cust-4",
    customerName: "Amitabh Sen",
    customerPhone: "7004123890",
    customerAddress: "Bailey Road, Patna",
    items: [
      {
        productId: "prod-8",
        productName: "Apple 20W USB-C Power Adapter",
        brand: "Apple",
        model: "MHJE3HN/A",
        quantity: 1,
        rate: 1900,
        discount: 100,
        amount: 1800,
        purchasePrice: 1350,
        gstRate: 18,
        category: "charger_cable"
      }
    ],
    subtotal: 1525.42,
    gstType: "gst",
    gstRate: 18,
    cgst: 137.29,
    sgst: 137.29,
    igst: 0,
    totalDiscount: 100,
    roundOff: 0,
    grandTotal: 1800,
    paymentMode: "cash",
    paidAmount: 1800,
    dueAmount: 0,
    createdBy: "Admin",
    createdAt: "2026-10-13T17:30:00"
  }
];

export const initialEMIRecords: EMIRecord[] = [
  {
    id: "emi-1",
    customerId: "cust-3",
    customerName: "Vikash Kumar Gupta",
    customerPhone: "9122345678",
    financeCompany: "Bajaj Finserv",
    loanAccountNumber: "BJF-8891024",
    mobileModel: "Redmi Note 14 Pro+ 5G",
    imei: "865192049182001",
    totalMobilePrice: 27999,
    downPayment: 6999,
    financedAmount: 21000,
    installmentAmount: 3500,
    totalInstallments: 6,
    paidInstallments: 2,
    firstEmiDate: "2026-08-10",
    nextDueDate: "2026-11-10",
    status: "active",
    installments: [
      { installmentNumber: 1, dueDate: "2026-09-10", amount: 3500, status: "paid", paidDate: "2026-09-08" },
      { installmentNumber: 2, dueDate: "2026-10-10", amount: 3500, status: "paid", paidDate: "2026-10-09" },
      { installmentNumber: 3, dueDate: "2026-11-10", amount: 3500, status: "pending" },
      { installmentNumber: 4, dueDate: "2026-12-10", amount: 3500, status: "pending" },
      { installmentNumber: 5, dueDate: "2027-01-10", amount: 3500, status: "pending" },
      { installmentNumber: 6, dueDate: "2027-02-10", amount: 3500, status: "pending" }
    ],
    createdAt: "2026-08-10"
  }
];

export const initialRepairJobs: RepairJob[] = [
  {
    id: "rep-1",
    jobTicketNo: "REP-2026-001",
    customerName: "Sanjay Mishra",
    customerPhone: "9835901234",
    mobileModel: "Realme 9 Pro+",
    imeiOrSerial: "865401928371029",
    problems: ["Screen Cracked", "Touch Not Working"],
    problemDescription: "Original OLED folder display replacement needed",
    repairCharges: 3200,
    advancePaid: 1000,
    remainingAmount: 2200,
    technicianName: "Sonu Technician",
    receivedDate: "2026-10-12",
    estimatedDeliveryDate: "2026-10-14",
    status: "In Progress",
    warrantyDays: 30
  },
  {
    id: "rep-2",
    jobTicketNo: "REP-2026-002",
    customerName: "Sunil Tiwari",
    customerPhone: "9934112288",
    mobileModel: "Samsung Galaxy M33",
    imeiOrSerial: "869401827361928",
    problems: ["Charging Port Loose", "Fast Charging Not Working"],
    problemDescription: "Type-C sub-board replacement",
    repairCharges: 650,
    advancePaid: 650,
    remainingAmount: 0,
    technicianName: "Deepak Sharma",
    receivedDate: "2026-10-13",
    estimatedDeliveryDate: "2026-10-13",
    status: "Ready",
    warrantyDays: 15
  }
];

export const initialExpenses: Expense[] = [
  {
    id: "exp-1",
    date: "2026-10-01",
    category: "Shop Rent",
    title: "October Shop Monthly Rent",
    amount: 18000,
    paymentMode: "bank",
    notes: "Paid via NEFT to Landlord"
  },
  {
    id: "exp-2",
    date: "2026-10-05",
    category: "Electricity Bill",
    title: "Electricity Meter Bill",
    amount: 3450,
    paymentMode: "upi",
    notes: "SBPDCL bill paid via UPI"
  },
  {
    id: "exp-3",
    date: "2026-10-13",
    category: "Tea & Refreshment",
    title: "Customer Tea & Snacks",
    amount: 180,
    paymentMode: "cash"
  }
];
