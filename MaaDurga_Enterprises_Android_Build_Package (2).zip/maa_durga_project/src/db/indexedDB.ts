import {
  Product,
  Invoice,
  Customer,
  CustomerPayment,
  Supplier,
  PurchaseBill,
  EMIRecord,
  ExchangeRecord,
  RepairJob,
  Expense,
  ShopSettings
} from '../types/erp';
import {
  defaultSettings,
  initialProducts,
  initialCustomers,
  initialSuppliers,
  initialInvoices,
  initialEMIRecords,
  initialRepairJobs,
  initialExpenses
} from './initialData';

const DB_NAME = 'MaaDurgaERP_DB';
const DB_VERSION = 1;

export interface AppDatabaseData {
  products: Product[];
  invoices: Invoice[];
  customers: Customer[];
  customerPayments: CustomerPayment[];
  suppliers: Supplier[];
  purchases: PurchaseBill[];
  emiRecords: EMIRecord[];
  exchangeRecords: ExchangeRecord[];
  repairJobs: RepairJob[];
  expenses: Expense[];
  settings: ShopSettings;
}

class IndexedDBManager {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private openDB(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Stores
        const stores = [
          'products',
          'invoices',
          'customers',
          'customerPayments',
          'suppliers',
          'purchases',
          'emiRecords',
          'exchangeRecords',
          'repairJobs',
          'expenses'
        ];

        stores.forEach((storeName) => {
          if (!db.objectStoreNames.contains(storeName)) {
            db.createObjectStore(storeName, { keyPath: 'id' });
          }
        });

        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });

    return this.dbPromise;
  }

  // Generic getAll
  async getAll<T>(storeName: string): Promise<T[]> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result as T[]);
      req.onerror = () => reject(req.error);
    });
  }

  // Generic put item
  async put<T extends { id: string }>(storeName: string, item: T): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.put(item);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // Bulk put items
  async putMany<T extends { id: string }>(storeName: string, items: T[]): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      items.forEach((item) => store.put(item));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // Generic delete
  async delete(storeName: string, id: string): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // Clear store
  async clear(storeName: string): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // Settings
  async getSettings(): Promise<ShopSettings> {
    try {
      const db = await this.openDB();
      return new Promise((resolve) => {
        const tx = db.transaction('settings', 'readonly');
        const store = tx.objectStore('settings');
        const req = store.get('app_settings');
        req.onsuccess = () => {
          if (req.result && req.result.data) {
            resolve(req.result.data as ShopSettings);
          } else {
            // Check localStorage fallback
            const local = localStorage.getItem('mde_settings');
            if (local) {
              try {
                resolve(JSON.parse(local));
                return;
              } catch {}
            }
            resolve(defaultSettings);
          }
        };
        req.onerror = () => resolve(defaultSettings);
      });
    } catch {
      return defaultSettings;
    }
  }

  async saveSettings(settings: ShopSettings): Promise<void> {
    const db = await this.openDB();
    // also save in localStorage as safe backup
    try {
      localStorage.setItem('mde_settings', JSON.stringify(settings));
    } catch {}

    return new Promise((resolve, reject) => {
      const tx = db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      const req = store.put({ key: 'app_settings', data: settings });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  // Initialize with initial demo data if database is empty
  async initializeIfEmpty(): Promise<boolean> {
    const existingProducts = await this.getAll<Product>('products');
    if (existingProducts.length === 0) {
      await this.resetToDemoData();
      return true;
    }
    return false;
  }

  // Reset all to demo showroom data
  async resetToDemoData(): Promise<void> {
    const db = await this.openDB();
    const stores = [
      'products',
      'invoices',
      'customers',
      'customerPayments',
      'suppliers',
      'purchases',
      'emiRecords',
      'exchangeRecords',
      'repairJobs',
      'expenses',
      'settings'
    ];

    const tx = db.transaction(stores, 'readwrite');
    stores.forEach((st) => tx.objectStore(st).clear());

    // Populate initial data
    const pStore = tx.objectStore('products');
    initialProducts.forEach((p) => pStore.put(p));

    const cStore = tx.objectStore('customers');
    initialCustomers.forEach((c) => cStore.put(c));

    const sStore = tx.objectStore('suppliers');
    initialSuppliers.forEach((s) => sStore.put(s));

    const iStore = tx.objectStore('invoices');
    initialInvoices.forEach((inv) => iStore.put(inv));

    const eStore = tx.objectStore('emiRecords');
    initialEMIRecords.forEach((emi) => eStore.put(emi));

    const rStore = tx.objectStore('repairJobs');
    initialRepairJobs.forEach((r) => rStore.put(r));

    const expStore = tx.objectStore('expenses');
    initialExpenses.forEach((exp) => expStore.put(exp));

    const setStore = tx.objectStore('settings');
    setStore.put({ key: 'app_settings', data: defaultSettings });

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => {
        try {
          localStorage.setItem('mde_settings', JSON.stringify(defaultSettings));
        } catch {}
        resolve();
      };
      tx.onerror = () => reject(tx.error);
    });
  }

  // Export complete ERP data as clean JSON object
  async exportFullBackup(): Promise<AppDatabaseData> {
    const [
      products,
      invoices,
      customers,
      customerPayments,
      suppliers,
      purchases,
      emiRecords,
      exchangeRecords,
      repairJobs,
      expenses,
      settings
    ] = await Promise.all([
      this.getAll<Product>('products'),
      this.getAll<Invoice>('invoices'),
      this.getAll<Customer>('customers'),
      this.getAll<CustomerPayment>('customerPayments'),
      this.getAll<Supplier>('suppliers'),
      this.getAll<PurchaseBill>('purchases'),
      this.getAll<EMIRecord>('emiRecords'),
      this.getAll<ExchangeRecord>('exchangeRecords'),
      this.getAll<RepairJob>('repairJobs'),
      this.getAll<Expense>('expenses'),
      this.getSettings()
    ]);

    return {
      products,
      invoices,
      customers,
      customerPayments,
      suppliers,
      purchases,
      emiRecords,
      exchangeRecords,
      repairJobs,
      expenses,
      settings
    };
  }

  // Restore full backup from JSON object
  async restoreBackup(data: Partial<AppDatabaseData>): Promise<void> {
    if (data.products && Array.isArray(data.products)) {
      await this.clear('products');
      await this.putMany('products', data.products);
    }
    if (data.invoices && Array.isArray(data.invoices)) {
      await this.clear('invoices');
      await this.putMany('invoices', data.invoices);
    }
    if (data.customers && Array.isArray(data.customers)) {
      await this.clear('customers');
      await this.putMany('customers', data.customers);
    }
    if (data.customerPayments && Array.isArray(data.customerPayments)) {
      await this.clear('customerPayments');
      await this.putMany('customerPayments', data.customerPayments);
    }
    if (data.suppliers && Array.isArray(data.suppliers)) {
      await this.clear('suppliers');
      await this.putMany('suppliers', data.suppliers);
    }
    if (data.purchases && Array.isArray(data.purchases)) {
      await this.clear('purchases');
      await this.putMany('purchases', data.purchases);
    }
    if (data.emiRecords && Array.isArray(data.emiRecords)) {
      await this.clear('emiRecords');
      await this.putMany('emiRecords', data.emiRecords);
    }
    if (data.exchangeRecords && Array.isArray(data.exchangeRecords)) {
      await this.clear('exchangeRecords');
      await this.putMany('exchangeRecords', data.exchangeRecords);
    }
    if (data.repairJobs && Array.isArray(data.repairJobs)) {
      await this.clear('repairJobs');
      await this.putMany('repairJobs', data.repairJobs);
    }
    if (data.expenses && Array.isArray(data.expenses)) {
      await this.clear('expenses');
      await this.putMany('expenses', data.expenses);
    }
    if (data.settings) {
      await this.saveSettings(data.settings);
    }
  }
}

export const dbManager = new IndexedDBManager();
