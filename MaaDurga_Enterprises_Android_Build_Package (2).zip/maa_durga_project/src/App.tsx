import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ERPProvider, useERP } from './context/ERPContext';
import { LanguageProvider } from './context/LanguageContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { Dashboard } from './components/dashboard/Dashboard';
import { NewBill } from './components/billing/NewBill';
import { BillsHistory } from './components/billing/BillsHistory';
import { StockManagement } from './components/stock/StockManagement';
import { PurchaseManagement } from './components/purchase/PurchaseManagement';
import { CustomerUdhaar } from './components/udhaar/CustomerUdhaar';
import { EMIManagement } from './components/emi/EMIManagement';
import { ExchangeManagement } from './components/exchange/ExchangeManagement';
import { RepairManagement } from './components/repair/RepairManagement';
import { ExpenseManagement } from './components/expenses/ExpenseManagement';
import { ReportsAnalytics } from './components/reports/ReportsAnalytics';
import { SettingsModal } from './components/settings/SettingsModal';
import { PinLockScreen } from './components/common/PinLockScreen';
import { AdminLoginScreen } from './components/auth/AdminLoginScreen';
import { ApkTopBar } from './components/common/ApkTopBar';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { ApkInstallModal } from './components/common/ApkInstallModal';

const MainLayout: React.FC = () => {
  const { isLoading: isErpLoading, activeTab, isLocked } = useERP();
  const { isAuthenticated, isLoading: isAuthLoading } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // 1. Initial Authentication & Storage Loading State
  if (isAuthLoading || (isAuthenticated && isErpLoading)) {
    return (
      <div className="min-h-screen bg-[#070b14] flex flex-col items-center justify-center text-center p-6 select-none">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center shadow-xl shadow-amber-500/20 animate-pulse mb-4">
          <span className="text-3xl font-black text-slate-950 font-royal">ॐ</span>
        </div>
        <h1 className="text-lg font-bold text-amber-300 font-royal tracking-widest uppercase">
          MAA DURGA ENTERPRISES
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Verifying Admin Credentials & Synchronizing Showroom ERP...
        </p>
      </div>
    );
  }

  // 2. If Not Authenticated -> Show Admin Mobile OTP Login Screen
  if (!isAuthenticated) {
    return <AdminLoginScreen />;
  }

  // 3. Authenticated -> Render Full ERP Dashboard
  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      {/* 4-digit POS Terminal Lock Screen if manually locked */}
      {isLocked && <PinLockScreen />}

      {/* Prominent Android APK Bar at top */}
      <ApkTopBar />

      {/* Top Navbar */}
      <Navbar
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Navigation */}
        <Sidebar
          isOpen={isSidebarOpen}
          onCloseMobile={() => setIsSidebarOpen(false)}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />

        {/* Central Dynamic Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full pb-28 lg:pb-8">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'new-bill' && <NewBill />}
          {activeTab === 'bills-history' && <BillsHistory />}
          {activeTab === 'stock' && <StockManagement />}
          {activeTab === 'purchases' && <PurchaseManagement />}
          {activeTab === 'udhaar' && <CustomerUdhaar />}
          {activeTab === 'emi' && <EMIManagement />}
          {activeTab === 'exchange' && <ExchangeManagement />}
          {activeTab === 'repairs' && <RepairManagement />}
          {activeTab === 'expenses' && <ExpenseManagement />}
          {activeTab === 'reports' && <ReportsAnalytics />}
        </main>
      </div>

      {/* NATIVE MOBILE APP BOTTOM NAVIGATION BAR (for Android & Mobile screens) */}
      <MobileBottomNav
        onOpenMobileMenu={() => setIsSidebarOpen(true)}
        onOpenApkModal={() => setIsApkModalOpen(true)}
      />

      {/* Mobile App APK Download & Install Modal */}
      <ApkInstallModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <ERPProvider>
          <MainLayout />
        </ERPProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}
