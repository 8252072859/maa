import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  Invoice,
  Customer,
  CustomerPayment,
  Supplier,
  PurchaseBill,
  EMIRecord,
  ExchangeRecord,
  RepairJob,
  Expense,
  ShopSettings,
  BillItem
} from '../types/erp';
import { dbManager, AppDatabaseData } from '../db/indexedDB';
import { defaultSettings } from '../db/initialData';
import { getTodayDateString, getCurrentTimeString } from '../utils/formatters';
import { sounds } from '../utils/soundEffects';

interface ERPContextType {
  // State
  isLoading: boolean;
  products: Product[];
  invoices: Invoice[];
  customers: Customer[];
  customerPayments: CustomerPayment[];
  suppliers: Supplier[];
  purchases: PurchaseBill[];
  emiRecords: EMIRecord[];
  exchangeRecords: ExchangeRecord[];
  repairJobs: RepairJob[];
  expenses: Expense[];
  settings: ShopSettings;
  isLocked: boolean;
  activeTab: string;

  // Setters & Navigation
  setActiveTab: (tab: string) => void;
  setIsLocked: (locked: boolean) => void;
  updateSettings: (newSettings: ShopSettings) => Promise<void>;

  // Products & Stock
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Product>;
  updateProduct: (product: Product) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  isImeiAvailable: (imei: string) => { available: boolean; reason?: string; product?: Product };
  adjustStockQuantity: (productId: string, newStock: number, reason: string) => Promise<void>;

  // Billing & Sales
  createInvoice: (invoiceData: Omit<Invoice, 'id' | 'createdAt'>) => Promise<Invoice>;
  cancelInvoice: (id: string, reason: string) => Promise<void>;

  // Customers & Udhaar
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt' | 'totalPurchases' | 'totalPaid' | 'currentUdhaar'>) => Promise<Customer>;
  updateCustomer: (customer: Customer) => Promise<void>;
  recordCustomerPayment: (payment: Omit<CustomerPayment, 'id'>) => Promise<void>;

  // Purchases & Suppliers
  addSupplier: (supplier: Omit<Supplier, 'id' | 'createdAt' | 'totalPurchased' | 'totalPaid' | 'pendingBalance'>) => Promise<Supplier>;
  createPurchaseBill: (bill: Omit<PurchaseBill, 'id' | 'createdAt'>) => Promise<void>;

  // EMI & Finance
  createEMIRecord: (record: Omit<EMIRecord, 'id' | 'createdAt'>) => Promise<void>;
  payEMIInstallment: (emiId: string, installmentIndex: number, mode: string) => Promise<void>;

  // Exchange & Used
  recordExchange: (exchange: Omit<ExchangeRecord, 'id'>) => Promise<void>;

  // Repairs
  createRepairJob: (job: Omit<RepairJob, 'id'>) => Promise<void>;
  updateRepairJobStatus: (id: string, status: RepairJob['status'], deliveredDate?: string) => Promise<void>;
  payRepairRemaining: (id: string, amountPaid: number) => Promise<void>;

  // Expenses
  addExpense: (expense: Omit<Expense, 'id'>) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;

  // Backup & Reset
  exportBackup: () => Promise<AppDatabaseData>;
  restoreBackup: (data: Partial<AppDatabaseData>) => Promise<void>;
  resetToDemoData: () => Promise<void>;
}

const ERPContext = createContext<ERPContextType | undefined>(undefined);

export const ERPProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [customerPayments, setCustomerPayments] = useState<CustomerPayment[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchases, setPurchases] = useState<PurchaseBill[]>([]);
  const [emiRecords, setEmiRecords] = useState<EMIRecord[]>([]);
  const [exchangeRecords, setExchangeRecords] = useState<ExchangeRecord[]>([]);
  const [repairJobs, setRepairJobs] = useState<RepairJob[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [settings, setSettings] = useState<ShopSettings>(defaultSettings);
  const [isLocked, setIsLocked] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');

  // Load all data from IndexedDB
  const reloadData = async () => {
    try {
      await dbManager.initializeIfEmpty();
      const [
        loadedProducts,
        loadedInvoices,
        loadedCustomers,
        loadedPayments,
        loadedSuppliers,
        loadedPurchases,
        loadedEmi,
        loadedExchange,
        loadedRepairs,
        loadedExpenses,
        loadedSettings
      ] = await Promise.all([
        dbManager.getAll<Product>('products'),
        dbManager.getAll<Invoice>('invoices'),
        dbManager.getAll<Customer>('customers'),
        dbManager.getAll<CustomerPayment>('customerPayments'),
        dbManager.getAll<Supplier>('suppliers'),
        dbManager.getAll<PurchaseBill>('purchases'),
        dbManager.getAll<EMIRecord>('emiRecords'),
        dbManager.getAll<ExchangeRecord>('exchangeRecords'),
        dbManager.getAll<RepairJob>('repairJobs'),
        dbManager.getAll<Expense>('expenses'),
        dbManager.getSettings()
      ]);

      setProducts(loadedProducts);
      // Sort invoices newest first
      setInvoices(loadedInvoices.sort((a, b) => new Date(b.createdAt || b.date).getTime() - new Date(a.createdAt || a.date).getTime()));
      setCustomers(loadedCustomers);
      setCustomerPayments(loadedPayments);
      setSuppliers(loadedSuppliers);
      setPurchases(loadedPurchases);
      setEmiRecords(loadedEmi);
      setExchangeRecords(loadedExchange);
      setRepairJobs(loadedRepairs);
      setExpenses(loadedExpenses);
      setSettings(loadedSettings);

      if (loadedSettings.pinLockEnabled) {
        setIsLocked(true);
      }
    } catch (err) {
      console.error('Failed to load database:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    reloadData();
  }, []);

  // Update Settings
  const updateSettings = async (newSettings: ShopSettings) => {
    await dbManager.saveSettings(newSettings);
    setSettings(newSettings);
  };

  // Check if IMEI is available or already sold
  const isImeiAvailable = (imei: string): { available: boolean; reason?: string; product?: Product } => {
    const clean = imei.trim();
    if (!clean) return { available: false, reason: "Empty IMEI" };

    // Check in past active invoices
    for (const inv of invoices) {
      if (inv.isCancelled) continue;
      for (const item of inv.items) {
        if (item.imei1 === clean || item.imei2 === clean) {
          return {
            available: false,
            reason: `IMEI ${clean} already sold in Bill #${inv.invoiceNumber} on ${inv.date} to ${inv.customerName}`
          };
        }
      }
    }

    // Check in existing product stock
    const matchedProduct = products.find(p => p.imeiList && p.imeiList.includes(clean));
    if (matchedProduct) {
      return { available: true, product: matchedProduct };
    }

    return { available: true };
  };

  // Add Product
  const addProduct = async (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Promise<Product> => {
    const now = getTodayDateString();
    const newProduct: Product = {
      ...productData,
      id: `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: now,
      updatedAt: now
    };
    await dbManager.put('products', newProduct);
    setProducts(prev => [newProduct, ...prev]);
    return newProduct;
  };

  // Update Product
  const updateProduct = async (product: Product) => {
    const updated: Product = { ...product, updatedAt: getTodayDateString() };
    await dbManager.put('products', updated);
    setProducts(prev => prev.map(p => (p.id === product.id ? updated : p)));
  };

  // Delete Product
  const deleteProduct = async (id: string) => {
    await dbManager.delete('products', id);
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  // Adjust Stock
  const adjustStockQuantity = async (productId: string, newStock: number, reason: string) => {
    const p = products.find(prod => prod.id === productId);
    if (!p) return;
    const updated: Product = {
      ...p,
      currentStock: Math.max(0, newStock),
      notes: reason ? `${p.notes || ''} [Adjust: ${reason}]` : p.notes,
      updatedAt: getTodayDateString()
    };
    await dbManager.put('products', updated);
    setProducts(prev => prev.map(prod => (prod.id === productId ? updated : prod)));
  };

  // Create Invoice (Heart of Billing)
  const createInvoice = async (invoiceData: Omit<Invoice, 'id' | 'createdAt'>): Promise<Invoice> => {
    // 1. Verify IMEIs are not previously sold
    for (const item of invoiceData.items) {
      if (item.imei1) {
        const check1 = isImeiAvailable(item.imei1);
        if (!check1.available) {
          sounds.playErrorBuzz();
          throw new Error(check1.reason);
        }
      }
      if (item.imei2) {
        const check2 = isImeiAvailable(item.imei2);
        if (!check2.available) {
          sounds.playErrorBuzz();
          throw new Error(check2.reason);
        }
      }
    }

    const nowIso = new Date().toISOString();
    const newInvoice: Invoice = {
      ...invoiceData,
      id: `inv-${Date.now()}`,
      createdAt: nowIso
    };

    // 2. Save Invoice
    await dbManager.put('invoices', newInvoice);

    // 3. Deduct Stock and Remove sold IMEIs from active inventory
    const updatedProducts = [...products];
    for (const item of invoiceData.items) {
      const idx = updatedProducts.findIndex(p => p.id === item.productId);
      if (idx !== -1) {
        const prod = { ...updatedProducts[idx] };
        prod.currentStock = Math.max(0, prod.currentStock - item.quantity);
        
        // Remove used IMEIs
        if (prod.imeiList && prod.imeiList.length > 0) {
          prod.imeiList = prod.imeiList.filter(
            imei => imei !== item.imei1 && imei !== item.imei2
          );
        }
        prod.updatedAt = getTodayDateString();
        await dbManager.put('products', prod);
        updatedProducts[idx] = prod;
      }
    }
    setProducts(updatedProducts);

    // 4. Update Customer Udhaar and Purchase Totals
    let cust = customers.find(c => c.id === invoiceData.customerId || (c.phone && c.phone === invoiceData.customerPhone));
    if (cust) {
      const updatedCustomer: Customer = {
        ...cust,
        totalPurchases: cust.totalPurchases + invoiceData.grandTotal,
        totalPaid: cust.totalPaid + invoiceData.paidAmount,
        currentUdhaar: cust.currentUdhaar + invoiceData.dueAmount,
        lastPurchaseDate: invoiceData.date
      };
      await dbManager.put('customers', updatedCustomer);
      setCustomers(prev => prev.map(c => (c.id === updatedCustomer.id ? updatedCustomer : c)));
    } else if (invoiceData.customerName) {
      // Create new customer
      const newCust: Customer = {
        id: `cust-${Date.now()}`,
        name: invoiceData.customerName,
        phone: invoiceData.customerPhone || '',
        address: invoiceData.customerAddress || '',
        totalPurchases: invoiceData.grandTotal,
        totalPaid: invoiceData.paidAmount,
        currentUdhaar: invoiceData.dueAmount,
        createdAt: invoiceData.date,
        lastPurchaseDate: invoiceData.date
      };
      await dbManager.put('customers', newCust);
      setCustomers(prev => [newCust, ...prev]);
    }

    // 5. Update next invoice sequence in settings
    const updatedSettings: ShopSettings = {
      ...settings,
      nextInvoiceSeq: settings.nextInvoiceSeq + 1
    };
    await dbManager.saveSettings(updatedSettings);
    setSettings(updatedSettings);

    // 6. Play cash chime and update state
    sounds.playSuccessChime();
    setInvoices(prev => [newInvoice, ...prev]);

    return newInvoice;
  };

  // Cancel Invoice (Restores Stock & Reverses Udhaar)
  const cancelInvoice = async (id: string, reason: string) => {
    const inv = invoices.find(i => i.id === id);
    if (!inv || inv.isCancelled) return;

    const cancelledInv: Invoice = {
      ...inv,
      isCancelled: true,
      cancelReason: reason
    };
    await dbManager.put('invoices', cancelledInv);

    // Restore stock and IMEIs
    const updatedProducts = [...products];
    for (const item of inv.items) {
      const idx = updatedProducts.findIndex(p => p.id === item.productId);
      if (idx !== -1) {
        const prod = { ...updatedProducts[idx] };
        prod.currentStock += item.quantity;
        const restoredImeis = [...(prod.imeiList || [])];
        if (item.imei1 && !restoredImeis.includes(item.imei1)) restoredImeis.push(item.imei1);
        if (item.imei2 && !restoredImeis.includes(item.imei2)) restoredImeis.push(item.imei2);
        prod.imeiList = restoredImeis;
        prod.updatedAt = getTodayDateString();
        await dbManager.put('products', prod);
        updatedProducts[idx] = prod;
      }
    }
    setProducts(updatedProducts);

    // Reverse customer balance
    const cust = customers.find(c => c.id === inv.customerId);
    if (cust) {
      const updatedCust: Customer = {
        ...cust,
        totalPurchases: Math.max(0, cust.totalPurchases - inv.grandTotal),
        totalPaid: Math.max(0, cust.totalPaid - inv.paidAmount),
        currentUdhaar: Math.max(0, cust.currentUdhaar - inv.dueAmount)
      };
      await dbManager.put('customers', updatedCust);
      setCustomers(prev => prev.map(c => (c.id === updatedCust.id ? updatedCust : c)));
    }

    setInvoices(prev => prev.map(i => (i.id === id ? cancelledInv : i)));
  };

  // Add Customer
  const addCustomer = async (data: Omit<Customer, 'id' | 'createdAt' | 'totalPurchases' | 'totalPaid' | 'currentUdhaar'>): Promise<Customer> => {
    const newCust: Customer = {
      ...data,
      id: `cust-${Date.now()}`,
      totalPurchases: 0,
      totalPaid: 0,
      currentUdhaar: 0,
      createdAt: getTodayDateString()
    };
    await dbManager.put('customers', newCust);
    setCustomers(prev => [newCust, ...prev]);
    return newCust;
  };

  // Update Customer
  const updateCustomer = async (customer: Customer) => {
    await dbManager.put('customers', customer);
    setCustomers(prev => prev.map(c => (c.id === customer.id ? customer : c)));
  };

  // Record Customer Payment (उधार जमा)
  const recordCustomerPayment = async (paymentData: Omit<CustomerPayment, 'id'>) => {
    const newPayment: CustomerPayment = {
      ...paymentData,
      id: `pay-${Date.now()}`
    };
    await dbManager.put('customerPayments', newPayment);
    setCustomerPayments(prev => [newPayment, ...prev]);

    // Deduct from customer's currentUdhaar & add to totalPaid
    const cust = customers.find(c => c.id === paymentData.customerId);
    if (cust) {
      const updatedCust: Customer = {
        ...cust,
        totalPaid: cust.totalPaid + paymentData.amount,
        currentUdhaar: Math.max(0, cust.currentUdhaar - paymentData.amount)
      };
      await dbManager.put('customers', updatedCust);
      setCustomers(prev => prev.map(c => (c.id === updatedCust.id ? updatedCust : c)));
    }
    sounds.playSuccessChime();
  };

  // Suppliers & Purchases
  const addSupplier = async (data: Omit<Supplier, 'id' | 'createdAt' | 'totalPurchased' | 'totalPaid' | 'pendingBalance'>): Promise<Supplier> => {
    const newSupp: Supplier = {
      ...data,
      id: `supp-${Date.now()}`,
      totalPurchased: 0,
      totalPaid: 0,
      pendingBalance: 0,
      createdAt: getTodayDateString()
    };
    await dbManager.put('suppliers', newSupp);
    setSuppliers(prev => [newSupp, ...prev]);
    return newSupp;
  };

  // Create Purchase Bill (Increases Stock automatically!)
  const createPurchaseBill = async (billData: Omit<PurchaseBill, 'id' | 'createdAt'>) => {
    const newBill: PurchaseBill = {
      ...billData,
      id: `pur-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    await dbManager.put('purchases', newBill);
    setPurchases(prev => [newBill, ...prev]);

    // Update or add products and new IMEIs
    const updatedProducts = [...products];
    for (const item of billData.items) {
      // Find matching product by brand & model or name
      const existingIdx = updatedProducts.findIndex(
        p => p.brand.toLowerCase() === item.brand.toLowerCase() && p.model.toLowerCase() === item.model.toLowerCase()
      );

      if (existingIdx !== -1) {
        const existing = updatedProducts[existingIdx];
        const combinedImeis = Array.from(new Set([...(existing.imeiList || []), ...item.imeiList]));
        const updatedP: Product = {
          ...existing,
          currentStock: existing.currentStock + item.quantity,
          purchasePrice: item.purchaseRate,
          sellingPrice: item.sellingRateTarget > 0 ? item.sellingRateTarget : existing.sellingPrice,
          imeiList: combinedImeis,
          updatedAt: getTodayDateString()
        };
        await dbManager.put('products', updatedP);
        updatedProducts[existingIdx] = updatedP;
      } else {
        // Add as fresh product
        const freshP: Product = {
          id: `prod-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          name: item.productName,
          brand: item.brand,
          model: item.model,
          ram: item.ram,
          storage: item.storage,
          color: item.color,
          category: item.category,
          imeiList: item.imeiList,
          purchasePrice: item.purchaseRate,
          sellingPrice: item.sellingRateTarget || (item.purchaseRate * 1.15),
          currentStock: item.quantity,
          minStockAlert: 2,
          warrantyMonths: 12,
          createdAt: getTodayDateString(),
          updatedAt: getTodayDateString()
        };
        await dbManager.put('products', freshP);
        updatedProducts.unshift(freshP);
      }
    }
    setProducts(updatedProducts);

    // Update supplier ledger
    const supp = suppliers.find(s => s.id === billData.supplierId);
    if (supp) {
      const updatedSupp: Supplier = {
        ...supp,
        totalPurchased: supp.totalPurchased + billData.grandTotal,
        totalPaid: supp.totalPaid + billData.paidAmount,
        pendingBalance: supp.pendingBalance + billData.pendingAmount
      };
      await dbManager.put('suppliers', updatedSupp);
      setSuppliers(prev => prev.map(s => (s.id === updatedSupp.id ? updatedSupp : s)));
    }
    sounds.playSuccessChime();
  };

  // EMI Records
  const createEMIRecord = async (record: Omit<EMIRecord, 'id' | 'createdAt'>) => {
    const newEMI: EMIRecord = {
      ...record,
      id: `emi-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    await dbManager.put('emiRecords', newEMI);
    setEmiRecords(prev => [newEMI, ...prev]);
    sounds.playSuccessChime();
  };

  const payEMIInstallment = async (emiId: string, installmentIndex: number, mode: string) => {
    const record = emiRecords.find(e => e.id === emiId);
    if (!record) return;

    const updatedInstallments = [...record.installments];
    if (updatedInstallments[installmentIndex]) {
      updatedInstallments[installmentIndex] = {
        ...updatedInstallments[installmentIndex],
        status: 'paid',
        paidDate: getTodayDateString(),
        paymentMode: mode,
        receiptNumber: `EMIPAY-${Date.now().toString().slice(-6)}`
      };
    }

    const paidCount = updatedInstallments.filter(i => i.status === 'paid').length;
    const isAllPaid = paidCount === record.totalInstallments;

    // calculate next due date
    const nextPending = updatedInstallments.find(i => i.status === 'pending');

    const updatedRecord: EMIRecord = {
      ...record,
      paidInstallments: paidCount,
      nextDueDate: nextPending ? nextPending.dueDate : 'All Paid',
      status: isAllPaid ? 'completed' : 'active',
      installments: updatedInstallments
    };

    await dbManager.put('emiRecords', updatedRecord);
    setEmiRecords(prev => prev.map(e => (e.id === emiId ? updatedRecord : e)));
    sounds.playSuccessChime();
  };

  // Exchange & Used Stock
  const recordExchange = async (data: Omit<ExchangeRecord, 'id'>) => {
    const newExchange: ExchangeRecord = {
      ...data,
      id: `exch-${Date.now()}`
    };

    // Also automatically create a Used Mobile Stock entry!
    const usedProduct: Product = {
      id: `prod-used-${Date.now()}`,
      name: `${data.oldBrand} ${data.oldModel} (Used/Exchange)`,
      brand: data.oldBrand,
      model: data.oldModel,
      imeiList: data.oldImei ? [data.oldImei] : [],
      category: 'exchanged_phone',
      isUsed: true,
      isExchange: true,
      purchasePrice: data.totalExchangeValue,
      sellingPrice: Math.round(data.totalExchangeValue * 1.25),
      currentStock: 1,
      minStockAlert: 1,
      warrantyMonths: 1,
      notes: `Exchanged from ${data.customerName} (${data.customerPhone}). Condition: ${data.condition}`,
      createdAt: getTodayDateString(),
      updatedAt: getTodayDateString()
    };

    newExchange.usedStockProductId = usedProduct.id;

    await dbManager.put('products', usedProduct);
    setProducts(prev => [usedProduct, ...prev]);

    await dbManager.put('exchangeRecords', newExchange);
    setExchangeRecords(prev => [newExchange, ...prev]);
    sounds.playSuccessChime();
  };

  // Repairs
  const createRepairJob = async (jobData: Omit<RepairJob, 'id'>) => {
    const newJob: RepairJob = {
      ...jobData,
      id: `rep-${Date.now()}`
    };
    await dbManager.put('repairJobs', newJob);
    setRepairJobs(prev => [newJob, ...prev]);
    sounds.playSuccessChime();
  };

  const updateRepairJobStatus = async (id: string, status: RepairJob['status'], deliveredDate?: string) => {
    const job = repairJobs.find(r => r.id === id);
    if (!job) return;

    const updatedJob: RepairJob = {
      ...job,
      status,
      actualDeliveredDate: deliveredDate || (status === 'Delivered' ? getTodayDateString() : job.actualDeliveredDate)
    };
    await dbManager.put('repairJobs', updatedJob);
    setRepairJobs(prev => prev.map(r => (r.id === id ? updatedJob : r)));
  };

  const payRepairRemaining = async (id: string, amountPaid: number) => {
    const job = repairJobs.find(r => r.id === id);
    if (!job) return;

    const newAdvance = job.advancePaid + amountPaid;
    const newRemaining = Math.max(0, job.repairCharges - newAdvance);

    const updatedJob: RepairJob = {
      ...job,
      advancePaid: newAdvance,
      remainingAmount: newRemaining
    };
    await dbManager.put('repairJobs', updatedJob);
    setRepairJobs(prev => prev.map(r => (r.id === id ? updatedJob : r)));
    sounds.playSuccessChime();
  };

  // Expenses
  const addExpense = async (expenseData: Omit<Expense, 'id'>) => {
    const newExp: Expense = {
      ...expenseData,
      id: `exp-${Date.now()}`
    };
    await dbManager.put('expenses', newExp);
    setExpenses(prev => [newExp, ...prev]);
  };

  const deleteExpense = async (id: string) => {
    await dbManager.delete('expenses', id);
    setExpenses(prev => prev.filter(e => e.id !== id));
  };

  // Backup & Reset
  const exportBackup = async (): Promise<AppDatabaseData> => {
    return await dbManager.exportFullBackup();
  };

  const restoreBackup = async (data: Partial<AppDatabaseData>) => {
    await dbManager.restoreBackup(data);
    await reloadData();
  };

  const resetToDemoData = async () => {
    await dbManager.resetToDemoData();
    await reloadData();
  };

  return (
    <ERPContext.Provider
      value={{
        isLoading,
        products,
        invoices,
        customers,
        customerPayments,
        suppliers,
        purchases,
        emiRecords,
        exchangeRecords,
        repairJobs,
        expenses,
        settings,
        isLocked,
        activeTab,
        setActiveTab,
        setIsLocked,
        updateSettings,
        addProduct,
        updateProduct,
        deleteProduct,
        isImeiAvailable,
        adjustStockQuantity,
        createInvoice,
        cancelInvoice,
        addCustomer,
        updateCustomer,
        recordCustomerPayment,
        addSupplier,
        createPurchaseBill,
        createEMIRecord,
        payEMIInstallment,
        recordExchange,
        createRepairJob,
        updateRepairJobStatus,
        payRepairRemaining,
        addExpense,
        deleteExpense,
        exportBackup,
        restoreBackup,
        resetToDemoData
      }}
    >
      {children}
    </ERPContext.Provider>
  );
};

export const useERP = () => {
  const context = useContext(ERPContext);
  if (!context) {
    throw new Error('useERP must be used within ERPProvider');
  }
  return context;
};
