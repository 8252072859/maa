import React, { createContext, useContext, useState, useEffect } from 'react';

interface AdminUser {
  phone: string;
  role: 'admin';
  shopName: string;
}

export interface SendOtpResponse {
  success: boolean;
  channel: 'whatsapp' | 'sms';
  message: string;
  whatsappUrl?: string;
  expiresInSeconds?: number;
  resendCooldown?: number;
}

interface AuthContextType {
  isAuthenticated: boolean;
  isLoading: boolean;
  adminUser: AdminUser | null;
  sendOtp: (phone: string, channel?: 'whatsapp' | 'sms') => Promise<SendOtpResponse>;
  verifyOtp: (phone: string, otp: string) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
const apiUrl = (path: string) => `${API_BASE_URL}${path}`;

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);

  // Check existing session token on mount
  useEffect(() => {
    const checkSession = async () => {
      const token = sessionStorage.getItem('mde_admin_token');
      if (!token) {
        setIsLoading(false);
        return;
      }

      try {
        const res = await fetch(apiUrl('/api/auth/session'), {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        if (res.ok) {
          const data = await res.json();
          if (data.authenticated && data.user) {
            setIsAuthenticated(true);
            setAdminUser(data.user);
          } else {
            sessionStorage.removeItem('mde_admin_token');
          }
        } else {
          sessionStorage.removeItem('mde_admin_token');
        }
      } catch (err) {
        console.error('Session verification error:', err);
      } finally {
        setIsLoading(false);
      }
    };

    checkSession();
  }, []);

  const sendOtp = async (phone: string, channel: 'whatsapp' | 'sms' = 'whatsapp'): Promise<SendOtpResponse> => {
    const res = await fetch(apiUrl('/api/auth/send-otp'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, channel })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to send OTP.');
    }
    return data;
  };

  const verifyOtp = async (phone: string, otp: string) => {
    const res = await fetch(apiUrl('/api/auth/verify-otp'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, otp })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Verification failed.');
    }

    if (data.token) {
      sessionStorage.setItem('mde_admin_token', data.token);
      setIsAuthenticated(true);
      setAdminUser(data.user);
    }
    return data;
  };

  const logout = async () => {
    const token = sessionStorage.getItem('mde_admin_token');
    if (token) {
      try {
        await fetch(apiUrl('/api/auth/logout'), {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}` }
        });
      } catch {}
      sessionStorage.removeItem('mde_admin_token');
    }
    setIsAuthenticated(false);
    setAdminUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isLoading,
        adminUser,
        sendOtp,
        verifyOtp,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
