import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'hi' | 'en';

interface Translations {
  [key: string]: {
    hi: string;
    en: string;
  };
}

export const translations: Translations = {
  // Navigation
  dashboard: { hi: "डैशबोर्ड", en: "Dashboard" },
  newBill: { hi: "नया बिल (F2)", en: "New Bill (F2)" },
  billsHistory: { hi: "बिक्री बिल सूची", en: "Bills History" },
  stock: { hi: "स्टॉक प्रबंधन", en: "Stock Management" },
  purchases: { hi: "खरीदारी / सप्लायर", en: "Purchases & Suppliers" },
  udhaarKhata: { hi: "ग्राहक उधार खाता", en: "Customer Udhaar" },
  emiFinance: { hi: "EMI एवं फाइनेंस", en: "EMI & Finance" },
  exchange: { hi: "पुराना मोबाइल एक्सचेंज", en: "Exchange & Used" },
  repairs: { hi: "रिपेयरिंग जॉब्स", en: "Mobile Repairs" },
  expenses: { hi: "दुकान खर्च", en: "Shop Expenses" },
  reports: { hi: "रिपोर्ट्स और मुनाफा", en: "Reports & Profit" },
  settings: { hi: "सेटिंग्स व बैकअप", en: "Settings & Backup" },

  // Dashboard Metrics
  todaySales: { hi: "आज की कुल बिक्री", en: "Today's Total Sales" },
  todayProfit: { hi: "आज का शुद्ध मुनाफा", en: "Today's Net Profit" },
  totalPurchases: { hi: "कुल खरीदारी", en: "Total Purchases" },
  totalCustomers: { hi: "कुल ग्राहक", en: "Total Customers" },
  totalMobileStock: { hi: "कुल मोबाइल स्टॉक", en: "Total Mobile Stock" },
  totalStockValue: { hi: "स्टॉक खरीद मूल्य", en: "Stock Purchase Valuation" },
  totalUdhaar: { hi: "कुल बकाया उधार", en: "Total Pending Udhaar" },
  todayReceived: { hi: "आज प्राप्त पेमेंट", en: "Today's Received Payment" },
  pendingEmi: { hi: "Pending EMI", en: "Pending EMI" },
  activeWarranty: { hi: "वारंटी में मोबाइल", en: "Active Warranty Mobiles" },
  pendingRepairs: { hi: "Pending रिपेयर", en: "Pending Repairs" },
  lowStockAlert: { hi: "लो स्टॉक चेतावनी", en: "Low Stock Alert" },

  // Billing
  customerDetails: { hi: "ग्राहक विवरण", en: "Customer Details" },
  customerName: { hi: "ग्राहक का नाम", en: "Customer Name" },
  mobileNumber: { hi: "मोबाइल नंबर", en: "Mobile Number" },
  address: { hi: "पता", en: "Address" },
  invoiceNo: { hi: "बिल संख्या", en: "Invoice No." },
  billDate: { hi: "बिल दिनांक", en: "Bill Date" },
  searchProduct: { hi: "उत्पाद या IMEI सर्च करें...", en: "Search Product or IMEI..." },
  addProduct: { hi: "उत्पाद जोड़ें", en: "Add Product" },
  imei1: { hi: "IMEI 1", en: "IMEI 1" },
  imei2: { hi: "IMEI 2", en: "IMEI 2" },
  serialNo: { hi: "सीरियल नंबर", en: "Serial No." },
  rate: { hi: "दर (कीमत)", en: "Rate" },
  qty: { hi: "मात्रा", en: "Qty" },
  discount: { hi: "छूट (₹)", en: "Discount (₹)" },
  amount: { hi: "कुल रकम", en: "Amount" },
  subtotal: { hi: "उप-योग (Subtotal)", en: "Subtotal" },
  grandTotal: { hi: "कुल देय राशि (Grand Total)", en: "Grand Total" },
  paymentMode: { hi: "भुगतान का तरीका", en: "Payment Mode" },
  paidAmount: { hi: "प्राप्त राशि", en: "Paid Amount" },
  remainingDue: { hi: "बकाया राशि (उधार)", en: "Remaining Udhaar" },
  saveAndPrint: { hi: "बिल सेव और प्रिंट करें", en: "Save & Print Bill" },
  scanImei: { hi: "IMEI स्कैन करें", en: "Scan IMEI" },
  
  // Actions
  save: { hi: "सुरक्षित करें", en: "Save" },
  cancel: { hi: "रद्द करें", en: "Cancel" },
  print: { hi: "प्रिंट करें", en: "Print" },
  downloadPdf: { hi: "PDF डाउनलोड", en: "Download PDF" },
  whatsappShare: { hi: "WhatsApp शेयर", en: "Share on WhatsApp" },
  edit: { hi: "संपादित करें", en: "Edit" },
  delete: { hi: "हटाएं", en: "Delete" },
  search: { hi: "खोजें...", en: "Search..." },
  filter: { hi: "फ़िल्टर", en: "Filter" },
  exportCsv: { hi: "CSV / Excel निर्यात", en: "Export CSV / Excel" },
  backupData: { hi: "डेटा बैकअप लें", en: "Backup JSON" },
  restoreData: { hi: "डेटा रीस्टोर करें", en: "Restore JSON" },
  lockApp: { hi: "ऐप लॉक करें", en: "Lock App" },

  // General
  all: { hi: "सभी", en: "All" },
  inStock: { hi: "उपलब्ध", en: "In Stock" },
  outOfStock: { hi: "समाप्त", en: "Out of Stock" },
  cash: { hi: "नकद (Cash)", en: "Cash" },
  upi: { hi: "UPI (GPay / PhonePe / Paytm)", en: "UPI" },
  card: { hi: "डेबिट / क्रेडिट कार्ड", en: "Card" },
  bank: { hi: "बैंक ट्रांसफर", en: "Bank Transfer" },
  udhar: { hi: "उधार (Credit)", en: "Udhar (Credit)" },
  split: { hi: "मिश्रित भुगतान (Split)", en: "Split Payment" },
  brand: { hi: "ब्रांड", en: "Brand" },
  model: { hi: "मॉडल", en: "Model" },
  status: { hi: "स्थिति", en: "Status" }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof typeof translations) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('mde_language');
      return (saved === 'en' || saved === 'hi') ? saved : 'hi';
    } catch {
      return 'hi';
    }
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('mde_language', lang);
    } catch {}
  };

  const t = (key: keyof typeof translations): string => {
    if (translations[key]) {
      return translations[key][language] || translations[key].en;
    }
    return String(key);
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
};
