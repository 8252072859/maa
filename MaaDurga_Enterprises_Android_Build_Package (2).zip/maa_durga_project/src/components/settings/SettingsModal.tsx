import React, { useState } from 'react';
import {
  Settings,
  X,
  Save,
  Download,
  Upload,
  RotateCcw,
  Shield,
  Languages,
  CheckCircle2,
  AlertTriangle,
  Store,
  QrCode
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { ShopSettings } from '../../types/erp';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { settings, updateSettings, exportBackup, restoreBackup, resetToDemoData } = useERP();
  const { language, setLanguage, t } = useLanguage();

  const [formState, setFormState] = useState<ShopSettings>({ ...settings });
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings(formState);
    setSuccessMsg('Settings saved successfully!');
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleDownloadBackup = async () => {
    const data = await exportBackup();
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `MaaDurga_ERP_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (confirm('Are you sure you want to restore from this backup file? Existing records will be replaced.')) {
          await restoreBackup(parsed);
          setSuccessMsg('Backup restored successfully!');
          setTimeout(() => setSuccessMsg(null), 3000);
        }
      } catch (err) {
        alert('Invalid JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  const handleResetDemo = async () => {
    if (confirm('Reset database to demo showroom data? All custom entries will be reset to default sample showroom inventory.')) {
      setIsResetting(true);
      await resetToDemoData();
      setIsResetting(false);
      setSuccessMsg('Reset to demo showroom data complete!');
      setTimeout(() => setSuccessMsg(null), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[94vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 font-royal">
                ERP Settings, Shop Profile & Data Backup
              </h3>
              <p className="text-[11px] text-slate-400">
                GSTIN, UPI QR Code, Invoice Prefix, PIN Security & Offline JSON Sync.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {successMsg && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Section 1: Shop Profile */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-amber-400 uppercase tracking-wider text-[11px] font-royal flex items-center gap-1.5">
              <Store className="w-4 h-4" /> 1. SHOWROOM IDENTITY & CONTACT
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Shop Name *</label>
                <input
                  type="text"
                  required
                  value={formState.shopName}
                  onChange={(e) => setFormState({ ...formState, shopName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Tagline</label>
                <input
                  type="text"
                  value={formState.shopTagline}
                  onChange={(e) => setFormState({ ...formState, shopTagline: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Owner Name</label>
                <input
                  type="text"
                  value={formState.ownerName}
                  onChange={(e) => setFormState({ ...formState, ownerName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Primary Phone *</label>
                <input
                  type="tel"
                  required
                  value={formState.phone}
                  onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Alternate Phone</label>
                <input
                  type="tel"
                  value={formState.altPhone || ''}
                  onChange={(e) => setFormState({ ...formState, altPhone: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-slate-300 font-semibold mb-1">Shop Address</label>
                <input
                  type="text"
                  value={formState.address}
                  onChange={(e) => setFormState({ ...formState, address: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">City, State & Pincode</label>
                <input
                  type="text"
                  value={`${formState.city}, ${formState.state} - ${formState.pincode}`}
                  onChange={(e) => {
                    const parts = e.target.value.split(',');
                    setFormState({
                      ...formState,
                      city: parts[0] ? parts[0].trim() : formState.city
                    });
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                />
              </div>
            </div>
          </div>

          {/* Section 2: GSTIN, Dynamic UPI QR & Invoice Settings */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-amber-400 uppercase tracking-wider text-[11px] font-royal flex items-center gap-1.5">
              <QrCode className="w-4 h-4" /> 2. GST & DYNAMIC UPI PAYMENT QR
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Shop GSTIN</label>
                <input
                  type="text"
                  placeholder="e.g. 10ABCDE1234F1Z5"
                  value={formState.gstin}
                  onChange={(e) => setFormState({ ...formState, gstin: e.target.value.toUpperCase() })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Shop UPI VPA ID (For Dynamic QR) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. maadurga@okaxis or 9876543210@paytm"
                  value={formState.upiId}
                  onChange={(e) => setFormState({ ...formState, upiId: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code font-semibold"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Invoice Prefix</label>
                <input
                  type="text"
                  value={formState.invoicePrefix}
                  onChange={(e) => setFormState({ ...formState, invoicePrefix: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Invoice Warranty Policy Terms</label>
              <textarea
                rows={3}
                value={formState.invoiceTerms}
                onChange={(e) => setFormState({ ...formState, invoiceTerms: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
              />
            </div>
          </div>

          {/* Section 3: POS PIN Lock Security & Roles */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-amber-400 uppercase tracking-wider text-[11px] font-royal flex items-center gap-1.5">
              <Shield className="w-4 h-4" /> 3. SECURITY PIN LOCK & ROLE
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Enable 4-Digit PIN Lock</label>
                <select
                  value={formState.pinLockEnabled ? 'true' : 'false'}
                  onChange={(e) => setFormState({ ...formState, pinLockEnabled: e.target.value === 'true' })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-semibold"
                >
                  <option value="false">Disabled (Open POS)</option>
                  <option value="true">Enabled (Require 4-digit PIN)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">4-Digit Security PIN</label>
                <input
                  type="password"
                  maxLength={4}
                  value={formState.pinCode}
                  onChange={(e) => setFormState({ ...formState, pinCode: e.target.value.replace(/[^0-9]/g, '') })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code font-bold tracking-widest text-center"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Active User Role</label>
                <select
                  value={formState.userRole}
                  onChange={(e) => setFormState({ ...formState, userRole: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-semibold"
                >
                  <option value="admin">Admin (Showroom Owner)</option>
                  <option value="staff">Staff / Billing Counter</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 4: JSON Backup & Reset Database */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <h4 className="font-bold text-amber-400 uppercase tracking-wider text-[11px] font-royal flex items-center gap-1.5">
              <Download className="w-4 h-4" /> 4. DATABASE BACKUP, RESTORE & DEMO SEEDING
            </h4>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              All inventory, customers, IMEIs, invoices and khata are safely saved locally in IndexedDB. You can export a full JSON backup anytime or restore onto a new laptop/tablet.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold flex items-center gap-1.5 transition"
              >
                <Download className="w-4 h-4 text-amber-400" />
                <span>Download JSON Backup</span>
              </button>

              <label className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold flex items-center gap-1.5 cursor-pointer transition">
                <Upload className="w-4 h-4 text-blue-400" />
                <span>Restore JSON Backup</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileRestore}
                  className="hidden"
                />
              </label>

              <button
                type="button"
                onClick={handleResetDemo}
                disabled={isResetting}
                className="px-4 py-2 rounded-xl bg-red-950/40 hover:bg-red-950/70 text-red-300 border border-red-500/30 font-semibold flex items-center gap-1.5 transition ml-auto"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{isResetting ? 'Resetting...' : 'Load Sample Showroom Data'}</span>
              </button>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-semibold"
            >
              Close
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20"
            >
              Save ERP Settings
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
