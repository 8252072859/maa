import React, { useState } from 'react';
import {
  WalletCards,
  Plus,
  Trash2,
  Calendar,
  Coins,
  FileSpreadsheet
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { Expense } from '../../types/erp';
import { formatCurrency, formatDate, getTodayDateString, exportToCSV } from '../../utils/formatters';

export const ExpenseManagement: React.FC = () => {
  const { expenses, addExpense, deleteExpense } = useERP();
  const { t } = useLanguage();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [category, setCategory] = useState<Expense['category']>('Shop Rent');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<Expense['paymentMode']>('cash');
  const [date, setDate] = useState(getTodayDateString());
  const [notes, setNotes] = useState('');

  // Total expenses
  const totalExpensesAllTime = expenses.reduce((sum, e) => sum + e.amount, 0);

  // Today's expenses
  const todayStr = getTodayDateString();
  const todayExpenses = expenses.filter(e => e.date === todayStr).reduce((sum, e) => sum + e.amount, 0);

  // Group by category for breakdown
  const categoryTotals: Record<string, number> = {};
  expenses.forEach((e) => {
    categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
  });

  const handleCreateExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amount <= 0) return;

    await addExpense({
      date,
      category,
      title: title.trim(),
      amount,
      paymentMode,
      notes: notes.trim() || undefined
    });

    setIsModalOpen(false);
    setTitle('');
    setAmount(0);
    setNotes('');
  };

  const handleExportCSV = () => {
    const rows = expenses.map((e) => ({
      'Date': e.date,
      'Category': e.category,
      'Title': e.title,
      'Amount': e.amount,
      'Payment Mode': e.paymentMode,
      'Notes': e.notes || ''
    }));
    exportToCSV('MaaDurga_Expenses', rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <WalletCards className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('expenses')} (SHOP OVERHEADS)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Rent, staff salaries, electricity, spare parts and refreshment expenditures.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>Add Shop Expense</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Today's Expenses</span>
          <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono-code mt-1">
            {formatCurrency(todayExpenses)}
          </div>
          <span className="text-[10px] text-slate-500">Deducted from today's net profit</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Recorded Expenses</span>
          <div className="text-xl sm:text-2xl font-black text-rose-400 font-mono-code mt-1">
            {formatCurrency(totalExpensesAllTime)}
          </div>
          <span className="text-[10px] text-slate-500">{expenses.length} Expense Vouchers</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-400">Expense Reports</span>
          <button
            onClick={handleExportCSV}
            className="mt-2 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Expenses CSV</span>
          </button>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
        {expenses.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No expenses recorded yet. Click 'Add Shop Expense' to log overhead costs.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Description / Title</th>
                  <th className="p-3.5 text-center">Payment Mode</th>
                  <th className="p-3.5 text-right">Amount</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-code">
                {expenses.map((exp) => (
                  <tr key={exp.id} className="hover:bg-slate-800/30">
                    <td className="p-3.5 text-slate-400 font-sans">
                      {formatDate(exp.date)}
                    </td>

                    <td className="p-3.5 font-sans font-bold text-amber-300">
                      {exp.category}
                    </td>

                    <td className="p-3.5 font-sans text-slate-200">
                      <div>{exp.title}</div>
                      {exp.notes && <div className="text-[10px] text-slate-500">{exp.notes}</div>}
                    </td>

                    <td className="p-3.5 text-center uppercase text-[11px] text-slate-300">
                      {exp.paymentMode}
                    </td>

                    <td className="p-3.5 text-right font-black text-rose-400">
                      - {formatCurrency(exp.amount)}
                    </td>

                    <td className="p-3.5 text-right font-sans">
                      <button
                        onClick={() => deleteExpense(exp.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-slate-800 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ADD EXPENSE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl p-6 shadow-2xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-100 font-royal">
              Record Shop Expense
            </h3>

            <form onSubmit={handleCreateExpense} className="space-y-3">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Expense Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                >
                  <option value="Shop Rent">Shop Monthly Rent</option>
                  <option value="Electricity Bill">Electricity Bill</option>
                  <option value="Staff Salary">Staff / Helper Salary</option>
                  <option value="Repair Spares & Tools">Repair Spares & Tools</option>
                  <option value="Transport & Courier">Transport & Courier Charges</option>
                  <option value="Tea & Refreshment">Tea & Customer Refreshment</option>
                  <option value="Marketing & Ads">Marketing & Banner Printing</option>
                  <option value="Other Expenses">Miscellaneous / Other</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Expense Title / Description *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. October Rent / Display Folder for stock"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Amount (₹) *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code font-bold"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Payment Mode</label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  >
                    <option value="cash">Cash</option>
                    <option value="upi">UPI</option>
                    <option value="bank">Bank</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
