import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  variant?: 'gold' | 'blue' | 'emerald' | 'amber' | 'rose' | 'slate';
  onClick?: () => void;
  badge?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  variant = 'slate',
  onClick,
  badge
}) => {
  const variantStyles = {
    gold: {
      border: 'border-amber-500/30 hover:border-amber-400',
      bgGlow: 'bg-amber-500/5',
      iconBg: 'bg-amber-500/15 text-amber-300',
      textHighlight: 'text-amber-200'
    },
    blue: {
      border: 'border-blue-500/30 hover:border-blue-400',
      bgGlow: 'bg-blue-500/5',
      iconBg: 'bg-blue-500/15 text-blue-300',
      textHighlight: 'text-blue-100'
    },
    emerald: {
      border: 'border-emerald-500/30 hover:border-emerald-400',
      bgGlow: 'bg-emerald-500/5',
      iconBg: 'bg-emerald-500/15 text-emerald-300',
      textHighlight: 'text-emerald-100'
    },
    amber: {
      border: 'border-yellow-500/30 hover:border-yellow-400',
      bgGlow: 'bg-yellow-500/5',
      iconBg: 'bg-yellow-500/15 text-yellow-300',
      textHighlight: 'text-yellow-100'
    },
    rose: {
      border: 'border-rose-500/30 hover:border-rose-400',
      bgGlow: 'bg-rose-500/5',
      iconBg: 'bg-rose-500/15 text-rose-300',
      textHighlight: 'text-rose-100'
    },
    slate: {
      border: 'border-slate-800 hover:border-slate-700',
      bgGlow: 'bg-slate-900/40',
      iconBg: 'bg-slate-800 text-slate-300',
      textHighlight: 'text-slate-100'
    }
  };

  const style = variantStyles[variant];

  return (
    <div
      onClick={onClick}
      className={`relative p-4 rounded-2xl bg-[#0d1322] border transition-all duration-200 ${
        style.border
      } ${style.bgGlow} ${onClick ? 'cursor-pointer active:scale-[0.99]' : ''} shadow-sm flex flex-col justify-between`}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <span className="text-xs font-semibold text-slate-400 leading-tight">
          {title}
        </span>
        <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${style.iconBg}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>

      <div>
        <div className="flex items-baseline gap-2">
          <span className={`text-xl sm:text-2xl font-extrabold tracking-tight font-mono-code ${style.textHighlight}`}>
            {value}
          </span>
          {badge && (
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30">
              {badge}
            </span>
          )}
        </div>
        {subtitle && (
          <p className="text-[11px] text-slate-500 mt-1 truncate">
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
};
