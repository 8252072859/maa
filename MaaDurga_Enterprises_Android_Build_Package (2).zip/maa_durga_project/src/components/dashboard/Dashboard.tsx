import React, { useState } from 'react';
import {
  TrendingUp,
  Receipt,
  Truck,
  Users,
  Smartphone,
  Coins,
  BookOpen,
  CreditCard,
  Landmark,
  ShieldCheck,
  Wrench,
  AlertTriangle,
  PlusCircle,
  ScanLine,
  FileSpreadsheet,
  ArrowRight,
  Printer,
  Share2,
  CheckCircle2,
  Clock,
  Download,
  QrCode,
  FileCode,
  Sparkles
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { MetricCard } from './MetricCard';
import { formatCurrency, formatDate, getTodayDateString, buildWhatsAppBillUrl, exportToCSV } from '../../utils/formatters';
import { BillPrintModal } from '../billing/BillPrintModal';
import { ImeiScannerModal } from '../common/ImeiScannerModal';
import { ApkInstallModal } from '../common/ApkInstallModal';
import { Invoice } from '../../types/erp';

export const Dashboard: React.FC = () => {
  const {
    products,
    invoices,
    customers,
    customerPayments,
    purchases,
    emiRecords,
    repairJobs,
    expenses,
    setActiveTab,
    isImeiAvailable
  } = useERP();
  const { t } = useLanguage();

  const [selectedInvoiceForPrint, setSelectedInvoiceForPrint] = useState<Invoice | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scanResultNotice, setScanResultNotice] = useState<string | null>(null);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  const todayStr = getTodayDateString();

  // 1. Today's Total Sales
  const todayInvoices = invoices.filter(inv => !inv.isCancelled && inv.date === todayStr);
  const todaySalesAmount = todayInvoices.reduce((sum, inv) => sum + inv.grandTotal, 0);

  // 2. Today's Real Profit
  // Item profit = item.amount - (item.purchasePrice * item.quantity)
  let todayGrossProfit = 0;
  todayInvoices.forEach(inv => {
    inv.items.forEach(item => {
      const itemCost = (item.purchasePrice || 0) * item.quantity;
      todayGrossProfit += (item.amount - itemCost);
    });
  });
  // Deduct today's expenses
  const todayExpensesSum = expenses
    .filter(exp => exp.date === todayStr)
    .reduce((sum, exp) => sum + exp.amount, 0);
  const todayNetProfit = Math.max(0, todayGrossProfit - todayExpensesSum);

  // 3. Total Purchases
  const totalPurchasesAmount = purchases.reduce((sum, p) => sum + p.grandTotal, 0);

  // 4. Total Customers
  const totalCustomersCount = customers.length;

  // 5. Total Mobile Stock (smartphones + feature + used)
  const mobileStockCount = products
    .filter(p => ['smartphone', 'feature_phone', 'used_phone', 'exchanged_phone'].includes(p.category))
    .reduce((sum, p) => sum + p.currentStock, 0);

  // 6. Total Stock Valuation at Purchase Price
  const totalStockValuation = products.reduce((sum, p) => sum + (p.currentStock * p.purchasePrice), 0);

  // 7. Total Udhaar from Customers
  const totalUdhaarAmount = customers.reduce((sum, c) => sum + (c.currentUdhaar || 0), 0);

  // 8. Today's Received Payment (Invoice paid amounts today + standalone udhaar receipts today)
  const todayInvoicePaid = todayInvoices.reduce((sum, inv) => sum + inv.paidAmount, 0);
  const todayCustomerReceipts = customerPayments
    .filter(cp => cp.date === todayStr)
    .reduce((sum, cp) => sum + cp.amount, 0);
  const todayTotalReceived = todayInvoicePaid + todayCustomerReceipts;

  // 9. Pending EMI
  let pendingEmiCount = 0;
  let pendingEmiAmount = 0;
  emiRecords
    .filter(e => e.status === 'active')
    .forEach(e => {
      e.installments
        .filter(i => i.status === 'pending')
        .forEach(inst => {
          pendingEmiCount += 1;
          pendingEmiAmount += inst.amount;
        });
    });

  // 10. Active Warranty Mobiles
  const oneYearAgo = new Date();
  oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
  const activeWarrantyCount = invoices
    .filter(inv => !inv.isCancelled && new Date(inv.date) >= oneYearAgo)
    .reduce((sum, inv) => sum + inv.items.filter(item => ['smartphone', 'feature_phone'].includes(item.category || '')).length, 0);

  // 11. Pending Repairs
  const pendingRepairs = repairJobs.filter(r => r.status !== 'Delivered');
  const pendingRepairsCount = pendingRepairs.length;

  // 12. Low Stock Alerts
  const lowStockItems = products.filter(p => p.currentStock <= p.minStockAlert);
  const lowStockCount = lowStockItems.length;

  // Quick scanner handler
  const handleScanImei = (scanned: string) => {
    const check = isImeiAvailable(scanned);
    if (!check.available) {
      setScanResultNotice(`⚠️ SOLD: ${check.reason}`);
    } else if (check.product) {
      setScanResultNotice(`✅ IN STOCK: ${check.product.brand} ${check.product.name} (Selling: ${formatCurrency(check.product.sellingPrice)})`);
    } else {
      setScanResultNotice(`ℹ️ Scanned IMEI: ${scanned} (Not yet cataloged in inventory)`);
    }
  };

  const handleExportQuickBills = () => {
    const rows = invoices.map(i => ({
      'Invoice No': i.invoiceNumber,
      'Date': i.date,
      'Customer Name': i.customerName,
      'Customer Phone': i.customerPhone,
      'Total Amount': i.grandTotal,
      'Paid Amount': i.paidAmount,
      'Due Balance': i.dueAmount,
      'Payment Mode': i.paymentMode,
      'Status': i.isCancelled ? 'CANCELLED' : 'ACTIVE'
    }));
    exportToCSV(`MaaDurga_Sales_${todayStr}`, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-amber-400 font-royal font-black text-xl">🔱</span>
            <span className="text-xs uppercase tracking-widest text-amber-300 font-bold font-royal">
              MAA DURGA ENTERPRISES
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-100 tracking-tight">
            Mobile Showroom Control Center
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Live inventory, dual IMEI tracking, automated customer khata, and instant tax/thermal billing.
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 relative z-10">
          <button
            onClick={() => setActiveTab('new-bill')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-amber-500/25 active:scale-95 transition"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t('newBill')}</span>
          </button>

          <button
            onClick={() => setIsScannerOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs sm:text-sm active:scale-95 transition"
          >
            <ScanLine className="w-4 h-4 text-amber-400" />
            <span>{t('scanImei')}</span>
          </button>

          <button
            onClick={handleExportQuickBills}
            className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs sm:text-sm active:scale-95 transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Export Excel</span>
          </button>
        </div>
      </div>

      {/* Notice on scan result */}
      {scanResultNotice && (
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-amber-500/40 text-xs text-slate-200 flex items-center justify-between">
          <span className="font-mono-code">{scanResultNotice}</span>
          <button
            onClick={() => setScanResultNotice(null)}
            className="text-slate-400 hover:text-white font-bold ml-4"
          >
            ✕
          </button>
        </div>
      )}

      {/* DEDICATED PROMINENT ANDROID APK CARD ("APK FILE KO UPAR KARO") */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-emerald-950/90 via-[#0d1629] to-amber-950/90 border-2 border-amber-400/80 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-4 select-none">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-amber-400 p-[2px] shadow-lg shadow-emerald-500/20 shrink-0">
            <div className="w-full h-full bg-[#070b14] rounded-[14px] flex items-center justify-center text-emerald-400 text-2xl font-bold">
              📲
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-sm sm:text-base font-black text-amber-200 uppercase tracking-wide font-royal">
                MAA DURGA ENTERPRISES ANDROID APK
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold font-mono-code">
                APK build required before installation
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              अपने मोबाइल या शोरूम टैबलेट में बिलिंग ऐप इनस्टॉल करें (Offline & IMEI Scanner Supported).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto justify-end flex-wrap">
          <a
            href="#android-apk-build-required"
            onClick={(e) => { e.preventDefault(); setIsApkModalOpen(true); }}
            className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:brightness-110 active:scale-95 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition cursor-pointer"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>APK Build Info</span>
          </a>

          <button
            type="button"
            onClick={() => setIsApkModalOpen(true)}
            className="flex-1 sm:flex-none py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-amber-400/50 text-amber-300 hover:text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <QrCode className="w-4 h-4" />
            <span>QR Code / Direct Install</span>
          </button>
        </div>
      </div>

      {/* 12 SMART DASHBOARD CARDS GRID */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-xs font-bold text-amber-400 uppercase tracking-widest font-royal">
            REAL-TIME FINANCIAL & STOCK METRICS
          </h3>
          <span className="text-[11px] text-slate-500 font-medium">Auto-updated from live ledger</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {/* 1. Today's Sales */}
          <MetricCard
            title={t('todaySales')}
            value={formatCurrency(todaySalesAmount)}
            subtitle={`${todayInvoices.length} Bills Cut Today`}
            icon={TrendingUp}
            variant="gold"
            onClick={() => setActiveTab('bills-history')}
          />

          {/* 2. Today's Profit */}
          <MetricCard
            title={t('todayProfit')}
            value={formatCurrency(todayNetProfit)}
            subtitle={`Gross - Expenses (${formatCurrency(todayExpensesSum)})`}
            icon={Coins}
            variant="emerald"
            onClick={() => setActiveTab('reports')}
          />

          {/* 3. Total Purchases */}
          <MetricCard
            title={t('totalPurchases')}
            value={formatCurrency(totalPurchasesAmount)}
            subtitle={`${purchases.length} Purchase Invoices`}
            icon={Truck}
            variant="blue"
            onClick={() => setActiveTab('purchases')}
          />

          {/* 4. Total Customers */}
          <MetricCard
            title={t('totalCustomers')}
            value={totalCustomersCount}
            subtitle="Registered in Khata"
            icon={Users}
            variant="slate"
            onClick={() => setActiveTab('udhaar')}
          />

          {/* 5. Total Mobile Stock */}
          <MetricCard
            title={t('totalMobileStock')}
            value={`${mobileStockCount} Units`}
            subtitle="Smartphones & Handsets"
            icon={Smartphone}
            variant="blue"
            onClick={() => setActiveTab('stock')}
          />

          {/* 6. Total Stock Valuation at Purchase Price */}
          <MetricCard
            title={t('totalStockValue')}
            value={formatCurrency(totalStockValuation)}
            subtitle="Actual Investment Cost"
            icon={Coins}
            variant="amber"
            onClick={() => setActiveTab('stock')}
          />

          {/* 7. Total Pending Udhaar */}
          <MetricCard
            title={t('totalUdhaar')}
            value={formatCurrency(totalUdhaarAmount)}
            subtitle="Receivable from Market"
            icon={BookOpen}
            variant={totalUdhaarAmount > 0 ? "rose" : "slate"}
            onClick={() => setActiveTab('udhaar')}
          />

          {/* 8. Today's Received Payment */}
          <MetricCard
            title={t('todayReceived')}
            value={formatCurrency(todayTotalReceived)}
            subtitle={`Cash / UPI / Bank Inflows`}
            icon={CreditCard}
            variant="emerald"
            onClick={() => setActiveTab('reports')}
          />

          {/* 9. Pending EMI */}
          <MetricCard
            title={t('pendingEmi')}
            value={formatCurrency(pendingEmiAmount)}
            subtitle={`${pendingEmiCount} Installments Pending`}
            icon={Landmark}
            variant="amber"
            onClick={() => setActiveTab('emi')}
          />

          {/* 10. Active Warranty Mobiles */}
          <MetricCard
            title={t('activeWarranty')}
            value={`${activeWarrantyCount} Mobiles`}
            subtitle="Under Brand Warranty"
            icon={ShieldCheck}
            variant="slate"
            onClick={() => setActiveTab('bills-history')}
          />

          {/* 11. Pending Repairs */}
          <MetricCard
            title={t('pendingRepairs')}
            value={pendingRepairsCount}
            subtitle={pendingRepairsCount > 0 ? "Awaiting Technician" : "All Repaired"}
            icon={Wrench}
            variant={pendingRepairsCount > 0 ? "rose" : "slate"}
            badge={pendingRepairsCount > 0 ? `${pendingRepairsCount} Pending` : undefined}
            onClick={() => setActiveTab('repairs')}
          />

          {/* 12. Low Stock Alert */}
          <MetricCard
            title={t('lowStockAlert')}
            value={lowStockCount}
            subtitle={lowStockCount > 0 ? "Reorder urgently" : "Healthy Stock Levels"}
            icon={AlertTriangle}
            variant={lowStockCount > 0 ? "rose" : "emerald"}
            badge={lowStockCount > 0 ? "Urgent Reorder" : undefined}
            onClick={() => setActiveTab('stock')}
          />
        </div>
      </div>

      {/* LOWER SECTION: RECENT BILLS & RECENT REPAIRS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Bills (2 Columns) */}
        <div className="lg:col-span-2 rounded-2xl bg-[#0d1322] border border-slate-800 p-5 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-bold text-slate-100">
                  Recent Sales Bills
                </h4>
              </div>
              <button
                onClick={() => setActiveTab('bills-history')}
                className="text-xs font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                View All Bills <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {invoices.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                No invoices recorded yet. Click 'New Bill' to create your first bill.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      <th className="pb-2">Invoice #</th>
                      <th className="pb-2">Customer</th>
                      <th className="pb-2">Product(s)</th>
                      <th className="pb-2 text-right">Amount</th>
                      <th className="pb-2 text-center">Payment</th>
                      <th className="pb-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-xs">
                    {invoices.slice(0, 5).map((inv) => (
                      <tr key={inv.id} className="hover:bg-slate-800/30 transition">
                        <td className="py-3 font-mono-code font-bold text-amber-300">
                          {inv.invoiceNumber}
                          <div className="text-[10px] text-slate-500 font-normal">
                            {formatDate(inv.date)} · {inv.time}
                          </div>
                        </td>
                        <td className="py-3">
                          <div className="font-semibold text-slate-200">{inv.customerName || 'Cash Customer'}</div>
                          <div className="text-[11px] text-slate-400 font-mono-code">{inv.customerPhone}</div>
                        </td>
                        <td className="py-3 max-w-[200px] truncate text-slate-300">
                          {inv.items.map(i => `${i.brand} ${i.productName}`).join(', ')}
                        </td>
                        <td className="py-3 text-right font-mono-code font-bold text-slate-100">
                          {formatCurrency(inv.grandTotal)}
                          {inv.dueAmount > 0 && (
                            <div className="text-[10px] text-red-400 font-normal">
                              Due: {formatCurrency(inv.dueAmount)}
                            </div>
                          )}
                        </td>
                        <td className="py-3 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            inv.paymentMode === 'cash' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' :
                            inv.paymentMode === 'upi' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30' :
                            inv.paymentMode === 'udhar' ? 'bg-red-500/10 text-red-400 border border-red-500/30' :
                            'bg-slate-800 text-slate-300'
                          }`}>
                            {inv.paymentMode}
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedInvoiceForPrint(inv)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                              title="Print Invoice"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            <a
                              href={buildWhatsAppBillUrl(
                                inv.customerPhone,
                                `Namaste ${inv.customerName}, Thank you for purchasing from *MAA DURGA ENTERPRISES*.\n\n*Invoice No:* ${inv.invoiceNumber}\n*Date:* ${inv.date}\n*Amount:* ${formatCurrency(inv.grandTotal)}\n*Paid:* ${formatCurrency(inv.paidAmount)}\n*Balance Due:* ${formatCurrency(inv.dueAmount)}\n\nContact: 9876543210. Visit again!`
                              )}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 transition"
                              title="Share on WhatsApp"
                            >
                              <Share2 className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Pending Repairs Widget (1 Column) */}
        <div className="rounded-2xl bg-[#0d1322] border border-slate-800 p-5 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-blue-400" />
                <h4 className="text-sm font-bold text-slate-100">
                  Active Repair Jobs
                </h4>
              </div>
              <button
                onClick={() => setActiveTab('repairs')}
                className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
              >
                View Jobs <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {pendingRepairs.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs flex flex-col items-center">
                <CheckCircle2 className="w-8 h-8 text-emerald-500/50 mb-2" />
                <span>All repair jobs delivered!</span>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingRepairs.slice(0, 4).map((job) => (
                  <div
                    key={job.id}
                    onClick={() => setActiveTab('repairs')}
                    className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono-code font-bold text-blue-400 text-xs">
                        {job.jobTicketNo}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        {job.status}
                      </span>
                    </div>
                    <div className="font-semibold text-slate-200 text-xs">
                      {job.mobileModel} · {job.customerName}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate mt-0.5">
                      {job.problems.join(', ')}
                    </div>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/80 text-[10px] text-slate-500">
                      <span>Tech: {job.technicianName}</span>
                      <span className="font-mono-code text-slate-300 font-bold">
                        {formatCurrency(job.repairCharges)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bill Print Modal */}
      {selectedInvoiceForPrint && (
        <BillPrintModal
          invoice={selectedInvoiceForPrint}
          onClose={() => setSelectedInvoiceForPrint(null)}
        />
      )}

      {/* IMEI Scanner Modal */}
      <ImeiScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleScanImei}
        title="Check Mobile Stock by IMEI"
      />

      {/* APK Installation & Download Modal */}
      <ApkInstallModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
};
