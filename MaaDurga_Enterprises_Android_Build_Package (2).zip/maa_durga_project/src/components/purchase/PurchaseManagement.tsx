import React, { useState } from 'react';
import {
  Truck,
  Plus,
  Search,
  FileSpreadsheet,
  UserPlus,
  Phone,
  Coins,
  Receipt,
  ScanLine,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { Supplier, PurchaseBill, PurchaseItem, ProductCategory } from '../../types/erp';
import { formatCurrency, formatDate, getTodayDateString, exportToCSV } from '../../utils/formatters';
import { ImeiScannerModal } from '../common/ImeiScannerModal';

export const PurchaseManagement: React.FC = () => {
  const { suppliers, purchases, addSupplier, createPurchaseBill } = useERP();
  const { t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'bills' | 'suppliers'>('bills');
  const [searchTerm, setSearchTerm] = useState('');

  // New Purchase Bill Modal
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [supplierInvoiceNo, setSupplierInvoiceNo] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(getTodayDateString());
  const [purchaseItems, setPurchaseItems] = useState<PurchaseItem[]>([]);

  // Item form inside purchase
  const [itemBrand, setItemBrand] = useState('Samsung');
  const [itemName, setItemName] = useState('');
  const [itemModel, setItemModel] = useState('');
  const [itemRam, setItemRam] = useState('8GB');
  const [itemStorage, setItemStorage] = useState('128GB');
  const [itemColor, setItemColor] = useState('');
  const [itemCategory, setItemCategory] = useState<ProductCategory>('smartphone');
  const [itemRate, setItemRate] = useState<number>(0);
  const [itemTargetSellingRate, setItemTargetSellingRate] = useState<number>(0);
  const [itemImeis, setItemImeis] = useState<string[]>([]);
  const [singleImeiInput, setSingleImeiInput] = useState('');

  // Payment towards purchase
  const [paidToSupplier, setPaidToSupplier] = useState<number>(0);
  const [purchaseNotes, setPurchaseNotes] = useState('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // New Supplier Modal
  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [newSuppName, setNewSuppName] = useState('');
  const [newSuppPhone, setNewSuppPhone] = useState('');
  const [newSuppAddress, setNewSuppAddress] = useState('');
  const [newSuppGstin, setNewSuppGstin] = useState('');

  // Filtered lists
  const filteredPurchases = purchases.filter(
    (p) =>
      p.purchaseNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.supplierInvoiceNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredSuppliers = suppliers.filter(
    (s) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.phone.includes(searchTerm)
  );

  // Totals
  const totalPurchasedAllTime = purchases.reduce((sum, p) => sum + p.grandTotal, 0);
  const totalPaidToSuppliers = suppliers.reduce((sum, s) => sum + s.totalPaid, 0);
  const totalPendingToSuppliers = suppliers.reduce((sum, s) => sum + s.pendingBalance, 0);

  // Add Item to Purchase list
  const handleAddPurchaseItem = () => {
    if (!itemName.trim() || itemRate <= 0) {
      setErrorMsg('Product name and purchase rate are required.');
      return;
    }

    const isMobile = ['smartphone', 'feature_phone', 'used_phone', 'exchanged_phone'].includes(itemCategory);
    const qty = isMobile && itemImeis.length > 0 ? itemImeis.length : 1;

    const newItem: PurchaseItem = {
      productName: itemName.trim(),
      brand: itemBrand.trim(),
      model: itemModel.trim(),
      ram: itemRam.trim() || undefined,
      storage: itemStorage.trim() || undefined,
      color: itemColor.trim() || undefined,
      category: itemCategory,
      imeiList: itemImeis,
      quantity: qty,
      purchaseRate: itemRate,
      sellingRateTarget: itemTargetSellingRate || Math.round(itemRate * 1.15),
      amount: itemRate * qty
    };

    setPurchaseItems([...purchaseItems, newItem]);

    // reset item fields
    setItemName('');
    setItemModel('');
    setItemColor('');
    setItemRate(0);
    setItemTargetSellingRate(0);
    setItemImeis([]);
    setErrorMsg(null);
  };

  const handleAddImeiToPurchase = () => {
    const clean = singleImeiInput.trim();
    if (!clean) return;
    if (itemImeis.includes(clean)) return;
    setItemImeis([...itemImeis, clean]);
    setSingleImeiInput('');
  };

  // Grand total for current new purchase
  const currentPurchaseSubtotal = purchaseItems.reduce((sum, i) => sum + i.amount, 0);
  const currentPurchaseDue = Math.max(0, currentPurchaseSubtotal - paidToSupplier);

  const handleSavePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSupplierId) {
      setErrorMsg('Please select a supplier.');
      return;
    }
    if (purchaseItems.length === 0) {
      setErrorMsg('Please add at least one item to this purchase bill.');
      return;
    }

    const supp = suppliers.find((s) => s.id === selectedSupplierId);
    if (!supp) return;

    try {
      await createPurchaseBill({
        purchaseNumber: `PUR-2026-${String(purchases.length + 1).padStart(3, '0')}`,
        supplierId: supp.id,
        supplierName: supp.name,
        supplierContact: supp.phone,
        supplierInvoiceNumber: supplierInvoiceNo.trim() || `SUPP-${Date.now().toString().slice(-4)}`,
        date: purchaseDate,
        items: purchaseItems,
        subtotal: currentPurchaseSubtotal,
        taxAmount: 0,
        grandTotal: currentPurchaseSubtotal,
        paidAmount: paidToSupplier,
        pendingAmount: currentPurchaseDue,
        notes: purchaseNotes
      });

      setIsPurchaseModalOpen(false);
      setPurchaseItems([]);
      setSupplierInvoiceNo('');
      setPaidToSupplier(0);
      setPurchaseNotes('');
      setErrorMsg(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save purchase bill.');
    }
  };

  const handleCreateSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSuppName.trim() || !newSuppPhone.trim()) return;

    await addSupplier({
      name: newSuppName.trim(),
      phone: newSuppPhone.trim(),
      address: newSuppAddress.trim() || undefined,
      gstin: newSuppGstin.trim() || undefined
    });

    setIsSupplierModalOpen(false);
    setNewSuppName('');
    setNewSuppPhone('');
    setNewSuppAddress('');
    setNewSuppGstin('');
  };

  const handleExportPurchases = () => {
    const rows = purchases.map((p) => ({
      'Purchase #': p.purchaseNumber,
      'Supplier': p.supplierName,
      'Supplier Invoice': p.supplierInvoiceNumber,
      'Date': p.date,
      'Items': p.items.map((i) => `${i.brand} ${i.productName} (Qty: ${i.quantity})`).join('; '),
      'Total Amount': p.grandTotal,
      'Paid Amount': p.paidAmount,
      'Pending Amount': p.pendingAmount
    }));
    exportToCSV('MaaDurga_Purchases_Report', rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('purchases')} & SUPPLIER LEDGER
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Bulk stock inward with IMEI intake, supplier payments & pending balances.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Tabs */}
          <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('bills')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                activeTab === 'bills' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Purchase Bills ({purchases.length})
            </button>
            <button
              onClick={() => setActiveTab('suppliers')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                activeTab === 'suppliers' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Suppliers Directory ({suppliers.length})
            </button>
          </div>

          <button
            onClick={() => setIsSupplierModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs transition"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add Supplier</span>
          </button>

          <button
            onClick={() => {
              if (suppliers.length > 0 && !selectedSupplierId) {
                setSelectedSupplierId(suppliers[0].id);
              }
              setIsPurchaseModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New Purchase Bill</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Purchases Inward</span>
          <div className="text-xl sm:text-2xl font-black text-slate-100 font-mono-code mt-1">
            {formatCurrency(totalPurchasedAllTime)}
          </div>
          <span className="text-[10px] text-slate-500">{purchases.length} Purchase Invoices</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Paid to Suppliers</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono-code mt-1">
            {formatCurrency(totalPaidToSuppliers)}
          </div>
          <span className="text-[10px] text-slate-500">Bank / RTGS / Cash Outflow</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Pending Payable Balance</span>
          <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono-code mt-1">
            {formatCurrency(totalPendingToSuppliers)}
          </div>
          <span className="text-[10px] text-slate-500">Owed to Wholesale Distributors</span>
        </div>
      </div>

      {/* Search Toolbar */}
      <div className="flex items-center justify-between gap-3 p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder={activeTab === 'bills' ? "Search purchase bills by supplier, invoice #..." : "Search suppliers by name or phone..."}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        </div>

        {activeTab === 'bills' && (
          <button
            onClick={handleExportPurchases}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition"
          >
            Export CSV
          </button>
        )}
      </div>

      {/* TAB 1: PURCHASE BILLS TABLE */}
      {activeTab === 'bills' && (
        <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
          {filteredPurchases.length === 0 ? (
            <div className="py-16 text-center text-slate-500 text-xs">
              No purchase bills recorded. Click 'New Purchase Bill' to inward stock.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="p-3.5">Purchase #</th>
                    <th className="p-3.5">Supplier Name</th>
                    <th className="p-3.5">Supplier Inv #</th>
                    <th className="p-3.5">Date</th>
                    <th className="p-3.5">Inward Products & IMEIs</th>
                    <th className="p-3.5 text-right">Total Amount</th>
                    <th className="p-3.5 text-right">Paid</th>
                    <th className="p-3.5 text-right">Pending</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono-code">
                  {filteredPurchases.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-800/30">
                      <td className="p-3.5 font-bold text-amber-300">
                        {p.purchaseNumber}
                      </td>
                      <td className="p-3.5 font-sans font-semibold text-slate-100">
                        {p.supplierName}
                        <div className="text-[10px] text-slate-400 font-mono-code">{p.supplierContact}</div>
                      </td>
                      <td className="p-3.5 text-slate-300">
                        {p.supplierInvoiceNumber}
                      </td>
                      <td className="p-3.5 text-slate-400 font-sans">
                        {formatDate(p.date)}
                      </td>
                      <td className="p-3.5 font-sans max-w-xs">
                        {p.items.map((item, idx) => (
                          <div key={idx} className="text-slate-200">
                            <span className="font-semibold">{item.brand} {item.productName}</span>
                            <span className="text-slate-400 text-[10px] ml-1.5">Qty: {item.quantity}</span>
                          </div>
                        ))}
                      </td>
                      <td className="p-3.5 text-right font-bold text-slate-100">
                        {formatCurrency(p.grandTotal)}
                      </td>
                      <td className="p-3.5 text-right text-emerald-400">
                        {formatCurrency(p.paidAmount)}
                      </td>
                      <td className="p-3.5 text-right font-bold text-amber-300">
                        {p.pendingAmount > 0 ? formatCurrency(p.pendingAmount) : 'Settled'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SUPPLIERS DIRECTORY */}
      {activeTab === 'suppliers' && (
        <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
          {filteredSuppliers.length === 0 ? (
            <div className="py-16 text-center text-slate-500 text-xs">
              No suppliers added. Click 'Add Supplier' to create your wholesale contacts.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="p-3.5">Supplier Name</th>
                    <th className="p-3.5">Contact Number</th>
                    <th className="p-3.5">Address / City</th>
                    <th className="p-3.5">GSTIN</th>
                    <th className="p-3.5 text-right">Total Purchased</th>
                    <th className="p-3.5 text-right">Total Paid</th>
                    <th className="p-3.5 text-right">Pending Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono-code">
                  {filteredSuppliers.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-800/30">
                      <td className="p-3.5 font-sans font-bold text-slate-100">
                        {s.name}
                      </td>
                      <td className="p-3.5 text-slate-300">
                        {s.phone}
                      </td>
                      <td className="p-3.5 font-sans text-slate-400">
                        {s.address || 'N/A'}
                      </td>
                      <td className="p-3.5 text-slate-400">
                        {s.gstin || 'Unregistered'}
                      </td>
                      <td className="p-3.5 text-right text-slate-100">
                        {formatCurrency(s.totalPurchased)}
                      </td>
                      <td className="p-3.5 text-right text-emerald-400">
                        {formatCurrency(s.totalPaid)}
                      </td>
                      <td className="p-3.5 text-right font-bold text-amber-300">
                        {formatCurrency(s.pendingBalance)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* NEW PURCHASE BILL MODAL */}
      {isPurchaseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[94vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <Truck className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-100 font-royal">
                    New Purchase Inward Bill
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Stock will be automatically increased with newly entered IMEIs.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsPurchaseModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            {errorMsg && (
              <div className="mx-6 mt-4 p-3 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSavePurchase} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
              {/* Supplier & Invoice Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Select Supplier *
                  </label>
                  <select
                    value={selectedSupplierId}
                    onChange={(e) => setSelectedSupplierId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                  >
                    <option value="">Select Supplier...</option>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.phone})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Supplier Invoice / Bill No *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. INV-88219"
                    value={supplierInvoiceNo}
                    onChange={(e) => setSupplierInvoiceNo(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Purchase Date
                  </label>
                  <input
                    type="date"
                    value={purchaseDate}
                    onChange={(e) => setPurchaseDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Add Inward Item Form */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                <h4 className="font-bold text-amber-300 uppercase tracking-wider text-[11px]">
                  + Add Handset or Accessory Inward
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">Category</label>
                    <select
                      value={itemCategory}
                      onChange={(e) => setItemCategory(e.target.value as ProductCategory)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                    >
                      <option value="smartphone">Smartphone</option>
                      <option value="feature_phone">Feature Phone</option>
                      <option value="used_phone">Used Mobile</option>
                      <option value="audio">Audio / Earbuds</option>
                      <option value="smartwatch">Smartwatch</option>
                      <option value="charger_cable">Charger & Cable</option>
                      <option value="accessories">Cover & Glass</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Brand</label>
                    <input
                      type="text"
                      placeholder="e.g. Vivo, Oppo, Apple"
                      value={itemBrand}
                      onChange={(e) => setItemBrand(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Model / Product Name *</label>
                    <input
                      type="text"
                      placeholder="e.g. V40 5G"
                      value={itemName}
                      onChange={(e) => setItemName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-slate-400 mb-1">RAM / Storage</label>
                    <input
                      type="text"
                      placeholder="8/128"
                      value={itemRam}
                      onChange={(e) => setItemRam(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Color</label>
                    <input
                      type="text"
                      placeholder="e.g. Black"
                      value={itemColor}
                      onChange={(e) => setItemColor(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Purchase Rate (₹) *</label>
                    <input
                      type="number"
                      value={itemRate}
                      onChange={(e) => setItemRate(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Target Selling Price (₹)</label>
                    <input
                      type="number"
                      value={itemTargetSellingRate}
                      onChange={(e) => setItemTargetSellingRate(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code"
                    />
                  </div>
                </div>

                {/* Intake IMEIs */}
                {['smartphone', 'feature_phone', 'used_phone', 'exchanged_phone'].includes(itemCategory) && (
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-300">
                        Scan or Type IMEIs to Intake ({itemImeis.length} Handsets)
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsScannerOpen(true)}
                        className="text-[10px] text-amber-400 flex items-center gap-1 font-bold"
                      >
                        <ScanLine className="w-3.5 h-3.5" /> Scan Barcode
                      </button>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Enter 15-digit IMEI..."
                        value={singleImeiInput}
                        onChange={(e) => setSingleImeiInput(e.target.value.replace(/[^0-9]/g, ''))}
                        className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code text-xs"
                      />
                      <button
                        type="button"
                        onClick={handleAddImeiToPurchase}
                        className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-xl"
                      >
                        + Add IMEI
                      </button>
                    </div>

                    {itemImeis.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 p-1.5 rounded-lg bg-slate-950 max-h-24 overflow-y-auto">
                        {itemImeis.map((im, idx) => (
                          <span key={idx} className="px-2 py-0.5 rounded bg-slate-800 text-amber-300 font-mono-code text-[10px] flex items-center gap-1">
                            {im}
                            <button
                              type="button"
                              onClick={() => setItemImeis(itemImeis.filter((_, i) => i !== idx))}
                              className="text-slate-400 hover:text-red-400"
                            >
                              ✕
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={handleAddPurchaseItem}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Add Item to Inward List
                  </button>
                </div>
              </div>

              {/* Items List */}
              {purchaseItems.length > 0 && (
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="font-bold text-slate-200">
                    Inward Bill Summary ({purchaseItems.length} Products)
                  </div>
                  <div className="divide-y divide-slate-800">
                    {purchaseItems.map((item, idx) => (
                      <div key={idx} className="py-2 flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-slate-100">{item.brand} {item.productName}</div>
                          <div className="text-[11px] text-slate-400">
                            {item.quantity} units @ {formatCurrency(item.purchaseRate)} · Target: {formatCurrency(item.sellingRateTarget)}
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono-code font-bold text-amber-300">
                            {formatCurrency(item.amount)}
                          </span>
                          <button
                            type="button"
                            onClick={() => setPurchaseItems(purchaseItems.filter((_, i) => i !== idx))}
                            className="text-slate-500 hover:text-red-400"
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Total & Payment Outflow */}
              <div className="grid grid-cols-2 gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono-code">
                <div>
                  <label className="block text-slate-400 font-sans mb-1">
                    Amount Paid to Supplier Now (₹)
                  </label>
                  <input
                    type="number"
                    value={paidToSupplier}
                    onChange={(e) => setPaidToSupplier(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-bold"
                  />
                </div>

                <div className="flex flex-col justify-end text-right">
                  <div className="text-slate-400 text-xs font-sans">Total Purchase Cost:</div>
                  <div className="text-xl font-black text-slate-100">
                    {formatCurrency(currentPurchaseSubtotal)}
                  </div>
                  <div className="text-amber-300 text-xs">
                    Pending Supplier Due: {formatCurrency(currentPurchaseDue)}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsPurchaseModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20"
                >
                  Inward Stock & Save Bill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* NEW SUPPLIER MODAL */}
      {isSupplierModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 font-royal">
              Add New Wholesale Supplier
            </h3>

            <form onSubmit={handleCreateSupplier} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Supplier / Firm Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shree Ganesh Telecom"
                  value={newSuppName}
                  onChange={(e) => setNewSuppName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Mobile / Phone *</label>
                <input
                  type="tel"
                  required
                  placeholder="9876543210"
                  value={newSuppPhone}
                  onChange={(e) => setNewSuppPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Address / City</label>
                <input
                  type="text"
                  placeholder="e.g. Fraser Road, Patna"
                  value={newSuppAddress}
                  onChange={(e) => setNewSuppAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">GSTIN (Optional)</label>
                <input
                  type="text"
                  placeholder="10ABCDE1234F1Z5"
                  value={newSuppGstin}
                  onChange={(e) => setNewSuppGstin(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSupplierModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Save Supplier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Scanner modal for purchase IMEI intake */}
      <ImeiScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={(code) => {
          if (!itemImeis.includes(code)) {
            setItemImeis([...itemImeis, code]);
          }
        }}
        title="Scan IMEI for Inward Purchase"
      />
    </div>
  );
};
