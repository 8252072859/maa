import React, { useState } from 'react';
import {
  Boxes,
  Plus,
  Search,
  Filter,
  AlertTriangle,
  Edit,
  Trash2,
  ScanLine,
  SlidersHorizontal,
  Coins,
  History,
  CheckCircle2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { Product, ProductCategory } from '../../types/erp';
import { formatCurrency, formatDate, exportToCSV } from '../../utils/formatters';
import { AddProductModal } from './AddProductModal';
import { ImeiScannerModal } from '../common/ImeiScannerModal';

export const StockManagement: React.FC = () => {
  const { products, deleteProduct, adjustStockQuantity, invoices } = useERP();
  const { t } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [lowStockOnly, setLowStockOnly] = useState(false);
  const [viewMode, setViewMode] = useState<'inventory' | 'sold_imeis'>('inventory');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);
  const [productToAdjust, setProductToAdjust] = useState<Product | null>(null);
  const [adjustQtyInput, setAdjustQtyInput] = useState<number>(0);
  const [adjustReasonInput, setAdjustReasonInput] = useState('Showroom Demo Unit');
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);

  // IMEI quick lookup modal
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [expandedProductImeis, setExpandedProductImeis] = useState<Record<string, boolean>>({});

  const toggleImeis = (productId: string) => {
    setExpandedProductImeis(prev => ({ ...prev, [productId]: !prev[productId] }));
  };

  // Unique brands in stock
  const allBrands = Array.from(new Set(products.map(p => p.brand))).sort();

  // Filtered Products
  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.imeiList && p.imeiList.some(im => im.includes(searchTerm)));

    const matchesBrand = selectedBrand === 'all' || p.brand.toLowerCase() === selectedBrand.toLowerCase();
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesLowStock = !lowStockOnly || p.currentStock <= p.minStockAlert;

    return matchesSearch && matchesBrand && matchesCategory && matchesLowStock;
  });

  // Financial Stock Metrics
  const totalStockUnits = products.reduce((sum, p) => sum + p.currentStock, 0);
  const totalPurchaseValue = products.reduce((sum, p) => sum + (p.currentStock * p.purchasePrice), 0);
  const totalRetailValue = products.reduce((sum, p) => sum + (p.currentStock * p.sellingPrice), 0);
  const expectedGrossProfit = Math.max(0, totalRetailValue - totalPurchaseValue);
  const lowStockCount = products.filter(p => p.currentStock <= p.minStockAlert).length;

  // Sold Handset History mapping
  const soldHandsets: {
    imei: string;
    productName: string;
    brand: string;
    customerName: string;
    customerPhone: string;
    invoiceNumber: string;
    date: string;
    sellingRate: number;
  }[] = [];

  invoices.forEach(inv => {
    if (inv.isCancelled) return;
    inv.items.forEach(item => {
      if (item.imei1) {
        soldHandsets.push({
          imei: item.imei1,
          productName: item.productName,
          brand: item.brand,
          customerName: inv.customerName,
          customerPhone: inv.customerPhone,
          invoiceNumber: inv.invoiceNumber,
          date: inv.date,
          sellingRate: item.rate
        });
      }
      if (item.imei2) {
        soldHandsets.push({
          imei: item.imei2,
          productName: item.productName,
          brand: item.brand,
          customerName: inv.customerName,
          customerPhone: inv.customerPhone,
          invoiceNumber: inv.invoiceNumber,
          date: inv.date,
          sellingRate: item.rate
        });
      }
    });
  });

  const filteredSoldHandsets = soldHandsets.filter(sh =>
    sh.imei.includes(searchTerm) ||
    sh.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sh.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sh.customerPhone.includes(searchTerm) ||
    sh.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExportStockCSV = () => {
    const rows = filteredProducts.map(p => ({
      'Product Name': p.name,
      'Brand': p.brand,
      'Model': p.model,
      'Category': p.category,
      'Current Stock': p.currentStock,
      'Purchase Price': p.purchasePrice,
      'Selling Price': p.sellingPrice,
      'Stock Purchase Valuation': p.currentStock * p.purchasePrice,
      'Available IMEIs': (p.imeiList || []).join('; ')
    }));
    exportToCSV('MaaDurga_Inventory_Stock', rows);
  };

  const handleSaveStockAdjustment = async () => {
    if (!productToAdjust) return;
    await adjustStockQuantity(productToAdjust.id, adjustQtyInput, adjustReasonInput);
    setProductToAdjust(null);
  };

  const handleConfirmDelete = async () => {
    if (!productToDelete) return;
    await deleteProduct(productToDelete.id);
    setProductToDelete(null);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Boxes className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('stock')} & DUAL IMEI INVENTORY
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time multi-brand smartphone tracking with duplicate sale protection.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Toggle between Active Inventory & Sold History */}
          <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setViewMode('inventory')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                viewMode === 'inventory' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Current Stock
            </button>
            <button
              onClick={() => setViewMode('sold_imeis')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                viewMode === 'sold_imeis' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Sold Mobiles History
            </button>
          </div>

          <button
            onClick={() => {
              setProductToEdit(null);
              setIsAddModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add New Product</span>
          </button>
        </div>
      </div>

      {/* 4 Financial Valuation Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Stock Qty</span>
          <div className="text-xl sm:text-2xl font-black text-slate-100 font-mono-code mt-1">
            {totalStockUnits} Units
          </div>
          <span className="text-[10px] text-slate-500">{products.length} Products Cataloged</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Purchase Valuation</span>
          <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono-code mt-1">
            {formatCurrency(totalPurchaseValue)}
          </div>
          <span className="text-[10px] text-slate-500">Actual Cost Invested</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Expected Retail Value</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono-code mt-1">
            {formatCurrency(totalRetailValue)}
          </div>
          <span className="text-[10px] text-slate-500">Target Gross Revenue</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Projected Margin</span>
          <div className="text-xl sm:text-2xl font-black text-blue-400 font-mono-code mt-1">
            {formatCurrency(expectedGrossProfit)}
          </div>
          <span className="text-[10px] text-slate-500">
            {totalPurchaseValue > 0 ? `${Math.round((expectedGrossProfit / totalPurchaseValue) * 100)}% ROI Margin` : '0%'}
          </span>
        </div>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
        <div className="flex flex-1 items-center gap-2 w-full">
          <div className="relative flex-1">
            <input
              type="text"
              placeholder="Search by Model, Brand or 15-digit IMEI..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          </div>

          <button
            onClick={() => setIsScannerOpen(true)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 transition"
            title="Scan IMEI to filter"
          >
            <ScanLine className="w-4 h-4" />
          </button>
        </div>

        {viewMode === 'inventory' && (
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {/* Brand Filter */}
            <select
              value={selectedBrand}
              onChange={(e) => setSelectedBrand(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-300 text-xs focus:outline-none focus:border-amber-400"
            >
              <option value="all">All Brands</option>
              {allBrands.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>

            {/* Category Filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-300 text-xs focus:outline-none focus:border-amber-400"
            >
              <option value="all">All Categories</option>
              <option value="smartphone">Smartphones</option>
              <option value="feature_phone">Feature Phones</option>
              <option value="used_phone">Used Phones</option>
              <option value="exchanged_phone">Exchanged Phones</option>
              <option value="audio">Audio / Earbuds</option>
              <option value="smartwatch">Smartwatches</option>
              <option value="charger_cable">Chargers</option>
              <option value="accessories">Accessories</option>
            </select>

            {/* Low Stock Toggle Button */}
            <button
              onClick={() => setLowStockOnly(!lowStockOnly)}
              className={`px-3 py-2 rounded-xl text-xs font-semibold border transition ${
                lowStockOnly
                  ? 'bg-red-500/20 text-red-300 border-red-500/50'
                  : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
              }`}
            >
              Low Stock Only ({lowStockCount})
            </button>

            <button
              onClick={handleExportStockCSV}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition"
            >
              Export CSV
            </button>
          </div>
        )}
      </div>

      {/* VIEW MODE 1: ACTIVE INVENTORY TABLE */}
      {viewMode === 'inventory' && (
        <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
          {filteredProducts.length === 0 ? (
            <div className="py-16 text-center text-slate-500 text-xs">
              No products found in inventory.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="p-3.5">Product & Specs</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Available IMEIs in Stock</th>
                    <th className="p-3.5 text-right">Purchase Price</th>
                    <th className="p-3.5 text-right">Selling Price</th>
                    <th className="p-3.5 text-center">Current Stock</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono-code">
                  {filteredProducts.map((p) => {
                    const isLow = p.currentStock <= p.minStockAlert;
                    const hasImeis = p.imeiList && p.imeiList.length > 0;
                    const isExpanded = !!expandedProductImeis[p.id];

                    return (
                      <tr key={p.id} className="hover:bg-slate-800/30 transition">
                        {/* Product Info */}
                        <td className="p-3.5 font-sans">
                          <div className="font-bold text-slate-100 flex items-center gap-1.5">
                            <span className="text-amber-400">{p.brand}</span>
                            <span>{p.name}</span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            {p.model}
                            {p.ram ? ` · ${p.ram}/${p.storage}` : ''}
                            {p.color ? ` · ${p.color}` : ''}
                          </div>
                          {p.notes && (
                            <div className="text-[10px] text-slate-500 italic mt-0.5 max-w-xs truncate">
                              Note: {p.notes}
                            </div>
                          )}
                        </td>

                        {/* Category */}
                        <td className="p-3.5 font-sans">
                          <span className="capitalize text-slate-300 text-[11px]">
                            {p.category.replace('_', ' ')}
                          </span>
                          {p.isUsed && (
                            <span className="ml-1.5 px-1.5 py-0.2 rounded text-[9px] bg-purple-500/10 text-purple-300 border border-purple-500/30">
                              Used
                            </span>
                          )}
                        </td>

                        {/* IMEIs */}
                        <td className="p-3.5 font-mono-code max-w-xs">
                          {hasImeis ? (
                            <div>
                              <button
                                onClick={() => toggleImeis(p.id)}
                                className="flex items-center gap-1 text-[11px] text-amber-300 hover:text-amber-200 font-semibold"
                              >
                                <span>{p.imeiList.length} Units Cataloged</span>
                                {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                              </button>

                              {isExpanded && (
                                <div className="mt-2 space-y-1 max-h-32 overflow-y-auto p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px]">
                                  {p.imeiList.map((im, i) => (
                                    <div key={i} className="text-slate-300">
                                      #{i + 1}: <span className="font-semibold text-amber-400">{im}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="text-slate-500 text-[11px] font-sans">
                              {p.serialNumber ? `S/N: ${p.serialNumber}` : 'Standard SKU'}
                            </span>
                          )}
                        </td>

                        {/* Purchase Price */}
                        <td className="p-3.5 text-right text-slate-400">
                          {formatCurrency(p.purchasePrice)}
                        </td>

                        {/* Selling Price */}
                        <td className="p-3.5 text-right font-bold text-slate-100">
                          {formatCurrency(p.sellingPrice)}
                        </td>

                        {/* Stock count */}
                        <td className="p-3.5 text-center">
                          <span
                            className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                              p.currentStock === 0
                                ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                                : isLow
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                            }`}
                          >
                            {p.currentStock} {p.currentStock <= 1 ? 'pc' : 'pcs'}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="p-3.5 text-right font-sans">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Stock Adjustment */}
                            <button
                              onClick={() => {
                                setProductToAdjust(p);
                                setAdjustQtyInput(p.currentStock);
                              }}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                              title="Adjust Stock Quantity"
                            >
                              <SlidersHorizontal className="w-3.5 h-3.5" />
                            </button>

                            {/* Edit */}
                            <button
                              onClick={() => {
                                setProductToEdit(p);
                                setIsAddModalOpen(true);
                              }}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                              title="Edit Product"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete */}
                            <button
                              onClick={() => setProductToDelete(p)}
                              className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition"
                              title="Delete Product"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 2: SOLD MOBILES HISTORY (IMEI Audit) */}
      {viewMode === 'sold_imeis' && (
        <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
          <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-200">
                Sold Handsets IMEI Directory ({soldHandsets.length})
              </h3>
              <p className="text-[11px] text-slate-500">
                Track exact customer, bill number and sale date for every IMEI ever sold.
              </p>
            </div>
          </div>

          {filteredSoldHandsets.length === 0 ? (
            <div className="py-16 text-center text-slate-500 text-xs">
              No sold handsets matching your search.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="p-3.5">Sold Handset IMEI</th>
                    <th className="p-3.5">Model & Brand</th>
                    <th className="p-3.5">Customer Name & Phone</th>
                    <th className="p-3.5">Invoice #</th>
                    <th className="p-3.5">Sold Date</th>
                    <th className="p-3.5 text-right">Sold Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono-code">
                  {filteredSoldHandsets.map((sh, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="p-3.5 font-bold text-amber-300">
                        {sh.imei}
                      </td>
                      <td className="p-3.5 font-sans font-semibold text-slate-200">
                        {sh.brand} {sh.productName}
                      </td>
                      <td className="p-3.5 font-sans">
                        <div className="font-semibold text-slate-200">{sh.customerName}</div>
                        <div className="text-[11px] text-slate-400 font-mono-code">{sh.customerPhone}</div>
                      </td>
                      <td className="p-3.5 text-blue-400 font-semibold">
                        {sh.invoiceNumber}
                      </td>
                      <td className="p-3.5 text-slate-400 font-sans">
                        {formatDate(sh.date)}
                      </td>
                      <td className="p-3.5 text-right font-bold text-slate-100">
                        {formatCurrency(sh.sellingRate)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Add / Edit Product Modal */}
      <AddProductModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setProductToEdit(null);
        }}
        productToEdit={productToEdit}
      />

      {/* Stock Adjustment Modal */}
      {productToAdjust && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100">
              Adjust Stock Quantity
            </h3>
            <p className="text-xs text-slate-400">
              {productToAdjust.brand} {productToAdjust.name} (Current: {productToAdjust.currentStock})
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  New Stock Count
                </label>
                <input
                  type="number"
                  min={0}
                  value={adjustQtyInput}
                  onChange={(e) => setAdjustQtyInput(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Reason for Adjustment
                </label>
                <select
                  value={adjustReasonInput}
                  onChange={(e) => setAdjustReasonInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
                >
                  <option value="Showroom Demo Display Unit">Showroom Demo Display Unit</option>
                  <option value="Damaged in transit">Damaged in transit</option>
                  <option value="Returned to Supplier">Returned to Supplier</option>
                  <option value="Audit Stock Correction">Audit Stock Correction</option>
                  <option value="Internal Testing">Internal Testing</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setProductToAdjust(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveStockAdjustment}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/20"
              >
                Apply Adjustment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-red-500/40 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  Delete {productToDelete.brand} {productToDelete.name}?
                </h3>
                <p className="text-xs text-slate-400">
                  Are you sure you want to delete this product from the inventory catalog?
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold"
              >
                Delete Product
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Barcode / IMEI Scanner */}
      <ImeiScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={(code) => setSearchTerm(code)}
        title="Scan IMEI to Search in Stock"
      />
    </div>
  );
};
