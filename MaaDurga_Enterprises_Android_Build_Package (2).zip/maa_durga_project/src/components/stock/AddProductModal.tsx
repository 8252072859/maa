import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, ScanLine, Smartphone, Check, AlertCircle } from 'lucide-react';
import { Product, ProductCategory } from '../../types/erp';
import { useERP } from '../../context/ERPContext';
import { ImeiScannerModal } from '../common/ImeiScannerModal';

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  productToEdit?: Product | null;
}

export const AddProductModal: React.FC<AddProductModalProps> = ({
  isOpen,
  onClose,
  productToEdit
}) => {
  const { addProduct, updateProduct, isImeiAvailable } = useERP();

  const [name, setName] = useState('');
  const [brand, setBrand] = useState('Samsung');
  const [model, setModel] = useState('');
  const [ram, setRam] = useState('');
  const [storage, setStorage] = useState('');
  const [color, setColor] = useState('');
  const [category, setCategory] = useState<ProductCategory>('smartphone');
  const [purchasePrice, setPurchasePrice] = useState<number>(0);
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [currentStock, setCurrentStock] = useState<number>(1);
  const [minStockAlert, setMinStockAlert] = useState<number>(2);
  const [warrantyMonths, setWarrantyMonths] = useState<number>(12);
  const [serialNumber, setSerialNumber] = useState('');
  const [notes, setNotes] = useState('');

  // IMEIs List
  const [imeiList, setImeiList] = useState<string[]>([]);
  const [newImeiInput, setNewImeiInput] = useState('');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name);
      setBrand(productToEdit.brand);
      setModel(productToEdit.model);
      setRam(productToEdit.ram || '');
      setStorage(productToEdit.storage || '');
      setColor(productToEdit.color || '');
      setCategory(productToEdit.category);
      setPurchasePrice(productToEdit.purchasePrice);
      setSellingPrice(productToEdit.sellingPrice);
      setCurrentStock(productToEdit.currentStock);
      setMinStockAlert(productToEdit.minStockAlert);
      setWarrantyMonths(productToEdit.warrantyMonths);
      setSerialNumber(productToEdit.serialNumber || '');
      setNotes(productToEdit.notes || '');
      setImeiList(productToEdit.imeiList || []);
    } else {
      // Defaults for new product
      setName('');
      setBrand('Samsung');
      setModel('');
      setRam('8GB');
      setStorage('128GB');
      setColor('');
      setCategory('smartphone');
      setPurchasePrice(0);
      setSellingPrice(0);
      setCurrentStock(1);
      setMinStockAlert(2);
      setWarrantyMonths(12);
      setSerialNumber('');
      setNotes('');
      setImeiList([]);
    }
    setErrorMsg(null);
  }, [productToEdit, isOpen]);

  if (!isOpen) return null;

  const isMobileCategory = ['smartphone', 'feature_phone', 'used_phone', 'exchanged_phone'].includes(category);

  const handleAddImei = () => {
    const clean = newImeiInput.trim();
    if (!clean) return;

    if (imeiList.includes(clean)) {
      setErrorMsg('This IMEI is already in the list.');
      return;
    }

    const check = isImeiAvailable(clean);
    if (!check.available) {
      setErrorMsg(check.reason || 'IMEI has already been sold in previous invoice!');
      return;
    }

    const updated = [...imeiList, clean];
    setImeiList(updated);
    setCurrentStock(updated.length);
    setNewImeiInput('');
    setErrorMsg(null);
  };

  const handleRemoveImei = (index: number) => {
    const updated = imeiList.filter((_, i) => i !== index);
    setImeiList(updated);
    setCurrentStock(updated.length);
  };

  const handleScanImei = (scanned: string) => {
    const clean = scanned.trim();
    if (!clean) return;

    if (imeiList.includes(clean)) {
      setErrorMsg('This IMEI is already in the list.');
      return;
    }

    const check = isImeiAvailable(clean);
    if (!check.available) {
      setErrorMsg(check.reason || 'IMEI already sold previously!');
      return;
    }

    const updated = [...imeiList, clean];
    setImeiList(updated);
    setCurrentStock(updated.length);
    setErrorMsg(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Product Name is required.');
      return;
    }
    if (purchasePrice <= 0 || sellingPrice <= 0) {
      setErrorMsg('Purchase and Selling prices must be greater than 0.');
      return;
    }

    try {
      if (productToEdit) {
        await updateProduct({
          ...productToEdit,
          name: name.trim(),
          brand: brand.trim(),
          model: model.trim(),
          ram: ram.trim() || undefined,
          storage: storage.trim() || undefined,
          color: color.trim() || undefined,
          category,
          purchasePrice,
          sellingPrice,
          currentStock: isMobileCategory && imeiList.length > 0 ? imeiList.length : currentStock,
          minStockAlert,
          warrantyMonths,
          serialNumber: serialNumber.trim() || undefined,
          imeiList: isMobileCategory ? imeiList : [],
          notes: notes.trim() || undefined
        });
      } else {
        await addProduct({
          name: name.trim(),
          brand: brand.trim(),
          model: model.trim(),
          ram: ram.trim() || undefined,
          storage: storage.trim() || undefined,
          color: color.trim() || undefined,
          category,
          purchasePrice,
          sellingPrice,
          currentStock: isMobileCategory && imeiList.length > 0 ? imeiList.length : currentStock,
          minStockAlert,
          warrantyMonths,
          serialNumber: serialNumber.trim() || undefined,
          imeiList: isMobileCategory ? imeiList : [],
          notes: notes.trim() || undefined
        });
      }

      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save product.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100 font-royal">
                {productToEdit ? 'Edit Product / Mobile Stock' : 'Add New Mobile or Accessory'}
              </h3>
              <p className="text-[11px] text-slate-400">
                Inventory catalog with purchase cost, target retail price & dual IMEI list.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {/* Row 1: Category & Brand */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ProductCategory)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
              >
                <option value="smartphone">New Smartphone (Android / iPhone)</option>
                <option value="feature_phone">Keypad Feature Phone</option>
                <option value="used_phone">Used / Refurbished Mobile</option>
                <option value="exchanged_phone">Exchanged Mobile Stock</option>
                <option value="tablet">Tablet / iPad</option>
                <option value="smartwatch">Smartwatch</option>
                <option value="audio">Audio / Bluetooth Earbuds</option>
                <option value="charger_cable">Charger & Power Adapter</option>
                <option value="accessories">Cover, Tempered & Accessories</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Brand *
              </label>
              <input
                type="text"
                list="brand-suggestions"
                placeholder="e.g. Samsung, Apple, Vivo"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
              />
              <datalist id="brand-suggestions">
                <option value="Apple" />
                <option value="Samsung" />
                <option value="Vivo" />
                <option value="Oppo" />
                <option value="Realme" />
                <option value="OnePlus" />
                <option value="Xiaomi / Redmi" />
                <option value="Poco" />
                <option value="Motorola" />
                <option value="Nothing" />
                <option value="iQOO" />
                <option value="boAt" />
                <option value="Noise" />
              </datalist>
            </div>
          </div>

          {/* Row 2: Name & Model */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Product Name *
              </label>
              <input
                type="text"
                placeholder="e.g. Galaxy S25 Ultra 5G"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Model Number / Code
              </label>
              <input
                type="text"
                placeholder="e.g. SM-S928B"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Row 3: RAM, Storage & Color (For Mobiles) */}
          {isMobileCategory && (
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  RAM
                </label>
                <input
                  type="text"
                  placeholder="e.g. 8GB / 12GB"
                  value={ram}
                  onChange={(e) => setRam(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Storage
                </label>
                <input
                  type="text"
                  placeholder="e.g. 128GB / 256GB"
                  value={storage}
                  onChange={(e) => setStorage(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Color
                </label>
                <input
                  type="text"
                  placeholder="e.g. Titanium Gray"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          {/* Row 4: Pricing & Margin */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Purchase Price (₹) *
              </label>
              <input
                type="number"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Selling Price (₹) *
              </label>
              <input
                type="number"
                value={sellingPrice}
                onChange={(e) => setSellingPrice(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Current Stock Qty
              </label>
              <input
                type="number"
                value={isMobileCategory && imeiList.length > 0 ? imeiList.length : currentStock}
                onChange={(e) => setCurrentStock(Math.max(0, Number(e.target.value)))}
                disabled={isMobileCategory && imeiList.length > 0}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400 disabled:opacity-60"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Min Stock Alert
              </label>
              <input
                type="number"
                value={minStockAlert}
                onChange={(e) => setMinStockAlert(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Row 5: Warranty & Serial */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Warranty (Months)
              </label>
              <input
                type="number"
                value={warrantyMonths}
                onChange={(e) => setWarrantyMonths(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                Serial Number (Optional)
              </label>
              <input
                type="text"
                placeholder="Optional hardware serial"
                value={serialNumber}
                onChange={(e) => setSerialNumber(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Row 6: Handset IMEI Management (for mobile phones) */}
          {isMobileCategory && (
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-200">
                    Individual Unit IMEIs ({imeiList.length})
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Each 15-digit IMEI represents one physical handset in stock.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsScannerOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 transition font-semibold"
                >
                  <ScanLine className="w-3.5 h-3.5" />
                  <span>Scan Box Barcode</span>
                </button>
              </div>

              {/* Add IMEI input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter 15-digit IMEI number..."
                  value={newImeiInput}
                  onChange={(e) => setNewImeiInput(e.target.value.replace(/[^0-9]/g, ''))}
                  className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                />
                <button
                  type="button"
                  onClick={handleAddImei}
                  disabled={!newImeiInput.trim()}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center gap-1 disabled:opacity-40"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" /> Add
                </button>
              </div>

              {/* Tag list of IMEIs */}
              {imeiList.length > 0 && (
                <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto p-2 rounded-xl bg-slate-900/60 border border-slate-800">
                  {imeiList.map((imei, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 font-mono-code text-[11px]"
                    >
                      <span>{imei}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveImei(idx)}
                        className="text-slate-400 hover:text-red-400 ml-1"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Remarks */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              Notes / Condition (for used or exchange phones)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Scratchless condition, Battery Health 92%, Original Box available"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Submit buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20"
            >
              {productToEdit ? 'Save Changes' : 'Save Product to Inventory'}
            </button>
          </div>
        </form>
      </div>

      {/* Camera scanner for barcode */}
      <ImeiScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleScanImei}
        title="Scan IMEI to Add to Stock"
      />
    </div>
  );
};
