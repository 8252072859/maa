import React, { useEffect, useRef } from 'react';
import QRCode from 'qrcode';

interface UpiQrCodeProps {
  upiId: string;
  payeeName: string;
  amount?: number;
  invoiceNo?: string;
  size?: number;
  className?: string;
}

export const UpiQrCode: React.FC<UpiQrCodeProps> = ({
  upiId,
  payeeName,
  amount,
  invoiceNo,
  size = 140,
  className = ""
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current || !upiId) return;

    // Standard NPCI UPI URI Scheme
    let upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName || 'Maa Durga Enterprises')}&cu=INR`;
    if (amount && amount > 0) {
      upiUri += `&am=${amount.toFixed(2)}`;
    }
    if (invoiceNo) {
      upiUri += `&tn=${encodeURIComponent(`Bill ${invoiceNo}`)}`;
    }

    QRCode.toCanvas(
      canvasRef.current,
      upiUri,
      {
        width: size,
        margin: 1,
        color: {
          dark: '#0f172a',
          light: '#ffffff'
        }
      },
      (error) => {
        if (error) console.error('Error generating UPI QR code:', error);
      }
    );
  }, [upiId, payeeName, amount, invoiceNo, size]);

  if (!upiId) return null;

  return (
    <div className={`inline-flex flex-col items-center justify-center p-2 bg-white rounded-lg shadow-sm border border-slate-200 ${className}`}>
      <canvas ref={canvasRef} />
      <span className="text-[10px] font-semibold text-slate-700 mt-1 uppercase tracking-wider">
        Scan & Pay with any UPI
      </span>
    </div>
  );
};
