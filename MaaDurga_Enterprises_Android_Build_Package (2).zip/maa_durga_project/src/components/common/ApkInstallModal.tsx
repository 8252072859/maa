import React from 'react';
import { X, Smartphone, CheckCircle2, Copy, ExternalLink, ShieldCheck, Wrench } from 'lucide-react';
import { usePwaInstall } from '../../hooks/usePwaInstall';
import { sounds } from '../../utils/soundEffects';

interface ApkInstallModalProps { isOpen: boolean; onClose: () => void; }

export const ApkInstallModal: React.FC<ApkInstallModalProps> = ({ isOpen, onClose }) => {
  const { triggerInstall, hasNativePrompt, isInstalled } = usePwaInstall();
  if (!isOpen) return null;
  const appUrl = window.location.origin;
  const copyLink = async () => {
    try { await navigator.clipboard.writeText(appUrl); window.alert('App link copied.'); }
    catch { window.prompt('Copy app link:', appUrl); }
  };
  const installPwa = async () => {
    sounds.playScanBeep();
    const ok = await triggerInstall();
    if (ok) { sounds.playSuccessChime(); onClose(); }
  };
  return <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
    <div role="dialog" aria-modal="true" aria-labelledby="app-build-title" className="relative w-full max-w-lg bg-[#0d1322] border border-amber-500/40 rounded-3xl p-6 shadow-2xl space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-400/40 flex items-center justify-center text-2xl">🔱</div>
          <div><h3 id="app-build-title" className="text-base sm:text-lg font-black text-slate-100">MAA DURGA ENTERPRISES</h3><p className="text-xs text-amber-300 font-bold">Android app installation</p></div>
        </div>
        <button onClick={onClose} aria-label="Close" className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"><X className="w-5 h-5" /></button>
      </div>
      <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/30 space-y-2">
        <div className="flex items-center gap-2 text-amber-200 font-bold"><Wrench className="w-4 h-4"/> APK build is required</div>
        <p className="text-sm text-slate-300 leading-relaxed">A verified installable APK has not been generated yet. Do not download or install any placeholder file. Build the Android APK from the project using the instructions in <strong>ANDROID_BUILD_HINDI.md</strong>.</p>
      </div>
      {hasNativePrompt && !isInstalled && <button onClick={installPwa} className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black flex items-center justify-center gap-2"><Smartphone className="w-4 h-4"/> Install website on this phone</button>}
      {isInstalled && <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/30 text-emerald-300 text-sm flex items-center gap-2"><CheckCircle2 className="w-4 h-4"/> Website app is installed on this device.</div>}
      <button onClick={copyLink} className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold flex items-center justify-center gap-2"><Copy className="w-4 h-4"/> Copy app website link</button>
      <div className="text-xs text-slate-400 leading-relaxed flex gap-2"><ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400"/><span>Admin OTP for +91 8252072859 requires a deployed backend and configured real SMS/WhatsApp provider. Never use a demo OTP for real shop data.</span></div>
      <a href="https://capacitorjs.com/docs/android" target="_blank" rel="noreferrer" className="text-xs text-amber-300 underline flex items-center justify-center gap-1">Android APK build guide <ExternalLink className="w-3 h-3"/></a>
    </div>
  </div>;
};
