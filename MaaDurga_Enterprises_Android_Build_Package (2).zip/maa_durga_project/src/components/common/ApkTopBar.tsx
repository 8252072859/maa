import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  Sparkles, 
  ExternalLink, 
  Share2, 
  CheckCircle2, 
  QrCode, 
  X,
  FileCode,
  ShieldCheck
} from 'lucide-react';
import { usePwaInstall } from '../../hooks/usePwaInstall';
import { sounds } from '../../utils/soundEffects';
import { ApkInstallModal } from './ApkInstallModal';

interface ApkTopBarProps {
  variant?: 'banner' | 'compact';
}

export const ApkTopBar: React.FC<ApkTopBarProps> = ({ variant = 'banner' }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const { hasNativePrompt, triggerInstall, isInstalled } = usePwaInstall();

  if (isDismissed) {
    return (
      <div className="bg-gradient-to-r from-emerald-950/80 via-slate-900 to-amber-950/80 border-b border-amber-500/30 px-3 py-1 flex items-center justify-between text-[11px] text-amber-200">
        <div className="flex items-center gap-2">
          <span>📲 Android app installation</span>
          <span className="font-mono-code font-bold text-emerald-400">APK build required</span>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="text-amber-400 hover:text-white font-bold underline cursor-pointer"
        >
          View install options
        </button>
        <ApkInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      </div>
    );
  }

    const handleNativeInstall = async () => {
    sounds.playScanBeep();
    if (hasNativePrompt) {
      const res = await triggerInstall();
      if (res) sounds.playSuccessChime();
    } else {
      setIsModalOpen(true);
    }
  };

  return (
    <>
      {/* HIGH VISIBILITY TOP ANNOUNCEMENT BAR FOR ANDROID APK */}
      <aside 
        aria-label="Android APK Download Banner"
        className="relative z-40 bg-gradient-to-r from-[#0a1f14] via-[#0b162c] to-[#1a1205] border-b-2 border-amber-400/80 shadow-lg shadow-black/60 px-3 sm:px-6 py-2.5 text-slate-100 select-none"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2.5">
          {/* Left: APK Title & Badges */}
          <div className="flex items-center gap-2.5 sm:gap-3 flex-wrap justify-center md:justify-start text-center md:text-left">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/50 text-emerald-400 shadow-sm animate-pulse">
              <span className="text-lg">📲</span>
            </div>
            
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-100 to-yellow-300 font-royal tracking-wide">
                  ANDROID APP INSTALL / BUILD
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono-code text-[10px] font-bold">
                  APK build required
                </span>
              </div>
              <p className="text-[11px] text-slate-300 flex items-center gap-1.5 justify-center md:justify-start">
                <FileCode className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-mono-code font-bold text-amber-200">APK build required</span>
                <span className="text-slate-400 hidden sm:inline">· Android mobile and tablet support</span>
              </p>
            </div>
          </div>

          {/* Right: Quick Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap justify-center">
            {/* Direct APK Download Link */}
            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black text-xs uppercase tracking-wider shadow-md shadow-emerald-500/20 hover:scale-105 active:scale-95 transition cursor-pointer"
            >
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>APK Build Info</span>
            </button>

            {/* Direct Install on Phone (PWA / WebAPK) */}
            <button
              type="button"
              onClick={handleNativeInstall}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-md shadow-amber-500/20 hover:scale-105 active:scale-95 transition cursor-pointer"
            >
              <Smartphone className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Direct Install</span>
            </button>

            {/* View Full APK Details & QR Code Modal */}
            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white text-xs font-bold transition cursor-pointer"
              title="QR Code & APK Details"
            >
              <QrCode className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">QR Code / Details</span>
            </button>

            {/* Close / Dismiss Bar */}
            <button
              type="button"
              onClick={() => setIsDismissed(true)}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title="Hide Banner"
              aria-label="Dismiss banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Full Modal */}
      <ApkInstallModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};
