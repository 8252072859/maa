import React, { useState } from 'react';
import { Lock, Unlock, ShieldAlert, KeyRound } from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { sounds } from '../../utils/soundEffects';

export const PinLockScreen: React.FC = () => {
  const { settings, setIsLocked } = useERP();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setError(false);
      sounds.playScanBeep();

      if (nextPin.length === 4) {
        verifyPin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
    setError(false);
  };

  const verifyPin = (entered: string) => {
    const requiredPin = settings.pinCode || '1234';
    if (entered === requiredPin) {
      sounds.playSuccessChime();
      setIsLocked(false);
    } else {
      sounds.playErrorBuzz();
      setError(true);
      setTimeout(() => {
        setPin('');
      }, 600);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#070b14]/95 backdrop-blur-md p-4 select-none">
      <div className="w-full max-w-sm bg-slate-900 border border-amber-500/30 rounded-3xl p-8 shadow-2xl flex flex-col items-center relative overflow-hidden">
        {/* Glow accent */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Heraldic Logo Emblem */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-500 to-amber-700 flex items-center justify-center shadow-lg shadow-amber-500/20 mb-4 border border-amber-300">
          <span className="text-2xl font-black text-slate-950 font-royal tracking-widest">ॐ</span>
        </div>

        <h2 className="text-lg font-bold text-slate-100 tracking-wide font-royal text-center">
          MAA DURGA ENTERPRISES
        </h2>
        <p className="text-xs text-amber-400 font-medium mb-6">POS Terminal Locked</p>

        {/* PIN Indicators */}
        <div className="flex items-center gap-3 mb-6">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = pin.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-200 border ${
                  error
                    ? 'border-red-500 bg-red-500 animate-bounce'
                    : isFilled
                    ? 'border-amber-400 bg-amber-400 scale-110 shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                    : 'border-slate-700 bg-slate-950'
                }`}
              />
            );
          })}
        </div>

        {error && (
          <p className="text-xs text-red-400 font-semibold mb-4 flex items-center gap-1 animate-pulse">
            <ShieldAlert className="w-3.5 h-3.5" /> Incorrect PIN. Please try again.
          </p>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[260px] mb-6">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigit(digit)}
              className="h-14 rounded-2xl bg-slate-800/80 hover:bg-slate-700 active:scale-95 text-xl font-bold text-slate-100 border border-slate-700/60 transition shadow-sm"
            >
              {digit}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setPin('')}
            className="h-14 rounded-2xl bg-slate-800/40 hover:bg-slate-800 text-xs font-semibold text-slate-400 active:scale-95 border border-slate-800 transition"
          >
            CLEAR
          </button>
          <button
            type="button"
            onClick={() => handleDigit('0')}
            className="h-14 rounded-2xl bg-slate-800/80 hover:bg-slate-700 active:scale-95 text-xl font-bold text-slate-100 border border-slate-700/60 transition shadow-sm"
          >
            0
          </button>
          <button
            type="button"
            onClick={handleBackspace}
            className="h-14 rounded-2xl bg-slate-800/40 hover:bg-slate-800 text-xs font-semibold text-slate-400 active:scale-95 border border-slate-800 transition"
          >
            ⌫ DEL
          </button>
        </div>

        {/* Default hint for user safety */}
        <div className="text-center">
          <p className="text-[11px] text-slate-500">
            Default Showroom PIN: <span className="font-mono-code font-bold text-amber-400">{settings.pinCode || '1234'}</span>
          </p>
          <p className="text-[10px] text-slate-600 mt-1">
            (PIN lock can be disabled or changed in Settings)
          </p>
        </div>
      </div>
    </div>
  );
};
