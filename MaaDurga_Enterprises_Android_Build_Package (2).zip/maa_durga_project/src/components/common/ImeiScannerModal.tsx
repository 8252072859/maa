import React, { useState, useRef, useEffect } from 'react';
import { Camera, X, Check, Flashlight, AlertCircle, RefreshCw } from 'lucide-react';
import { sounds } from '../../utils/soundEffects';

interface ImeiScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (scannedCode: string) => void;
  title?: string;
}

export const ImeiScannerModal: React.FC<ImeiScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
  title = "Scan Mobile IMEI / Barcode"
}) => {
  const [manualCode, setManualCode] = useState('');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [hasCamera, setHasCamera] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setManualCode('');
      setCameraError(null);
      return;
    }

    startCamera();

    return () => {
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setHasCamera(true);

      // Attempt BarcodeDetector API if supported in browser
      if ('BarcodeDetector' in window) {
        const barcodeDetector = new (window as any).BarcodeDetector({
          formats: ['code_128', 'code_39', 'ean_13', 'ean_8', 'qr_code', 'itf', 'upc_a']
        });

        const scanInterval = setInterval(async () => {
          if (!videoRef.current || videoRef.current.readyState < 2) return;
          try {
            const barcodes = await barcodeDetector.detect(videoRef.current);
            if (barcodes.length > 0) {
              const rawValue = barcodes[0].rawValue;
              if (rawValue) {
                clearInterval(scanInterval);
                sounds.playScanBeep();
                onScan(rawValue);
                onClose();
              }
            }
          } catch {}
        }, 300);

        return () => clearInterval(scanInterval);
      }
    } catch (err: any) {
      console.log('Camera error or permission denied:', err);
      setCameraError('Camera access unavailable. You can enter or paste the 15-digit IMEI or Barcode manually below.');
      setHasCamera(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setTorchOn(false);
    setHasCamera(false);
  };

  const toggleTorch = async () => {
    if (!streamRef.current) return;
    try {
      const track = streamRef.current.getVideoTracks()[0];
      const capabilities = (track as any).getCapabilities?.();
      if (capabilities && 'torch' in capabilities) {
        const nextState = !torchOn;
        await (track as any).applyConstraints({
          advanced: [{ torch: nextState }]
        });
        setTorchOn(nextState);
      } else {
        alert('Flashlight torch is not supported on this device/camera.');
      }
    } catch {}
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = manualCode.trim();
    if (!clean) return;
    sounds.playScanBeep();
    onScan(clean);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">{title}</h3>
              <p className="text-xs text-slate-400">Box Barcode or Handset IMEI Scanner</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Camera Viewfinder */}
        <div className="relative bg-black h-64 flex items-center justify-center overflow-hidden">
          {hasCamera ? (
            <>
              <video
                ref={videoRef}
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              {/* Scan Reticle */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-64 h-28 border-2 border-amber-400/80 rounded-xl relative">
                  <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-amber-400"></div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-amber-400"></div>
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-amber-400"></div>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-amber-400"></div>
                  {/* Laser line animation */}
                  <div className="w-full h-0.5 bg-red-500/90 shadow-[0_0_8px_rgba(239,68,68,1)] animate-pulse mt-14" />
                </div>
              </div>
              {/* Torch Button */}
              <button
                type="button"
                onClick={toggleTorch}
                className={`absolute top-3 right-3 p-2 rounded-full border backdrop-blur-md transition ${
                  torchOn ? 'bg-amber-400 text-slate-950 border-amber-300' : 'bg-black/50 text-slate-300 border-white/20 hover:text-white'
                }`}
                title="Toggle Torch"
              >
                <Flashlight className="w-4 h-4" />
              </button>
            </>
          ) : (
            <div className="px-6 text-center text-slate-400 flex flex-col items-center">
              <AlertCircle className="w-8 h-8 text-amber-400 mb-2" />
              <p className="text-xs">{cameraError || 'Camera inactive. Use manual barcode input.'}</p>
              <button
                type="button"
                onClick={startCamera}
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-slate-800 text-slate-200 hover:bg-slate-700 transition"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Retry Camera
              </button>
            </div>
          )}
        </div>

        {/* Manual Barcode / IMEI Input */}
        <div className="p-5 bg-slate-900 border-t border-slate-800">
          <form onSubmit={handleManualSubmit} className="space-y-3">
            <label className="block text-xs font-medium text-slate-300">
              Manual 15-Digit IMEI or Barcode Number
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                autoFocus
                placeholder="e.g. 864920048123901"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value.replace(/[^0-9a-zA-Z-]/g, ''))}
                className="flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-slate-100 placeholder-slate-500 font-mono-code text-sm focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                disabled={!manualCode.trim()}
                className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-xl text-sm flex items-center gap-1.5 hover:from-amber-400 hover:to-amber-500 disabled:opacity-40 disabled:cursor-not-allowed transition shadow-lg shadow-amber-500/20"
              >
                <Check className="w-4 h-4" /> Apply
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              Tip: You can also use a standard USB or Bluetooth handheld barcode scanner to input into this field.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};
