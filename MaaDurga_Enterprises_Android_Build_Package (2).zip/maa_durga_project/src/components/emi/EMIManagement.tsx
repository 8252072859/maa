import React, { useState } from 'react';
import {
  Landmark,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileSpreadsheet,
  Calendar,
  CreditCard
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { EMIRecord, FinanceCompany, EMIInstallment } from '../../types/erp';
import { formatCurrency, formatDate, getTodayDateString, exportToCSV } from '../../utils/formatters';

export const EMIManagement: React.FC = () => {
  const { emiRecords, createEMIRecord, payEMIInstallment, products, customers } = useERP();
  const { t } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<EMIRecord | null>(null);

  // New EMI Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [financeCompany, setFinanceCompany] = useState<FinanceCompany>('Bajaj Finserv');
  const [loanAccNo, setLoanAccNo] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [mobileModel, setMobileModel] = useState('');
  const [imei, setImei] = useState('');
  const [totalMobilePrice, setTotalMobilePrice] = useState<number>(0);
  const [downPayment, setDownPayment] = useState<number>(0);
  const [totalInstallments, setTotalInstallments] = useState<number>(6);
  const [firstEmiDate, setFirstEmiDate] = useState(getTodayDateString());
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Mark Installment Paid Modal
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [installmentIndexToPay, setInstallmentIndexToPay] = useState<number | null>(null);
  const [payMode, setPayMode] = useState('UPI');

  // Calculations for new EMI
  const financedAmount = Math.max(0, totalMobilePrice - downPayment);
  const monthlyInstallment = totalInstallments > 0 ? Math.round(financedAmount / totalInstallments) : 0;

  const filteredRecords = emiRecords.filter(
    (e) =>
      e.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.customerPhone.includes(searchTerm) ||
      e.mobileModel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.imei.includes(searchTerm) ||
      (e.loanAccountNumber && e.loanAccountNumber.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleCreateEMI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !mobileModel.trim() || totalMobilePrice <= 0) {
      setErrorMsg('Customer Name, Mobile Model, and Price are required.');
      return;
    }

    // Build installment schedule
    const installments: EMIInstallment[] = [];
    const startDate = new Date(firstEmiDate);

    for (let i = 1; i <= totalInstallments; i++) {
      const d = new Date(startDate);
      d.setMonth(d.getMonth() + (i - 1));
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');

      installments.push({
        installmentNumber: i,
        dueDate: `${year}-${month}-${day}`,
        amount: monthlyInstallment,
        status: 'pending'
      });
    }

    try {
      await createEMIRecord({
        customerId: `cust-${Date.now()}`,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        financeCompany,
        loanAccountNumber: loanAccNo.trim() || undefined,
        mobileModel: mobileModel.trim(),
        imei: imei.trim(),
        totalMobilePrice,
        downPayment,
        financedAmount,
        installmentAmount: monthlyInstallment,
        totalInstallments,
        paidInstallments: 0,
        firstEmiDate,
        nextDueDate: firstEmiDate,
        status: 'active',
        installments
      });

      setIsAddModalOpen(false);
      setCustomerName('');
      setCustomerPhone('');
      setMobileModel('');
      setImei('');
      setTotalMobilePrice(0);
      setDownPayment(0);
      setLoanAccNo('');
      setErrorMsg(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create finance plan.');
    }
  };

  const handleConfirmPayInstallment = async () => {
    if (!selectedRecord || installmentIndexToPay === null) return;
    await payEMIInstallment(selectedRecord.id, installmentIndexToPay, payMode);
    setIsPayModalOpen(false);
    setInstallmentIndexToPay(null);

    // Refresh selected record
    const updated = emiRecords.find((e) => e.id === selectedRecord.id);
    if (updated) setSelectedRecord(updated);
  };

  const handleExportEMI = () => {
    const rows = emiRecords.map((e) => ({
      'Customer': e.customerName,
      'Phone': e.customerPhone,
      'Finance Company': e.financeCompany,
      'Loan Acc #': e.loanAccountNumber || '',
      'Mobile': e.mobileModel,
      'IMEI': e.imei,
      'Total Price': e.totalMobilePrice,
      'Down Payment': e.downPayment,
      'Financed Amount': e.financedAmount,
      'Installment Amount': e.installmentAmount,
      'Total Tenor': e.totalInstallments,
      'Paid Tenor': e.paidInstallments,
      'Next Due Date': e.nextDueDate,
      'Status': e.status
    }));
    exportToCSV('MaaDurga_EMI_Finance_Records', rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Landmark className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('emiFinance')} MANAGEMENT
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Bajaj Finserv, TVS Credit, IDFC First & In-House Mobile Finance Installment Tracking.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>New Finance Entry</span>
        </button>
      </div>

      {/* Audit Clarity Notice */}
      <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-500/30 text-xs text-blue-200 flex items-start gap-2.5">
        <AlertCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">Finance & Cash Clarity:</span> Down payments received count toward shop cash collection. Financed balances are settled by the respective NBFC/Bank into the shop bank account or tracked under shop self-finance.
        </div>
      </div>

      {/* Search Toolbar */}
      <div className="flex items-center justify-between gap-3 p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search by Customer, Mobile, IMEI, or Loan Account #..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        </div>

        <button
          onClick={handleExportEMI}
          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition"
        >
          Export CSV
        </button>
      </div>

      {/* EMI Records List */}
      <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
        {filteredRecords.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No EMI finance records found. Click 'New Finance Entry' to create one.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5">Customer & Phone</th>
                  <th className="p-3.5">Finance Company</th>
                  <th className="p-3.5">Handset & IMEI</th>
                  <th className="p-3.5 text-right">Down Payment</th>
                  <th className="p-3.5 text-right">Financed Amt</th>
                  <th className="p-3.5 text-center">Tenor Progress</th>
                  <th className="p-3.5">Next Due Date</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-code">
                {filteredRecords.map((emi) => (
                  <tr key={emi.id} className="hover:bg-slate-800/30">
                    <td className="p-3.5 font-sans">
                      <div className="font-bold text-slate-100">{emi.customerName}</div>
                      <div className="text-[11px] text-slate-400 font-mono-code">{emi.customerPhone}</div>
                    </td>

                    <td className="p-3.5 font-sans">
                      <span className="font-bold text-blue-400 block">{emi.financeCompany}</span>
                      {emi.loanAccountNumber && (
                        <span className="text-[10px] text-slate-400 font-mono-code">
                          A/C: {emi.loanAccountNumber}
                        </span>
                      )}
                    </td>

                    <td className="p-3.5 font-sans">
                      <div className="font-semibold text-slate-200">{emi.mobileModel}</div>
                      <div className="text-[10px] text-amber-400 font-mono-code">IMEI: {emi.imei}</div>
                    </td>

                    <td className="p-3.5 text-right text-emerald-400 font-bold">
                      {formatCurrency(emi.downPayment)}
                    </td>

                    <td className="p-3.5 text-right text-slate-100 font-bold">
                      {formatCurrency(emi.financedAmount)}
                    </td>

                    <td className="p-3.5 text-center font-sans">
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-800 text-slate-200 border border-slate-700">
                        {emi.paidInstallments} / {emi.totalInstallments} EMIs
                      </span>
                      <div className="text-[10px] text-slate-400 font-mono-code mt-0.5">
                        {formatCurrency(emi.installmentAmount)}/mo
                      </div>
                    </td>

                    <td className="p-3.5 font-sans text-amber-300 font-semibold">
                      {formatDate(emi.nextDueDate)}
                    </td>

                    <td className="p-3.5 text-right font-sans">
                      <button
                        onClick={() => setSelectedRecord(emi)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
                      >
                        Installment Card
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* INSTALLMENT CARD MODAL */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100 font-royal">
                  EMI Installment Ledger: {selectedRecord.customerName}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {selectedRecord.mobileModel} · {selectedRecord.financeCompany} (IMEI: {selectedRecord.imei})
                </p>
              </div>
              <button
                onClick={() => setSelectedRecord(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 overflow-y-auto text-xs">
              <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono-code text-center">
                <div>
                  <span className="text-[10px] text-slate-400 font-sans">Financed Amount</span>
                  <div className="font-bold text-slate-100 text-sm mt-0.5">
                    {formatCurrency(selectedRecord.financedAmount)}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-sans">Down Payment</span>
                  <div className="font-bold text-emerald-400 text-sm mt-0.5">
                    {formatCurrency(selectedRecord.downPayment)}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-sans">Monthly EMI</span>
                  <div className="font-bold text-amber-300 text-sm mt-0.5">
                    {formatCurrency(selectedRecord.installmentAmount)}
                  </div>
                </div>
              </div>

              {/* Installments Table */}
              <div className="rounded-xl border border-slate-800 overflow-hidden">
                <table className="w-full text-left text-xs font-mono-code">
                  <thead>
                    <tr className="bg-slate-950 border-b border-slate-800 text-[10px] text-slate-400 uppercase">
                      <th className="p-2.5">#</th>
                      <th className="p-2.5">Due Date</th>
                      <th className="p-2.5">EMI Amount</th>
                      <th className="p-2.5">Status</th>
                      <th className="p-2.5">Paid On</th>
                      <th className="p-2.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {selectedRecord.installments.map((inst, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/30">
                        <td className="p-2.5 text-slate-400">EMI {inst.installmentNumber}</td>
                        <td className="p-2.5 font-sans">{formatDate(inst.dueDate)}</td>
                        <td className="p-2.5 font-bold text-slate-100">{formatCurrency(inst.amount)}</td>
                        <td className="p-2.5 font-sans">
                          {inst.status === 'paid' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                              ✓ Paid
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
                              Pending
                            </span>
                          )}
                        </td>
                        <td className="p-2.5 font-sans text-slate-400">
                          {inst.paidDate ? formatDate(inst.paidDate) : '—'}
                        </td>
                        <td className="p-2.5 text-right font-sans">
                          {inst.status === 'pending' && (
                            <button
                              onClick={() => {
                                setInstallmentIndexToPay(idx);
                                setIsPayModalOpen(true);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px]"
                            >
                              Mark Paid
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM PAY INSTALLMENT MODAL */}
      {isPayModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-100">
              Confirm Installment Payment
            </h3>
            <p className="text-slate-400">
              Mark Installment #{(installmentIndexToPay ?? 0) + 1} as paid by customer.
            </p>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Payment Mode</label>
              <select
                value={payMode}
                onChange={(e) => setPayMode(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
              >
                <option value="Cash">Cash at Counter</option>
                <option value="UPI">UPI (GPay/PhonePe)</option>
                <option value="Debit Card">Debit Card</option>
                <option value="Bank Direct Debit">Bank ECS / Direct Debit</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsPayModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmPayInstallment}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
              >
                Confirm Payment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NEW EMI MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100 font-royal">
                New Mobile Finance / EMI Record
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            {errorMsg && (
              <div className="mx-6 mt-4 p-3 rounded-xl bg-red-950/70 border border-red-500 text-red-200 text-xs">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleCreateEMI} className="p-6 space-y-3.5 text-xs overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Finance Partner *</label>
                  <select
                    value={financeCompany}
                    onChange={(e) => setFinanceCompany(e.target.value as FinanceCompany)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  >
                    <option value="Bajaj Finserv">Bajaj Finserv</option>
                    <option value="TVS Credit">TVS Credit</option>
                    <option value="IDFC First Bank">IDFC First Bank</option>
                    <option value="Home Credit">Home Credit</option>
                    <option value="DMI Finance">DMI Finance</option>
                    <option value="Shop Self-Finance">Shop Self-Finance</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Loan / Mandate Number</label>
                  <input
                    type="text"
                    placeholder="e.g. BJF-99120"
                    value={loanAccNo}
                    onChange={(e) => setLoanAccNo(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Customer Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Vikash Gupta"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Customer Phone *</label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="9876543210"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mobile Model *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Vivo V40 5G"
                    value={mobileModel}
                    onChange={(e) => setMobileModel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Handset IMEI *</label>
                  <input
                    type="text"
                    required
                    placeholder="15-digit IMEI"
                    value={imei}
                    onChange={(e) => setImei(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Total Mobile Price (₹) *</label>
                  <input
                    type="number"
                    value={totalMobilePrice}
                    onChange={(e) => setTotalMobilePrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Down Payment (₹)</label>
                  <input
                    type="number"
                    value={downPayment}
                    onChange={(e) => setDownPayment(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Tenor (Months)</label>
                  <select
                    value={totalInstallments}
                    onChange={(e) => setTotalInstallments(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  >
                    <option value={3}>3 Months</option>
                    <option value={6}>6 Months</option>
                    <option value={9}>9 Months</option>
                    <option value={12}>12 Months</option>
                    <option value={18}>18 Months</option>
                    <option value={24}>24 Months</option>
                  </select>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1 font-mono-code">
                <div className="flex justify-between text-slate-400">
                  <span>Financed Principal:</span>
                  <span>{formatCurrency(financedAmount)}</span>
                </div>
                <div className="flex justify-between text-amber-300 font-bold text-sm">
                  <span>Monthly Installment:</span>
                  <span>{formatCurrency(monthlyInstallment)} / month</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Create Finance Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
