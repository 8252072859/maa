import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, 
  Phone, 
  KeyRound, 
  ArrowRight, 
  RotateCw, 
  AlertCircle, 
  CheckCircle2, 
  Lock,
  MessageCircle,
  ExternalLink,
  Smartphone,
  Download,
  FileCode,
  QrCode,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { sounds } from '../../utils/soundEffects';
import { ApkInstallModal } from '../common/ApkInstallModal';
import { ApkTopBar } from '../common/ApkTopBar';

export const AdminLoginScreen: React.FC = () => {
  const { sendOtp, verifyOtp } = useAuth();

  const [phone, setPhone] = useState('+91 8252072859');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [channel, setChannel] = useState<'whatsapp' | 'sms'>('whatsapp');
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [whatsappDirectUrl, setWhatsappDirectUrl] = useState<string | null>(null);
  const [generatedOtpCode, setGeneratedOtpCode] = useState<string | null>(null);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // Timers
  const [resendCooldown, setResendCooldown] = useState<number>(0);
  const [otpExpirySeconds, setOtpExpirySeconds] = useState<number>(300); // 5 minutes

  const otpInputsRef = useRef<(HTMLInputElement | null)[]>([]);

  // Resend countdown
  useEffect(() => {
    let timer: any = null;
    if (resendCooldown > 0) {
      timer = setInterval(() => {
        setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendCooldown]);

  // Expiry countdown
  useEffect(() => {
    let timer: any = null;
    if (step === 'otp' && otpExpirySeconds > 0) {
      timer = setInterval(() => {
        setOtpExpirySeconds((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, otpExpirySeconds]);

  // Format timer MM:SS
  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Step 1: Send OTP via WhatsApp or SMS
  const handleSendOtp = async (selectedChannel: 'whatsapp' | 'sms' = channel) => {
    setErrorMsg(null);
    setIsLoading(true);
    setChannel(selectedChannel);

    try {
      const clean = phone.replace(/\s+/g, '');
      const response = await sendOtp(clean, selectedChannel);
      sounds.playSuccessChime();
      setStep('otp');
      setResendCooldown(response.resendCooldown || 30);
      setOtpExpirySeconds(response.expiresInSeconds || 300);
      setOtpDigits(['', '', '', '', '', '']);
      setWhatsappDirectUrl(response.whatsappUrl || null);
      setGeneratedOtpCode(null);

      // focus first input after transition
      setTimeout(() => {
        otpInputsRef.current[0]?.focus();
      }, 200);
    } catch (err: any) {
      sounds.playErrorBuzz();
      setErrorMsg(err.message || 'Failed to dispatch verification OTP.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle individual OTP digit change
  const handleOtpChange = (index: number, value: string) => {
    const cleaned = value.replace(/[^0-9]/g, '');
    if (!cleaned) {
      const updated = [...otpDigits];
      updated[index] = '';
      setOtpDigits(updated);
      return;
    }

    const updated = [...otpDigits];
    updated[index] = cleaned.slice(-1);
    setOtpDigits(updated);

    // Auto-focus next box
    if (index < 5 && cleaned) {
      otpInputsRef.current[index + 1]?.focus();
    }

    // Auto-submit if all 6 filled
    if (index === 5 && cleaned) {
      const fullOtp = updated.join('');
      if (fullOtp.length === 6) {
        submitOtp(fullOtp);
      }
    }
  };

  // Handle Paste
  const handleOtpPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/[^0-9]/g, '').slice(0, 6);
    if (pasted.length === 6) {
      const digits = pasted.split('');
      setOtpDigits(digits);
      otpInputsRef.current[5]?.focus();
      submitOtp(pasted);
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputsRef.current[index - 1]?.focus();
    }
  };

  // Step 2: Verify OTP
  const submitOtp = async (codeToVerify?: string) => {
    const fullOtp = codeToVerify || otpDigits.join('');
    if (fullOtp.length !== 6) {
      setErrorMsg('Please enter all 6 digits of the OTP.');
      return;
    }

    setErrorMsg(null);
    setIsLoading(true);

    try {
      const clean = phone.replace(/\s+/g, '');
      await verifyOtp(clean, fullOtp);
      sounds.playSuccessChime();
    } catch (err: any) {
      sounds.playErrorBuzz();
      setErrorMsg(err.message || 'Invalid or expired OTP. Please check and retry.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickFill = () => {
    if (generatedOtpCode) {
      sounds.playScanBeep();
      setOtpDigits(generatedOtpCode.split(''));
      submitOtp(generatedOtpCode);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b14] flex flex-col relative select-none">
      {/* 1. TOP APK BAR - PROMINENTLY AT THE VERY TOP OF SCREEN */}
      <ApkTopBar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden">
        {/* Background radial ambient glows */}
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* TOP APK HIGHLIGHT BANNER RIGHT ABOVE LOGIN BOX */}
        <div className="w-full max-w-md mb-4 z-10">
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/90 via-slate-900 to-amber-950/90 border-2 border-amber-400/80 shadow-2xl flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400 shrink-0">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-black text-amber-200 uppercase tracking-wide flex items-center gap-1.5">
                  <span>Android APK Build Required</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                </div>
                <div className="text-[11px] font-mono-code text-slate-300">
                  Build APK from project source
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <a
                href="#android-apk-build-required"
                onClick={(e) => { e.preventDefault(); setIsApkModalOpen(true); }}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:brightness-110 text-slate-950 font-black text-[11px] uppercase tracking-wider flex items-center gap-1 shadow-md cursor-pointer transition"
              >
                <Download className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Build Info</span>
              </a>
              <button
                type="button"
                onClick={() => setIsApkModalOpen(true)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs cursor-pointer transition"
                title="View QR Code & Install Instructions"
              >
                <QrCode className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Main Login Card */}
        <div className="relative w-full max-w-md bg-[#0d1322] border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/90 flex flex-col items-center">
          {/* Crown / Trishul Emblem */}
          <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-400 to-amber-200 p-[2px] shadow-lg shadow-amber-500/25 mb-4">
            <div className="w-full h-full bg-[#0a0f1d] rounded-[14px] flex items-center justify-center">
              <span className="text-2xl font-black text-amber-400 font-royal">🔱</span>
            </div>
          </div>

          <h1 className="text-lg sm:text-xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-100 font-royal tracking-wider text-center">
            MAA DURGA ENTERPRISES
          </h1>
          <p className="text-xs text-emerald-400 font-bold tracking-wide mt-1 flex items-center gap-1.5">
            <MessageCircle className="w-3.5 h-3.5 fill-emerald-400 text-slate-900" />
            WHATSAPP OTP LOGIN SYSTEM
          </p>

          {/* Error Notification */}
          {errorMsg && (
            <div className="w-full mt-4 p-3 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span className="leading-snug">{errorMsg}</span>
            </div>
          )}

          {/* STEP 1: MOBILE NUMBER & SEND ON WHATSAPP */}
          {step === 'phone' && (
            <div className="w-full mt-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Admin WhatsApp Mobile Number</span>
                  <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Admin Number
                  </span>
                </label>

                <div className="relative">
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code font-bold text-sm tracking-wide focus:outline-none focus:border-emerald-400 transition"
                    placeholder="+91 8252072859"
                  />
                  <Phone className="w-4 h-4 text-emerald-400 absolute left-3.5 top-3.5" />
                </div>
                <div className="mt-2 p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/20 text-[11px] text-emerald-200/90 leading-relaxed">
                  📲 Login karte samay 6-digit OTP code sidhe <span className="font-bold text-emerald-300 font-mono-code">+91 8252072859</span> ke WhatsApp par bheja jayega. Us OTP se Admin Dashboard open hoga.
                </div>
              </div>

              {/* Big WhatsApp Send Button */}
              <button
                type="button"
                disabled={isLoading}
                onClick={() => handleSendOtp('whatsapp')}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-green-500 hover:brightness-110 active:scale-95 text-white font-black text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-emerald-600/30 disabled:opacity-50 transition cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RotateCw className="w-4 h-4 animate-spin" />
                    <span>WhatsApp OTP Sending...</span>
                  </>
                ) : (
                  <>
                    <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                    <span>WhatsApp Pe OTP Bhejo</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              {/* Alternative SMS button */}
              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => handleSendOtp('sms')}
                  className="text-xs text-slate-400 hover:text-slate-200 transition"
                >
                  Or receive via regular SMS instead
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: 6-DIGIT OTP VERIFICATION WITH WHATSAPP LINK & AUTO-FILL */}
          {step === 'otp' && (
            <div className="w-full mt-6 space-y-4">
              <div className="text-center">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold mb-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>OTP Sent to WhatsApp: +91 8252072859</span>
                </div>
                <p className="text-xs text-slate-300">
                  Enter the 6-digit verification code below to login
                </p>
              </div>

              {/* WhatsApp Direct Open Button */}
              {whatsappDirectUrl && (
                <a
                  href={whatsappDirectUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-2.5 px-3 rounded-xl bg-emerald-950/90 hover:bg-emerald-900 border border-emerald-400 text-emerald-200 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition shadow-lg cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 fill-emerald-400 text-slate-900" />
                  <span>Open WhatsApp to View OTP (व्हाट्सएप में देखें)</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              {/* Security Verification & 1-Tap Auto Fill */}
              {generatedOtpCode && (
                <div className="p-3 rounded-2xl bg-slate-950 border border-amber-500/40 text-center font-mono-code text-xs text-amber-300 shadow-inner flex flex-col items-center gap-2">
                  <div className="text-[11px] text-slate-400 font-sans flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>WhatsApp Security OTP Generated for 8252072859:</span>
                  </div>
                  <div className="text-xl font-black text-amber-300 tracking-widest bg-amber-500/10 px-4 py-1 rounded-lg border border-amber-500/30">
                    {generatedOtpCode}
                  </div>
                  <button
                    type="button"
                    onClick={handleQuickFill}
                    className="w-full py-1.5 px-3 rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>1-Tap Auto Fill & Login (तुरंत भरें और लॉगिन करें)</span>
                  </button>
                </div>
              )}

              {/* 6-box OTP entry */}
              <div className="flex items-center justify-center gap-2 sm:gap-2.5 pt-1">
                {otpDigits.map((digit, idx) => (
                  <input
                    key={idx}
                    ref={(el) => {
                      otpInputsRef.current[idx] = el;
                    }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(idx, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(idx, e)}
                    onPaste={idx === 0 ? handleOtpPaste : undefined}
                    className="w-11 h-13 sm:w-12 sm:h-14 text-center rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code font-black text-xl sm:text-2xl focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/50 shadow-inner"
                  />
                ))}
              </div>

              {/* Expiry & Resend Timers */}
              <div className="flex items-center justify-between text-xs px-1 text-slate-400">
                <div className="flex items-center gap-1">
                  <span>Expires in:</span>
                  <span className={`font-mono-code font-bold ${otpExpirySeconds < 60 ? 'text-red-400' : 'text-amber-300'}`}>
                    {formatTimer(otpExpirySeconds)}
                  </span>
                </div>

                <div>
                  {resendCooldown > 0 ? (
                    <span className="text-slate-500 font-mono-code">
                      Resend in {resendCooldown}s
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSendOtp(channel)}
                      className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCw className="w-3.5 h-3.5" /> Resend on WhatsApp
                    </button>
                  )}
                </div>
              </div>

              {/* Verify Button */}
              <button
                type="button"
                disabled={isLoading || otpDigits.join('').length !== 6 || otpExpirySeconds === 0}
                onClick={() => submitOtp()}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:brightness-110 active:scale-95 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-amber-500/25 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RotateCw className="w-4 h-4 animate-spin" />
                    <span>Verifying OTP...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
                    <span>Verify OTP & Login (लॉगिन करें)</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setStep('phone')}
                className="text-[11px] text-slate-400 hover:text-white block mx-auto pt-1 cursor-pointer"
              >
                ← Back to Mobile Entry
              </button>
            </div>
          )}

          {/* Security Footer Notice */}
          <div className="w-full mt-6 pt-4 border-t border-slate-800/80 text-center">
            <p className="text-[10px] text-slate-400 flex items-center justify-center gap-1">
              <Lock className="w-3 h-3 text-emerald-400" />
              WhatsApp OTP Verification for Admin +91 8252072859
            </p>
          </div>
        </div>
      </div>

      {/* APK Installation Modal */}
      <ApkInstallModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </div>
  );
};
