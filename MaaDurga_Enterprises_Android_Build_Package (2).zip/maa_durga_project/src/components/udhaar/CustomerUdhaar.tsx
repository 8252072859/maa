import React, { useState } from 'react';
import {
  BookOpen,
  UserPlus,
  Search,
  Phone,
  Coins,
  ArrowDownLeft,
  Share2,
  FileSpreadsheet,
  CheckCircle2,
  History,
  Receipt,
  UserCheck
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { Customer, CustomerPayment } from '../../types/erp';
import { formatCurrency, formatDate, getTodayDateString, getCurrentTimeString, buildWhatsAppBillUrl, exportToCSV } from '../../utils/formatters';

export const CustomerUdhaar: React.FC = () => {
  const {
    customers,
    customerPayments,
    invoices,
    addCustomer,
    recordCustomerPayment,
    settings
  } = useERP();
  const { t } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterUdhaarOnly, setFilterUdhaarOnly] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  // New Customer Modal
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [phoneInput, setPhoneInput] = useState('');
  const [addressInput, setAddressInput] = useState('');
  const [notesInput, setNotesInput] = useState('');

  // Receive Payment Modal (उधार जमा)
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [customerToPay, setCustomerToPay] = useState<Customer | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMode, setPayMode] = useState<'cash' | 'upi' | 'bank'>('cash');
  const [payNotes, setPayNotes] = useState('');

  // Total Market Udhaar
  const totalMarketUdhaar = customers.reduce((sum, c) => sum + (c.currentUdhaar || 0), 0);
  const totalCustomerPurchases = customers.reduce((sum, c) => sum + c.totalPurchases, 0);
  const totalCustomerCollections = customers.reduce((sum, c) => sum + c.totalPaid, 0);

  // Filtering
  const filteredCustomers = customers.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm) ||
      (c.address && c.address.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesUdhaar = !filterUdhaarOnly || c.currentUdhaar > 0;

    return matchesSearch && matchesUdhaar;
  });

  const handleCreateCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;

    await addCustomer({
      name: nameInput.trim(),
      phone: phoneInput.trim(),
      address: addressInput.trim() || undefined,
      notes: notesInput.trim() || undefined
    });

    setIsAddCustomerOpen(false);
    setNameInput('');
    setPhoneInput('');
    setAddressInput('');
    setNotesInput('');
  };

  const handleSavePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerToPay || payAmount <= 0) return;

    await recordCustomerPayment({
      customerId: customerToPay.id,
      customerName: customerToPay.name,
      amount: payAmount,
      date: getTodayDateString(),
      time: getCurrentTimeString(),
      paymentMode: payMode,
      notes: payNotes.trim() || undefined
    });

    setIsPayModalOpen(false);
    setCustomerToPay(null);
    setPayAmount(0);
    setPayNotes('');
  };

  const handleExportKhata = () => {
    const rows = filteredCustomers.map((c) => ({
      'Customer Name': c.name,
      'Phone': c.phone,
      'Address': c.address || '',
      'Total Purchases': c.totalPurchases,
      'Total Paid': c.totalPaid,
      'Current Udhaar Due': c.currentUdhaar,
      'Last Purchase Date': c.lastPurchaseDate || ''
    }));
    exportToCSV('MaaDurga_Customer_Khata', rows);
  };

  const buildReminderMsg = (cust: Customer) => {
    return `Namaste ${cust.name} ji,\nThis is a polite payment reminder from *${settings.shopName || 'MAA DURGA ENTERPRISES'}*.\n\nYour outstanding Udhaar balance is *${formatCurrency(cust.currentUdhaar)}*.\nKindly settle the dues at your earliest convenience via Cash or UPI.\n\n*Shop UPI ID:* ${settings.upiId}\n*Address:* ${settings.address}, ${settings.city}\n*Contact:* ${settings.phone}\n\nThank you! 🔱`;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('udhaarKhata')} (CUSTOMER LEDGER)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time balance tracking, instant payment collection & WhatsApp payment reminders.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsAddCustomerOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
          >
            <UserPlus className="w-4 h-4 stroke-[2.5]" />
            <span>Add New Customer</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Udhaar in Market</span>
          <div className="text-xl sm:text-2xl font-black text-red-400 font-mono-code mt-1">
            {formatCurrency(totalMarketUdhaar)}
          </div>
          <span className="text-[10px] text-slate-500">
            {customers.filter((c) => c.currentUdhaar > 0).length} Customers with Pending Balances
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Customer Purchases</span>
          <div className="text-xl sm:text-2xl font-black text-slate-100 font-mono-code mt-1">
            {formatCurrency(totalCustomerPurchases)}
          </div>
          <span className="text-[10px] text-slate-500">Gross Sales Volume</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Payment Collected</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono-code mt-1">
            {formatCurrency(totalCustomerCollections)}
          </div>
          <span className="text-[10px] text-slate-500">Cash / UPI / Bank Realized</span>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            placeholder="Search customer by Name, Mobile Number or Address..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setFilterUdhaarOnly(!filterUdhaarOnly)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold border transition ${
              filterUdhaarOnly
                ? 'bg-red-500/20 text-red-300 border-red-500/40'
                : 'bg-slate-950 text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            Udhaar Due Only ({customers.filter((c) => c.currentUdhaar > 0).length})
          </button>

          <button
            onClick={handleExportKhata}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition"
          >
            Export Excel
          </button>
        </div>
      </div>

      {/* Customer Khata Table */}
      <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
        {filteredCustomers.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No customers found matching your search.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5">Customer Name</th>
                  <th className="p-3.5">Phone Number</th>
                  <th className="p-3.5">Address</th>
                  <th className="p-3.5 text-right">Total Purchases</th>
                  <th className="p-3.5 text-right">Total Paid</th>
                  <th className="p-3.5 text-right">Current Udhaar Due</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-code">
                {filteredCustomers.map((cust) => {
                  const hasUdhaar = cust.currentUdhaar > 0;

                  return (
                    <tr
                      key={cust.id}
                      className={`hover:bg-slate-800/30 transition ${
                        hasUdhaar ? 'bg-red-950/5' : ''
                      }`}
                    >
                      <td className="p-3.5 font-sans">
                        <button
                          onClick={() => setSelectedCustomer(cust)}
                          className="font-bold text-slate-100 hover:text-amber-400 text-left transition"
                        >
                          {cust.name}
                        </button>
                        {cust.notes && (
                          <div className="text-[10px] text-slate-500 truncate max-w-xs font-normal">
                            {cust.notes}
                          </div>
                        )}
                      </td>

                      <td className="p-3.5 text-slate-300">
                        {cust.phone}
                      </td>

                      <td className="p-3.5 font-sans text-slate-400">
                        {cust.address || '—'}
                      </td>

                      <td className="p-3.5 text-right text-slate-300">
                        {formatCurrency(cust.totalPurchases)}
                      </td>

                      <td className="p-3.5 text-right text-emerald-400">
                        {formatCurrency(cust.totalPaid)}
                      </td>

                      <td className="p-3.5 text-right font-black">
                        {hasUdhaar ? (
                          <span className="text-red-400 text-sm">
                            {formatCurrency(cust.currentUdhaar)}
                          </span>
                        ) : (
                          <span className="text-emerald-500 font-sans text-xs">
                            ✓ No Dues
                          </span>
                        )}
                      </td>

                      <td className="p-3.5 text-right font-sans">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Receive Payment Button (उधार जमा) */}
                          {hasUdhaar && (
                            <button
                              onClick={() => {
                                setCustomerToPay(cust);
                                setPayAmount(cust.currentUdhaar);
                                setIsPayModalOpen(true);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1 shadow-sm transition"
                              title="Receive Payment (उधार जमा)"
                            >
                              <ArrowDownLeft className="w-3.5 h-3.5" />
                              <span>उधार जमा</span>
                            </button>
                          )}

                          {/* WhatsApp Reminder (तगादा संदेश) */}
                          {hasUdhaar && cust.phone && (
                            <a
                              href={buildWhatsAppBillUrl(cust.phone, buildReminderMsg(cust))}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 transition"
                              title="Send WhatsApp Payment Reminder"
                            >
                              <Share2 className="w-3.5 h-3.5" />
                            </a>
                          )}

                          {/* View Ledger */}
                          <button
                            onClick={() => setSelectedCustomer(cust)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition text-[11px]"
                            title="View Full Ledger"
                          >
                            <History className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* RECEIVE PAYMENT (उधार जमा) MODAL */}
      {isPayModalOpen && customerToPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-emerald-500/40 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <ArrowDownLeft className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100 font-royal">
                  Receive Payment (उधार जमा)
                </h3>
                <p className="text-xs text-slate-400">
                  {customerToPay.name} · Current Udhaar: {formatCurrency(customerToPay.currentUdhaar)}
                </p>
              </div>
            </div>

            <form onSubmit={handleSavePayment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Amount Received (₹) *
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  max={customerToPay.currentUdhaar}
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code font-bold text-sm focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Payment Mode
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['cash', 'upi', 'bank'].map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setPayMode(m as any)}
                      className={`py-2 rounded-xl border text-center uppercase font-bold transition ${
                        payMode === m
                          ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Notes / Reference No.
                </label>
                <input
                  type="text"
                  placeholder="e.g. Paid in Cash at shop counter"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-emerald-400"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 flex justify-between font-mono-code">
                <span>Remaining Balance after payment:</span>
                <span className="font-bold text-amber-300">
                  {formatCurrency(Math.max(0, customerToPay.currentUdhaar - payAmount))}
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPayModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-bold shadow-lg shadow-emerald-500/20"
                >
                  Record Payment & Update Khata
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CUSTOMER FULL LEDGER DETAIL MODAL */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100 font-royal">
                  {selectedCustomer.name}'s Khata Statement
                </h3>
                <p className="text-[11px] text-slate-400">
                  Ph: {selectedCustomer.phone} · {selectedCustomer.address || 'Patna'}
                </p>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 overflow-y-auto text-xs">
              {/* Summary Stats */}
              <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono-code text-center">
                <div>
                  <span className="text-[10px] text-slate-400 font-sans">Total Purchases</span>
                  <div className="font-bold text-slate-100 text-sm mt-0.5">
                    {formatCurrency(selectedCustomer.totalPurchases)}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-sans">Total Paid</span>
                  <div className="font-bold text-emerald-400 text-sm mt-0.5">
                    {formatCurrency(selectedCustomer.totalPaid)}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-sans">Current Udhaar Due</span>
                  <div className="font-black text-red-400 text-sm mt-0.5">
                    {formatCurrency(selectedCustomer.currentUdhaar)}
                  </div>
                </div>
              </div>

              {/* Transactions History */}
              <div className="space-y-2">
                <h4 className="font-bold text-slate-200">
                  Invoices & Payments Timeline
                </h4>

                <div className="space-y-2">
                  {invoices
                    .filter((i) => i.customerId === selectedCustomer.id || i.customerPhone === selectedCustomer.phone)
                    .map((inv) => (
                      <div
                        key={inv.id}
                        className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-semibold text-slate-200 font-mono-code">
                            Bill #{inv.invoiceNumber}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {formatDate(inv.date)} · {inv.items.map((i) => `${i.brand} ${i.productName}`).join(', ')}
                          </div>
                        </div>

                        <div className="text-right font-mono-code">
                          <div className="font-bold text-slate-100">{formatCurrency(inv.grandTotal)}</div>
                          {inv.dueAmount > 0 && (
                            <div className="text-[10px] text-red-400">Udhaar: {formatCurrency(inv.dueAmount)}</div>
                          )}
                        </div>
                      </div>
                    ))}

                  {/* Customer Payments */}
                  {customerPayments
                    .filter((cp) => cp.customerId === selectedCustomer.id)
                    .map((pay) => (
                      <div
                        key={pay.id}
                        className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-semibold text-emerald-400 flex items-center gap-1">
                            <ArrowDownLeft className="w-3.5 h-3.5" />
                            <span>Payment Received ({pay.paymentMode.toUpperCase()})</span>
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {formatDate(pay.date)} · {pay.notes || 'Counter Payment'}
                          </div>
                        </div>

                        <div className="font-mono-code font-bold text-emerald-400 text-sm">
                          + {formatCurrency(pay.amount)}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADD CUSTOMER MODAL */}
      {isAddCustomerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 font-royal">
              Register New Customer in Khata
            </h3>

            <form onSubmit={handleCreateCustomer} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Customer Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Mobile Number (10 digits) *</label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  placeholder="9876543210"
                  value={phoneInput}
                  onChange={(e) => setPhoneInput(e.target.value.replace(/[^0-9]/g, ''))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Address / Landmark</label>
                <input
                  type="text"
                  placeholder="e.g. Boring Road, Patna"
                  value={addressInput}
                  onChange={(e) => setAddressInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Notes / Guarantor</label>
                <input
                  type="text"
                  placeholder="e.g. Referred by Suresh Ji"
                  value={notesInput}
                  onChange={(e) => setNotesInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddCustomerOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Save to Khata
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
