import React, { useState } from 'react';
import {
  FileText,
  Search,
  Printer,
  Share2,
  Trash2,
  Filter,
  FileSpreadsheet,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { Invoice } from '../../types/erp';
import { formatCurrency, formatDate, buildWhatsAppBillUrl, exportToCSV } from '../../utils/formatters';
import { BillPrintModal } from './BillPrintModal';

export const BillsHistory: React.FC = () => {
  const { invoices, cancelInvoice, settings } = useERP();
  const { t } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [invoiceToCancel, setInvoiceToCancel] = useState<Invoice | null>(null);
  const [cancelReason, setCancelReason] = useState('Customer Return / Mistaken Bill');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');

  const filteredInvoices = invoices.filter((inv) => {
    const matchesSearch =
      inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.customerPhone.includes(searchTerm) ||
      inv.items.some(
        (i) =>
          i.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (i.imei1 && i.imei1.includes(searchTerm)) ||
          (i.imei2 && i.imei2.includes(searchTerm))
      );

    const matchesPayment = paymentFilter === 'all' || inv.paymentMode === paymentFilter;

    return matchesSearch && matchesPayment;
  });

  const handleExportCSV = () => {
    const rows = filteredInvoices.map((inv) => ({
      'Invoice No': inv.invoiceNumber,
      'Date': inv.date,
      'Time': inv.time,
      'Customer Name': inv.customerName,
      'Customer Phone': inv.customerPhone,
      'Products': inv.items.map((i) => `${i.brand} ${i.productName} (Qty: ${i.quantity})`).join('; '),
      'IMEIs': inv.items.map((i) => i.imei1 || '').filter(Boolean).join('; '),
      'Grand Total': inv.grandTotal,
      'Paid Amount': inv.paidAmount,
      'Due Balance': inv.dueAmount,
      'Payment Mode': inv.paymentMode,
      'Tax Type': inv.gstType,
      'Status': inv.isCancelled ? 'CANCELLED' : 'ACTIVE'
    }));
    exportToCSV('MaaDurga_Sales_History', rows);
  };

  const handleConfirmCancel = async () => {
    if (!invoiceToCancel) return;
    await cancelInvoice(invoiceToCancel.id, cancelReason);
    setInvoiceToCancel(null);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('billsHistory')} ({invoices.length})
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Search sales bills by Invoice Number, Customer, Phone or Mobile IMEI.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold self-start sm:self-auto transition"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          <span>{t('exportCsv')}</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            placeholder="Search by Invoice #, Customer, Phone, or IMEI..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value)}
            className="px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-300 text-xs focus:outline-none focus:border-amber-400 w-full sm:w-auto"
          >
            <option value="all">All Payment Modes</option>
            <option value="cash">Cash Only</option>
            <option value="upi">UPI Only</option>
            <option value="udhar">Udhar (Credit)</option>
            <option value="card">Card</option>
            <option value="bank">Bank</option>
          </select>
        </div>
      </div>

      {/* Invoices List Table */}
      <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
        {filteredInvoices.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No invoices found matching your criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5">Invoice #</th>
                  <th className="p-3.5">Date & Time</th>
                  <th className="p-3.5">Customer</th>
                  <th className="p-3.5">Items & Handset IMEIs</th>
                  <th className="p-3.5 text-right">Grand Total</th>
                  <th className="p-3.5 text-center">Payment</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-code">
                {filteredInvoices.map((inv) => (
                  <tr
                    key={inv.id}
                    className={`hover:bg-slate-800/30 transition ${
                      inv.isCancelled ? 'opacity-60 bg-red-950/10' : ''
                    }`}
                  >
                    <td className="p-3.5 font-bold text-amber-300">
                      {inv.invoiceNumber}
                    </td>

                    <td className="p-3.5 text-slate-300 font-sans">
                      <div>{formatDate(inv.date)}</div>
                      <div className="text-[10px] text-slate-500">{inv.time}</div>
                    </td>

                    <td className="p-3.5 font-sans">
                      <div className="font-bold text-slate-100">{inv.customerName}</div>
                      <div className="text-[11px] text-slate-400 font-mono-code">
                        {inv.customerPhone || 'No Phone'}
                      </div>
                    </td>

                    <td className="p-3.5 font-sans max-w-xs">
                      {inv.items.map((item, idx) => (
                        <div key={idx} className="text-slate-200">
                          <span className="font-semibold">
                            {item.brand} {item.productName}
                          </span>
                          {item.imei1 && (
                            <span className="text-[10px] text-amber-400 font-mono-code block">
                              IMEI: {item.imei1}
                            </span>
                          )}
                        </div>
                      ))}
                    </td>

                    <td className="p-3.5 text-right">
                      <div className="font-bold text-slate-100">
                        {formatCurrency(inv.grandTotal)}
                      </div>
                      {inv.dueAmount > 0 && (
                        <div className="text-[10px] text-red-400">
                          Due: {formatCurrency(inv.dueAmount)}
                        </div>
                      )}
                    </td>

                    <td className="p-3.5 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-sans ${
                        inv.paymentMode === 'cash'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : inv.paymentMode === 'upi'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                          : inv.paymentMode === 'udhar'
                          ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                          : 'bg-slate-800 text-slate-300'
                      }`}>
                        {inv.paymentMode}
                      </span>
                    </td>

                    <td className="p-3.5 text-center font-sans">
                      {inv.isCancelled ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/10 text-red-400 border border-red-500/30">
                          CANCELLED
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          ACTIVE
                        </span>
                      )}
                    </td>

                    <td className="p-3.5 text-right font-sans">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setSelectedInvoice(inv)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                          title="Print / View Invoice"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        <a
                          href={buildWhatsAppBillUrl(
                            inv.customerPhone,
                            `Namaste ${inv.customerName}, Thank you for your purchase from *${settings.shopName}*.\n\n*Invoice:* ${inv.invoiceNumber}\n*Date:* ${inv.date}\n*Amount:* ${formatCurrency(inv.grandTotal)}\n*Paid:* ${formatCurrency(inv.paidAmount)}\n${inv.dueAmount > 0 ? `*Balance Due:* ${formatCurrency(inv.dueAmount)}\n` : ''}\nThank you!`
                          )}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 transition"
                          title="Share on WhatsApp"
                        >
                          <Share2 className="w-4 h-4" />
                        </a>

                        {!inv.isCancelled && (
                          <button
                            onClick={() => setInvoiceToCancel(inv)}
                            className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 transition"
                            title="Cancel Bill & Restore Stock"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Bill Print Modal */}
      {selectedInvoice && (
        <BillPrintModal
          invoice={selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
        />
      )}

      {/* Cancel Confirmation Modal */}
      {invoiceToCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-red-500/40 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-100">
                  Cancel Invoice #{invoiceToCancel.invoiceNumber}?
                </h3>
                <p className="text-xs text-slate-400">
                  This will restore all handset IMEIs and items back to active stock, and reverse any customer Udhaar balance.
                </p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Reason for Cancellation
              </label>
              <input
                type="text"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-red-400"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setInvoiceToCancel(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
              >
                No, Keep Bill
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-lg shadow-red-600/30"
              >
                Yes, Cancel Bill
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
