import React, { useState } from 'react';
import { X, Printer, Share2, Download, Copy, Check, Eye } from 'lucide-react';
import { Invoice } from '../../types/erp';
import { useERP } from '../../context/ERPContext';
import { formatCurrency, formatDate, numberToWordsIndian, buildWhatsAppBillUrl } from '../../utils/formatters';
import { UpiQrCode } from '../common/UpiQrCode';

interface BillPrintModalProps {
  invoice: Invoice;
  onClose: () => void;
}

export const BillPrintModal: React.FC<BillPrintModalProps> = ({ invoice, onClose }) => {
  const { settings } = useERP();
  const [printFormat, setPrintFormat] = useState<'a4' | 'thermal80' | 'thermal58'>('a4');
  const [copied, setCopied] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const whatsappMessage = `Namaste ${invoice.customerName || 'Customer'},\nThank you for shopping at *${settings.shopName || 'MAA DURGA ENTERPRISES'}*!\n\n*Invoice No:* ${invoice.invoiceNumber}\n*Date:* ${formatDate(invoice.date)}\n*Items:* ${invoice.items.map(i => `${i.brand} ${i.productName} (IMEI: ${i.imei1 || 'N/A'})`).join(', ')}\n*Grand Total:* ${formatCurrency(invoice.grandTotal)}\n*Paid:* ${formatCurrency(invoice.paidAmount)}\n${invoice.dueAmount > 0 ? `*Remaining Udhaar Due:* ${formatCurrency(invoice.dueAmount)}\n` : ''}\n*Shop Address:* ${settings.address}, ${settings.city}\n*Contact:* ${settings.phone}\n\nThank you, please visit us again! 🔱`;

  const handleCopyText = () => {
    navigator.clipboard.writeText(whatsappMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl flex flex-col max-h-[96vh] overflow-hidden">
        {/* Modal Controls Header (no-print) */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3.5 bg-slate-950 border-b border-slate-800 no-print">
          <div className="flex items-center gap-2">
            <span className="text-amber-400 font-royal font-black text-lg">🔱</span>
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                Invoice {invoice.invoiceNumber}
              </h3>
              <p className="text-[11px] text-slate-400">
                {formatDate(invoice.date)} · {invoice.customerName || 'Walk-in'}
              </p>
            </div>
          </div>

          {/* Format Selector: A4 / 80mm / 58mm */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs">
            <button
              onClick={() => setPrintFormat('a4')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                printFormat === 'a4'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              A4 Tax Invoice
            </button>
            <button
              onClick={() => setPrintFormat('thermal80')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                printFormat === 'thermal80'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              80mm Thermal
            </button>
            <button
              onClick={() => setPrintFormat('thermal58')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                printFormat === 'thermal58'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              58mm Mini
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <a
              href={buildWhatsAppBillUrl(invoice.customerPhone, whatsappMessage)}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow-sm"
              title="Send to Customer WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>

            <button
              onClick={handleCopyText}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs transition"
              title="Copy Bill Text"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition shadow-lg shadow-amber-500/20"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Bill</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Bill Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-950/60 flex justify-center">
          {/* A4 FORMAT */}
          {printFormat === 'a4' && (
            <div className="printable-bill-wrapper w-full max-w-3xl bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-xl font-sans text-xs border border-slate-200">
              {/* Header */}
              <div className="border-b-2 border-slate-800 pb-4 mb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-xl bg-amber-500 border border-amber-600 flex items-center justify-center text-slate-950 font-black text-2xl font-royal shadow-sm">
                      🔱
                    </div>
                    <div>
                      <h1 className="text-xl sm:text-2xl font-black tracking-wide text-slate-950 font-royal">
                        {settings.shopName || "MAA DURGA ENTERPRISES"}
                      </h1>
                      <p className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">
                        {settings.shopTagline || "MOBILE SHOWROOM, ACCESSORIES & REPAIR CENTER"}
                      </p>
                      <p className="text-[10px] text-slate-600 mt-0.5">
                        {settings.address}, {settings.city}, {settings.state} - {settings.pincode}
                      </p>
                      <p className="text-[10px] text-slate-600 font-semibold">
                        Phone: {settings.phone} {settings.altPhone ? `· ${settings.altPhone}` : ''} | Email: {settings.email}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="inline-block px-2.5 py-1 bg-slate-900 text-white font-black text-[10px] uppercase rounded tracking-wider mb-1">
                      {invoice.gstType === 'gst' ? 'TAX INVOICE' : 'RETAIL INVOICE'}
                    </span>
                    {settings.gstin && (
                      <div className="text-[11px] font-mono-code font-bold text-slate-800">
                        GSTIN: {settings.gstin}
                      </div>
                    )}
                    <div className="text-[11px] font-mono-code font-extrabold text-amber-900 mt-1">
                      Invoice No: {invoice.invoiceNumber}
                    </div>
                    <div className="text-[10px] text-slate-600 font-medium">
                      Date: {formatDate(invoice.date)} · Time: {invoice.time}
                    </div>
                  </div>
                </div>
              </div>

              {/* Customer Info Box */}
              <div className="grid grid-cols-2 gap-4 p-3 rounded-lg bg-slate-50 border border-slate-200 mb-4">
                <div>
                  <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
                    Billed To (Customer Details):
                  </span>
                  <div className="font-bold text-slate-900 text-sm mt-0.5">
                    {invoice.customerName || 'Walk-in Customer'}
                  </div>
                  <div className="text-slate-700 font-mono-code text-xs mt-0.5">
                    Mobile: {invoice.customerPhone || 'N/A'}
                  </div>
                  {invoice.customerAddress && (
                    <div className="text-slate-600 text-[11px] mt-0.5">
                      Address: {invoice.customerAddress}
                    </div>
                  )}
                </div>

                <div className="text-right flex flex-col justify-center items-end">
                  <div className="text-[11px]">
                    <span className="text-slate-500">Payment Mode: </span>
                    <span className="font-bold text-slate-900 uppercase">{invoice.paymentMode}</span>
                  </div>
                  <div className="text-[11px] mt-1">
                    <span className="text-slate-500">Bill Type: </span>
                    <span className="font-semibold text-slate-900">
                      {invoice.gstType === 'gst' ? 'GST Regular (18% HSN 8517)' : 'Non-GST Retail'}
                    </span>
                  </div>
                  {invoice.isCancelled && (
                    <span className="mt-1 px-2 py-0.5 bg-red-100 text-red-700 font-bold text-[10px] rounded border border-red-300">
                      CANCELLED BILL
                    </span>
                  )}
                </div>
              </div>

              {/* Items Table */}
              <table className="w-full text-left border-collapse border border-slate-300 mb-4">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-300 text-[10px] font-bold uppercase text-slate-700">
                    <th className="p-2 border-r border-slate-300 text-center w-8">#</th>
                    <th className="p-2 border-r border-slate-300">Item Description</th>
                    <th className="p-2 border-r border-slate-300">IMEI 1 / Serial No</th>
                    <th className="p-2 border-r border-slate-300 text-center w-12">Qty</th>
                    <th className="p-2 border-r border-slate-300 text-right w-20">Rate</th>
                    <th className="p-2 border-r border-slate-300 text-right w-16">Disc</th>
                    <th className="p-2 text-right w-24">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {invoice.items.map((item, idx) => (
                    <tr key={idx} className="border-b border-slate-200">
                      <td className="p-2 border-r border-slate-300 text-center font-mono-code">{idx + 1}</td>
                      <td className="p-2 border-r border-slate-300">
                        <div className="font-bold text-slate-900">
                          {item.brand} {item.productName}
                        </div>
                        <div className="text-[10px] text-slate-600">
                          {item.ramStorage ? `${item.ramStorage} ` : ''}
                          {item.color ? `· Color: ${item.color} ` : ''}
                          · HSN: 8517
                        </div>
                      </td>
                      <td className="p-2 border-r border-slate-300 font-mono-code text-[11px]">
                        {item.imei1 && (
                          <div className="text-slate-900 font-semibold">IMEI 1: {item.imei1}</div>
                        )}
                        {item.imei2 && (
                          <div className="text-slate-600 text-[10px]">IMEI 2: {item.imei2}</div>
                        )}
                        {item.serialNumber && !item.imei1 && (
                          <div className="text-slate-700">S/N: {item.serialNumber}</div>
                        )}
                        {!item.imei1 && !item.serialNumber && (
                          <span className="text-slate-400 italic">Accessories</span>
                        )}
                      </td>
                      <td className="p-2 border-r border-slate-300 text-center font-mono-code font-bold">
                        {item.quantity}
                      </td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono-code">
                        {formatCurrency(item.rate)}
                      </td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono-code text-slate-600">
                        {item.discount > 0 ? formatCurrency(item.discount) : '-'}
                      </td>
                      <td className="p-2 text-right font-mono-code font-bold text-slate-900">
                        {formatCurrency(item.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Lower Section: Words, Summary & UPI QR */}
              <div className="grid grid-cols-12 gap-4 border border-slate-300 p-4 rounded-lg bg-slate-50 mb-4">
                {/* Left col: Amount in words & UPI QR */}
                <div className="col-span-7 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">
                      Amount Chargeable (in words):
                    </span>
                    <p className="font-bold text-slate-900 italic mt-0.5 text-[11px]">
                      {numberToWordsIndian(invoice.grandTotal)}
                    </p>
                  </div>

                  <div className="flex items-center gap-4 mt-4 pt-3 border-t border-slate-200">
                    {settings.upiId && (
                      <UpiQrCode
                        upiId={settings.upiId}
                        payeeName={settings.shopName}
                        amount={invoice.grandTotal}
                        invoiceNo={invoice.invoiceNumber}
                        size={84}
                      />
                    )}
                    <div className="text-[10px] text-slate-600 space-y-0.5">
                      <div className="font-bold text-slate-800">Direct Showroom UPI Payment</div>
                      <div>UPI VPA: <span className="font-mono-code font-semibold">{settings.upiId}</span></div>
                      <div>Bank Name: State Bank of India</div>
                      <div className="text-[9px] text-slate-500">Scan via PhonePe, Google Pay, Paytm, BHIM</div>
                    </div>
                  </div>
                </div>

                {/* Right col: Financial calculations */}
                <div className="col-span-5 space-y-1.5 border-l border-slate-300 pl-4 font-mono-code">
                  <div className="flex justify-between text-slate-600">
                    <span>Taxable Subtotal:</span>
                    <span>{formatCurrency(invoice.subtotal)}</span>
                  </div>

                  {invoice.gstType === 'gst' && (
                    <>
                      <div className="flex justify-between text-slate-600">
                        <span>CGST (9%):</span>
                        <span>{formatCurrency(invoice.cgst)}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>SGST (9%):</span>
                        <span>{formatCurrency(invoice.sgst)}</span>
                      </div>
                    </>
                  )}

                  {invoice.totalDiscount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-semibold">
                      <span>Total Discount:</span>
                      <span>- {formatCurrency(invoice.totalDiscount)}</span>
                    </div>
                  )}

                  {invoice.roundOff !== 0 && (
                    <div className="flex justify-between text-slate-500 text-[10px]">
                      <span>Round Off:</span>
                      <span>{invoice.roundOff > 0 ? `+${invoice.roundOff}` : invoice.roundOff}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-base font-black text-slate-950 pt-2 border-t-2 border-slate-800">
                    <span>Grand Total:</span>
                    <span>{formatCurrency(invoice.grandTotal)}</span>
                  </div>

                  <div className="flex justify-between text-emerald-800 font-bold pt-1">
                    <span>Amount Paid:</span>
                    <span>{formatCurrency(invoice.paidAmount)}</span>
                  </div>

                  {invoice.dueAmount > 0 && (
                    <div className="flex justify-between text-red-600 font-extrabold pt-1 border-t border-red-200">
                      <span>Remaining Udhaar Due:</span>
                      <span>{formatCurrency(invoice.dueAmount)}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Terms and Signatures */}
              <div className="grid grid-cols-2 gap-6 pt-3 border-t border-slate-300 text-[10px]">
                <div>
                  <span className="font-bold text-slate-800 uppercase tracking-wider block mb-1">
                    Warranty Terms & Conditions:
                  </span>
                  <div className="whitespace-pre-line text-slate-600 leading-relaxed text-[9px]">
                    {settings.invoiceTerms}
                  </div>
                </div>

                <div className="flex flex-col justify-between items-end">
                  <div className="text-right">
                    <span className="font-bold text-slate-800 text-[11px]">
                      For {settings.shopName || "MAA DURGA ENTERPRISES"}
                    </span>
                  </div>
                  <div className="text-right mt-12">
                    <div className="border-t border-slate-400 w-48 text-center pt-1 font-semibold text-slate-700">
                      Authorized Signatory / Seal
                    </div>
                  </div>
                </div>
              </div>

              {/* Thank you footer */}
              <div className="text-center font-bold text-slate-700 mt-6 pt-3 border-t border-dashed border-slate-300 text-[11px] tracking-wider uppercase font-royal">
                🔱 Thank You for Shopping With Us! Please Visit Again! 🔱
              </div>
            </div>
          )}

          {/* 80mm THERMAL RECEIPT */}
          {printFormat === 'thermal80' && (
            <div className="printable-bill-wrapper w-[300px] bg-white text-slate-900 p-4 rounded-xl shadow-xl font-mono-code text-[11px] border border-slate-300">
              <div className="text-center pb-2 border-b border-dashed border-slate-400">
                <div className="text-lg font-black text-slate-950 font-royal">
                  {settings.shopName || "MAA DURGA ENTERPRISES"}
                </div>
                <div className="text-[10px] text-slate-600">{settings.shopTagline}</div>
                <div className="text-[10px] text-slate-600">{settings.address}, {settings.city}</div>
                <div className="text-[10px] font-bold">Ph: {settings.phone}</div>
                {settings.gstin && <div className="text-[10px]">GSTIN: {settings.gstin}</div>}
              </div>

              <div className="py-2 border-b border-dashed border-slate-400 text-[10px]">
                <div>Inv: <span className="font-bold">{invoice.invoiceNumber}</span></div>
                <div>Date: {formatDate(invoice.date)} {invoice.time}</div>
                <div>Cust: <span className="font-bold">{invoice.customerName}</span> ({invoice.customerPhone})</div>
                <div>Mode: <span className="font-bold uppercase">{invoice.paymentMode}</span></div>
              </div>

              <div className="py-2 border-b border-dashed border-slate-400">
                {invoice.items.map((item, idx) => (
                  <div key={idx} className="mb-2">
                    <div className="font-bold text-slate-950">
                      {item.brand} {item.productName}
                    </div>
                    {item.imei1 && (
                      <div className="text-[10px] text-slate-700">IMEI: {item.imei1}</div>
                    )}
                    <div className="flex justify-between text-[10px]">
                      <span>{item.quantity} x {formatCurrency(item.rate)}</span>
                      <span className="font-bold">{formatCurrency(item.amount)}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="py-2 border-b border-dashed border-slate-400 space-y-1 text-right">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(invoice.subtotal)}</span>
                </div>
                {invoice.gstType === 'gst' && (
                  <div className="flex justify-between">
                    <span>Tax (GST 18%):</span>
                    <span>{formatCurrency(invoice.cgst + invoice.sgst)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-black pt-1 border-t border-slate-400">
                  <span>Total:</span>
                  <span>{formatCurrency(invoice.grandTotal)}</span>
                </div>
                <div className="flex justify-between font-bold text-emerald-800">
                  <span>Paid:</span>
                  <span>{formatCurrency(invoice.paidAmount)}</span>
                </div>
                {invoice.dueAmount > 0 && (
                  <div className="flex justify-between font-bold text-red-600">
                    <span>Balance Due:</span>
                    <span>{formatCurrency(invoice.dueAmount)}</span>
                  </div>
                )}
              </div>

              {settings.upiId && (
                <div className="py-3 flex flex-col items-center justify-center border-b border-dashed border-slate-400">
                  <UpiQrCode
                    upiId={settings.upiId}
                    payeeName={settings.shopName}
                    amount={invoice.grandTotal}
                    invoiceNo={invoice.invoiceNumber}
                    size={72}
                  />
                </div>
              )}

              <div className="text-center pt-2 text-[9px] text-slate-600">
                <p>Warranty by Authorized Service Center</p>
                <p className="font-bold text-slate-900 mt-1">Thank You! Please Visit Again!</p>
              </div>
            </div>
          )}

          {/* 58mm MINI THERMAL RECEIPT */}
          {printFormat === 'thermal58' && (
            <div className="printable-bill-wrapper w-[220px] bg-white text-slate-900 p-2.5 rounded-xl shadow-xl font-mono-code text-[10px] border border-slate-300">
              <div className="text-center pb-1 border-b border-dashed border-slate-400">
                <div className="text-sm font-black text-slate-950 font-royal leading-tight">
                  {settings.shopName}
                </div>
                <div className="text-[9px] text-slate-600">Mob: {settings.phone}</div>
              </div>

              <div className="py-1 border-b border-dashed border-slate-400 text-[9px]">
                <div>No: {invoice.invoiceNumber}</div>
                <div>{invoice.date} {invoice.time}</div>
                <div>To: {invoice.customerName}</div>
              </div>

              <div className="py-1 border-b border-dashed border-slate-400">
                {invoice.items.map((item, idx) => (
                  <div key={idx} className="mb-1">
                    <div className="font-bold">{item.productName}</div>
                    {item.imei1 && <div className="text-[8px]">IM:{item.imei1.slice(-8)}</div>}
                    <div className="flex justify-between">
                      <span>{item.quantity}x{item.rate}</span>
                      <span className="font-bold">{item.amount}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="py-1 border-b border-dashed border-slate-400 font-bold space-y-0.5">
                <div className="flex justify-between text-xs">
                  <span>TOTAL:</span>
                  <span>{formatCurrency(invoice.grandTotal)}</span>
                </div>
                <div className="flex justify-between text-[9px]">
                  <span>PAID:</span>
                  <span>{formatCurrency(invoice.paidAmount)}</span>
                </div>
                {invoice.dueAmount > 0 && (
                  <div className="flex justify-between text-red-600 text-[9px]">
                    <span>DUE:</span>
                    <span>{formatCurrency(invoice.dueAmount)}</span>
                  </div>
                )}
              </div>

              <div className="text-center pt-1 text-[8px] text-slate-600">
                Thank You! Visit Again!
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
