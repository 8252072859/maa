import React, { useState, useEffect, useRef } from 'react';
import {
  Receipt,
  Search,
  ScanLine,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Printer,
  User,
  Phone,
  MapPin,
  Smartphone,
  CreditCard,
  Percent,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { Product, BillItem, Invoice, PaymentMode, Customer } from '../../types/erp';
import { formatCurrency, getTodayDateString, getCurrentTimeString } from '../../utils/formatters';
import { sounds } from '../../utils/soundEffects';
import { ImeiScannerModal } from '../common/ImeiScannerModal';
import { BillPrintModal } from './BillPrintModal';

export const NewBill: React.FC = () => {
  const {
    products,
    customers,
    settings,
    createInvoice,
    isImeiAvailable,
    setActiveTab
  } = useERP();
  const { t } = useLanguage();

  // Invoice Meta
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [billDate, setBillDate] = useState(getTodayDateString());
  const [billTime, setBillTime] = useState(getCurrentTimeString());

  // Customer State
  const [customerSearch, setCustomerSearch] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [showCustomerDropdown, setShowCustomerDropdown] = useState(false);

  // Line items in current bill
  const [items, setItems] = useState<BillItem[]>([]);

  // Item form for currently adding product
  const [productSearch, setProductSearch] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedImei1, setSelectedImei1] = useState('');
  const [selectedImei2, setSelectedImei2] = useState('');
  const [selectedSerial, setSelectedSerial] = useState('');
  const [itemRate, setItemRate] = useState<number>(0);
  const [itemDiscount, setItemDiscount] = useState<number>(0);
  const [itemQty, setItemQty] = useState<number>(1);
  const [showProductDropdown, setShowProductDropdown] = useState(false);

  // Financial calculations
  const [gstType, setGstType] = useState<'gst' | 'non_gst'>('gst');
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('cash');
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [billNotes, setBillNotes] = useState('');

  // UI Modals & Feedback
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannerTarget, setScannerTarget] = useState<'formImei1' | 'formImei2' | 'search'>('formImei1');
  const [createdInvoice, setCreatedInvoice] = useState<Invoice | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Set initial invoice number
  useEffect(() => {
    const seq = String(settings.nextInvoiceSeq || 1).padStart(4, '0');
    setInvoiceNumber(`${settings.invoicePrefix || 'MDE-2026-'}${seq}`);
  }, [settings.nextInvoiceSeq, settings.invoicePrefix]);

  // Customer filtering
  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.phone.includes(customerSearch)
  );

  const handleSelectCustomer = (cust: Customer) => {
    setSelectedCustomerId(cust.id);
    setCustomerName(cust.name);
    setCustomerPhone(cust.phone);
    setCustomerAddress(cust.address || '');
    setCustomerSearch(cust.name);
    setShowCustomerDropdown(false);
  };

  // Product filtering
  const filteredProducts = products.filter(
    (p) =>
      p.currentStock > 0 &&
      (p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
        p.brand.toLowerCase().includes(productSearch.toLowerCase()) ||
        p.model.toLowerCase().includes(productSearch.toLowerCase()) ||
        (p.imeiList && p.imeiList.some((im) => im.includes(productSearch))))
  );

  const handleSelectProduct = (prod: Product) => {
    setSelectedProduct(prod);
    setItemRate(prod.sellingPrice);
    setItemDiscount(0);
    setItemQty(1);
    // pre-fill first available IMEI if handset
    if (prod.imeiList && prod.imeiList.length > 0) {
      setSelectedImei1(prod.imeiList[0]);
    } else {
      setSelectedImei1('');
    }
    setSelectedImei2('');
    setSelectedSerial(prod.serialNumber || '');
    setProductSearch(`${prod.brand} ${prod.name}`);
    setShowProductDropdown(false);
  };

  // Add Item to Bill
  const handleAddItem = () => {
    if (!selectedProduct) {
      setErrorMessage('Please select a product first.');
      return;
    }

    if (itemRate <= 0) {
      setErrorMessage('Rate must be greater than 0.');
      return;
    }

    // Handset IMEI check
    const isMobile = ['smartphone', 'feature_phone', 'used_phone', 'exchanged_phone'].includes(
      selectedProduct.category
    );
    if (isMobile) {
      if (!selectedImei1.trim()) {
        setErrorMessage('IMEI 1 is required for mobile handsets.');
        return;
      }

      // Check if IMEI 1 is available
      const check1 = isImeiAvailable(selectedImei1);
      if (!check1.available) {
        setErrorMessage(check1.reason || 'This IMEI has already been sold!');
        return;
      }

      // Check if already in current bill items
      if (items.some((i) => i.imei1 === selectedImei1 || i.imei2 === selectedImei1)) {
        setErrorMessage('This IMEI is already added in this bill!');
        return;
      }

      if (selectedImei2.trim()) {
        const check2 = isImeiAvailable(selectedImei2);
        if (!check2.available) {
          setErrorMessage(check2.reason || 'IMEI 2 has already been sold!');
          return;
        }
      }
    }

    const calculatedAmount = Math.max(0, itemRate * itemQty - itemDiscount);

    const newItem: BillItem = {
      productId: selectedProduct.id,
      productName: selectedProduct.name,
      brand: selectedProduct.brand,
      model: selectedProduct.model,
      ramStorage:
        selectedProduct.ram || selectedProduct.storage
          ? `${selectedProduct.ram || ''} ${selectedProduct.storage || ''}`.trim()
          : undefined,
      color: selectedProduct.color,
      imei1: selectedImei1.trim() || undefined,
      imei2: selectedImei2.trim() || undefined,
      serialNumber: selectedSerial.trim() || undefined,
      quantity: itemQty,
      rate: itemRate,
      discount: itemDiscount,
      amount: calculatedAmount,
      purchasePrice: selectedProduct.purchasePrice,
      gstRate: gstType === 'gst' ? 18 : 0,
      category: selectedProduct.category
    };

    setItems([...items, newItem]);
    sounds.playScanBeep();

    // Reset item form
    setSelectedProduct(null);
    setProductSearch('');
    setSelectedImei1('');
    setSelectedImei2('');
    setSelectedSerial('');
    setItemRate(0);
    setItemDiscount(0);
    setItemQty(1);
    setErrorMessage(null);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  // Grand Totals Calculation
  const subtotalBeforeDiscount = items.reduce((sum, item) => sum + item.rate * item.quantity, 0);
  const totalItemDiscounts = items.reduce((sum, item) => sum + item.discount, 0);
  const netTaxable = Math.max(0, subtotalBeforeDiscount - totalItemDiscounts);

  // If GST is enabled (18% inclusive in selling price or added)
  // Standard Indian retail: prices are GST inclusive, we show taxable + CGST 9% + SGST 9%
  const gstInclusiveTax = gstType === 'gst' ? (netTaxable * 18) / 118 : 0;
  const taxableSubtotal = gstType === 'gst' ? netTaxable - gstInclusiveTax : netTaxable;
  const cgst = gstType === 'gst' ? gstInclusiveTax / 2 : 0;
  const sgst = gstType === 'gst' ? gstInclusiveTax / 2 : 0;

  const rawGrandTotal = netTaxable;
  const roundOff = Math.round(rawGrandTotal) - rawGrandTotal;
  const grandTotal = Math.round(rawGrandTotal);

  // Default paid amount matches grandTotal if not Udhar
  useEffect(() => {
    if (paymentMode === 'udhar') {
      // For Udhar, default paid amount can be 0 or partial
    } else {
      setPaidAmount(grandTotal);
    }
  }, [grandTotal, paymentMode]);

  const dueAmount = Math.max(0, grandTotal - paidAmount);

  // Scanner handler
  const handleScannedCode = (code: string) => {
    if (scannerTarget === 'search') {
      // Look up product by IMEI or Barcode
      const found = products.find(
        (p) => p.imeiList && p.imeiList.includes(code)
      );
      if (found) {
        handleSelectProduct(found);
      } else {
        setProductSearch(code);
      }
    } else if (scannerTarget === 'formImei1') {
      setSelectedImei1(code);
    } else if (scannerTarget === 'formImei2') {
      setSelectedImei2(code);
    }
  };

  // Save Bill
  const handleSaveBill = async () => {
    if (items.length === 0) {
      setErrorMessage('Please add at least one product to create the bill.');
      return;
    }

    if (!customerName.trim() && dueAmount > 0) {
      setErrorMessage('Customer Name is required when there is an Udhaar balance.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const invoiceData: Omit<Invoice, 'id' | 'createdAt'> = {
        invoiceNumber,
        date: billDate,
        time: billTime,
        customerId: selectedCustomerId || `cust-${Date.now()}`,
        customerName: customerName.trim() || 'Cash Customer',
        customerPhone: customerPhone.trim() || '',
        customerAddress: customerAddress.trim() || '',
        items,
        subtotal: Math.round(taxableSubtotal * 100) / 100,
        gstType,
        gstRate: gstType === 'gst' ? 18 : 0,
        cgst: Math.round(cgst * 100) / 100,
        sgst: Math.round(sgst * 100) / 100,
        igst: 0,
        totalDiscount: totalItemDiscounts,
        roundOff: Math.round(roundOff * 100) / 100,
        grandTotal,
        paymentMode,
        paidAmount,
        dueAmount,
        notes: billNotes,
        createdBy: settings.userRole || 'Admin'
      };

      const saved = await createInvoice(invoiceData);

      // Celebration Confetti
      try {
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch {}

      setCreatedInvoice(saved);

      // Reset form
      setItems([]);
      setCustomerName('');
      setCustomerPhone('');
      setCustomerAddress('');
      setCustomerSearch('');
      setSelectedCustomerId('');
      setBillNotes('');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save bill. Please check inputs.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              ADVANCED BILL BOOK & POS
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Dual IMEI verification, instant tax calculation, and automatic stock deduction.
          </p>
        </div>

        {/* Invoice Number & Date Meta */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono-code">
            <span className="text-slate-500 mr-2">Invoice:</span>
            <span className="text-amber-300 font-bold">{invoiceNumber}</span>
          </div>

          <div className="px-3.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono-code text-slate-300">
            {billDate} · {billTime}
          </div>
        </div>
      </div>

      {errorMessage && (
        <div className="p-4 rounded-2xl bg-red-950/60 border border-red-500/50 text-red-200 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="p-1 hover:text-white text-red-300"
          >
            ✕
          </button>
        </div>
      )}

      {/* Grid: Left Column (Customer & Item Entry) + Right Column (Bill Summary & Save) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: Customer + Items (8 Cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* 1. CUSTOMER DETAILS CARD */}
          <div className="p-5 rounded-2xl bg-[#0d1322] border border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  {t('customerDetails')}
                </h3>
              </div>
              <span className="text-[11px] text-slate-500">
                (Type mobile to search existing Khata)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Customer Name with Autocomplete */}
              <div className="relative">
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  {t('customerName')} *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Ramesh Sharma"
                  value={customerName}
                  onChange={(e) => {
                    setCustomerName(e.target.value);
                    setCustomerSearch(e.target.value);
                    setShowCustomerDropdown(true);
                  }}
                  onFocus={() => setShowCustomerDropdown(true)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
                />

                {/* Dropdown for matching customers */}
                {showCustomerDropdown && customerSearch.trim().length > 0 && filteredCustomers.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-1 z-20 max-h-48 overflow-y-auto bg-slate-900 border border-slate-700 rounded-xl shadow-2xl divide-y divide-slate-800">
                    {filteredCustomers.map((c) => (
                      <div
                        key={c.id}
                        onClick={() => handleSelectCustomer(c)}
                        className="p-2.5 hover:bg-slate-800 cursor-pointer text-xs"
                      >
                        <div className="font-semibold text-slate-200">{c.name}</div>
                        <div className="text-[10px] text-slate-400 flex items-center justify-between">
                          <span>Ph: {c.phone}</span>
                          {c.currentUdhaar > 0 && (
                            <span className="text-red-400 font-bold">
                              Udhaar: {formatCurrency(c.currentUdhaar)}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Mobile Number */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  {t('mobileNumber')} (10 digits)
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    maxLength={10}
                    placeholder="9876543210"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs font-mono-code focus:outline-none focus:border-amber-400"
                  />
                  <Phone className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-2.5" />
                </div>
              </div>

              {/* Address */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  {t('address')}
                </label>
                <input
                  type="text"
                  placeholder="e.g. Boring Road, Patna"
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          </div>

          {/* 2. PRODUCT SELECTION & IMEI CARD */}
          <div className="p-5 rounded-2xl bg-[#0d1322] border border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-blue-400" />
                <h3 className="text-sm font-bold text-slate-200">
                  Select Product & Mobile IMEI
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setScannerTarget('search');
                  setIsScannerOpen(true);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold border border-slate-700 transition"
              >
                <ScanLine className="w-3.5 h-3.5" />
                <span>Barcode Scanner</span>
              </button>
            </div>

            {/* Product Live Search Bar */}
            <div className="relative">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Search product by Brand, Model or IMEI..."
                    value={productSearch}
                    onChange={(e) => {
                      setProductSearch(e.target.value);
                      setShowProductDropdown(true);
                    }}
                    onFocus={() => setShowProductDropdown(true)}
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
                  />
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                </div>
              </div>

              {/* Live matching products dropdown */}
              {showProductDropdown && productSearch.trim().length > 0 && filteredProducts.length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-1 z-20 max-h-56 overflow-y-auto bg-slate-900 border border-slate-700 rounded-xl shadow-2xl divide-y divide-slate-800">
                  {filteredProducts.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => handleSelectProduct(p)}
                      className="p-3 hover:bg-slate-800 cursor-pointer text-xs flex items-center justify-between"
                    >
                      <div>
                        <span className="font-bold text-slate-100">
                          {p.brand} {p.name}
                        </span>
                        <div className="text-[11px] text-slate-400">
                          {p.model} {p.ram ? `· ${p.ram}/${p.storage}` : ''} {p.color ? `· ${p.color}` : ''}
                        </div>
                        {p.imeiList && p.imeiList.length > 0 && (
                          <div className="text-[10px] text-amber-400 font-mono-code mt-0.5">
                            Available IMEIs: {p.imeiList.length} in stock
                          </div>
                        )}
                      </div>

                      <div className="text-right">
                        <div className="font-mono-code font-bold text-amber-300">
                          {formatCurrency(p.sellingPrice)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          Stock: {p.currentStock}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Selected Product Config Form */}
            {selectedProduct && (
              <div className="p-4 rounded-xl bg-slate-950/70 border border-amber-500/20 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="font-bold text-slate-100 text-xs">
                    {selectedProduct.brand} {selectedProduct.name}
                    <span className="ml-2 font-normal text-slate-400">
                      ({selectedProduct.model})
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Stock Available: {selectedProduct.currentStock}
                  </span>
                </div>

                {/* Handset IMEI 1 & IMEI 2 Fields */}
                {['smartphone', 'feature_phone', 'used_phone', 'exchanged_phone'].includes(selectedProduct.category) && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* IMEI 1 */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-semibold text-slate-400">
                          Primary IMEI 1 *
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            setScannerTarget('formImei1');
                            setIsScannerOpen(true);
                          }}
                          className="text-[10px] text-amber-400 hover:text-amber-300 flex items-center gap-1"
                        >
                          <ScanLine className="w-3 h-3" /> Scan IMEI 1
                        </button>
                      </div>

                      {/* Dropdown of available IMEIs in stock or custom input */}
                      {selectedProduct.imeiList && selectedProduct.imeiList.length > 0 ? (
                        <select
                          value={selectedImei1}
                          onChange={(e) => setSelectedImei1(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                        >
                          <option value="">Select IMEI from stock...</option>
                          {selectedProduct.imeiList.map((im) => (
                            <option key={im} value={im}>
                              {im}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          placeholder="Enter 15-digit IMEI 1"
                          value={selectedImei1}
                          onChange={(e) => setSelectedImei1(e.target.value.replace(/[^0-9]/g, ''))}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                        />
                      )}
                    </div>

                    {/* IMEI 2 (Secondary SIM) */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-semibold text-slate-400">
                          Secondary IMEI 2 (Optional)
                        </label>
                        <button
                          type="button"
                          onClick={() => {
                            setScannerTarget('formImei2');
                            setIsScannerOpen(true);
                          }}
                          className="text-[10px] text-amber-400 hover:text-amber-300 flex items-center gap-1"
                        >
                          <ScanLine className="w-3 h-3" /> Scan IMEI 2
                        </button>
                      </div>
                      <input
                        type="text"
                        placeholder="e.g. 864920048123902"
                        value={selectedImei2}
                        onChange={(e) => setSelectedImei2(e.target.value.replace(/[^0-9]/g, ''))}
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>
                )}

                {/* Rate, Discount, Qty and Add Button */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                      Rate (Selling Price)
                    </label>
                    <input
                      type="number"
                      value={itemRate}
                      onChange={(e) => setItemRate(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                      Discount (₹)
                    </label>
                    <input
                      type="number"
                      value={itemDiscount}
                      onChange={(e) => setItemDiscount(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                      Quantity
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={selectedProduct.currentStock}
                      value={itemQty}
                      onChange={(e) => setItemQty(Math.max(1, Number(e.target.value)))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-mono-code text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="flex items-end">
                    <button
                      type="button"
                      onClick={handleAddItem}
                      className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-md shadow-amber-500/20"
                    >
                      <Plus className="w-4 h-4 stroke-[2.5]" />
                      <span>Add to Bill</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 3. CURRENT BILL ITEMS TABLE */}
          <div className="p-5 rounded-2xl bg-[#0d1322] border border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-200">
                Bill Items ({items.length})
              </h3>
              {items.length > 0 && (
                <button
                  type="button"
                  onClick={() => setItems([])}
                  className="text-xs text-red-400 hover:text-red-300 font-medium"
                >
                  Clear All
                </button>
              )}
            </div>

            {items.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">
                No items added to bill yet. Select a product above to add.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                      <th className="pb-2">#</th>
                      <th className="pb-2">Product Description</th>
                      <th className="pb-2">IMEI / S/N</th>
                      <th className="pb-2 text-center">Qty</th>
                      <th className="pb-2 text-right">Rate</th>
                      <th className="pb-2 text-right">Disc</th>
                      <th className="pb-2 text-right">Amount</th>
                      <th className="pb-2 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono-code">
                    {items.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/30">
                        <td className="py-2.5 text-slate-400 font-sans">{idx + 1}</td>
                        <td className="py-2.5 font-sans font-semibold text-slate-200">
                          {item.brand} {item.productName}
                          {item.ramStorage && (
                            <span className="text-[10px] text-slate-400 font-normal block">
                              {item.ramStorage} {item.color ? `· ${item.color}` : ''}
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 text-[11px] text-amber-300">
                          {item.imei1 || item.serialNumber || 'N/A'}
                          {item.imei2 && (
                            <div className="text-[10px] text-slate-400">
                              2: {item.imei2}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 text-center text-slate-200">{item.quantity}</td>
                        <td className="py-2.5 text-right text-slate-300">
                          {formatCurrency(item.rate)}
                        </td>
                        <td className="py-2.5 text-right text-emerald-400">
                          {item.discount > 0 ? formatCurrency(item.discount) : '-'}
                        </td>
                        <td className="py-2.5 text-right font-bold text-slate-100">
                          {formatCurrency(item.amount)}
                        </td>
                        <td className="py-2.5 text-center font-sans">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(idx)}
                            className="p-1 text-slate-500 hover:text-red-400 transition"
                            title="Remove Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: TAX, PAYMENT MODE & SAVE BUTTON (4 Cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="p-5 rounded-2xl bg-[#0d1322] border border-amber-500/25 shadow-xl space-y-5">
            <h3 className="text-sm font-bold text-amber-300 uppercase tracking-wider font-royal">
              PAYMENT & BILL SUMMARY
            </h3>

            {/* GST Option Toggle */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-semibold text-slate-400">
                Invoice Tax Mode
              </label>
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setGstType('gst')}
                  className={`py-1.5 px-3 rounded-lg text-xs font-semibold transition ${
                    gstType === 'gst'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  GST (18% HSN 8517)
                </button>
                <button
                  type="button"
                  onClick={() => setGstType('non_gst')}
                  className={`py-1.5 px-3 rounded-lg text-xs font-semibold transition ${
                    gstType === 'non_gst'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Non-GST Retail
                </button>
              </div>
            </div>

            {/* Financial Summary */}
            <div className="space-y-2 p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono-code text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Subtotal:</span>
                <span>{formatCurrency(subtotalBeforeDiscount)}</span>
              </div>

              {totalItemDiscounts > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Total Discount:</span>
                  <span>- {formatCurrency(totalItemDiscounts)}</span>
                </div>
              )}

              {gstType === 'gst' && (
                <>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Taxable Value:</span>
                    <span>{formatCurrency(taxableSubtotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>CGST (9%):</span>
                    <span>{formatCurrency(cgst)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>SGST (9%):</span>
                    <span>{formatCurrency(sgst)}</span>
                  </div>
                </>
              )}

              {roundOff !== 0 && (
                <div className="flex justify-between text-slate-500 text-[10px]">
                  <span>Round Off:</span>
                  <span>{roundOff > 0 ? `+${roundOff}` : roundOff}</span>
                </div>
              )}

              <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline text-slate-100">
                <span className="font-sans font-bold text-sm">Grand Total:</span>
                <span className="text-xl font-black text-amber-300">
                  {formatCurrency(grandTotal)}
                </span>
              </div>
            </div>

            {/* Payment Mode Selection */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-semibold text-slate-400">
                {t('paymentMode')}
              </label>
              <div className="grid grid-cols-3 gap-1.5 text-xs font-semibold">
                {[
                  { id: 'cash', label: 'Cash' },
                  { id: 'upi', label: 'UPI' },
                  { id: 'card', label: 'Card' },
                  { id: 'bank', label: 'Bank' },
                  { id: 'udhar', label: 'Udhar' },
                  { id: 'split', label: 'Split' }
                ].map((mode) => (
                  <button
                    key={mode.id}
                    type="button"
                    onClick={() => setPaymentMode(mode.id as PaymentMode)}
                    className={`py-2 rounded-xl border text-center transition ${
                      paymentMode === mode.id
                        ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-bold'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Paid Amount & Due Balance */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  {t('paidAmount')}
                </label>
                <input
                  type="number"
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code font-bold text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  {t('remainingDue')}
                </label>
                <div className={`px-3 py-2 rounded-xl bg-slate-950 border font-mono-code font-bold text-sm flex items-center ${
                  dueAmount > 0 ? 'border-red-500/50 text-red-400' : 'border-slate-800 text-emerald-400'
                }`}>
                  {formatCurrency(dueAmount)}
                </div>
              </div>
            </div>

            {dueAmount > 0 && (
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300">
                ⚠️ Balance of <span className="font-bold">{formatCurrency(dueAmount)}</span> will be automatically added to {customerName || 'Customer'}'s Udhaar Khata.
              </div>
            )}

            {/* Bill Note */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                Remarks / Notes
              </label>
              <input
                type="text"
                placeholder="Optional invoice notes..."
                value={billNotes}
                onChange={(e) => setBillNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* BIG SAVE & PRINT BILL BUTTON */}
            <button
              type="button"
              disabled={isSubmitting || items.length === 0}
              onClick={handleSaveBill}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:brightness-110 text-slate-950 font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl shadow-amber-500/25 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed transition"
            >
              <Printer className="w-5 h-5 stroke-[2.5]" />
              <span>{isSubmitting ? 'Saving Invoice...' : t('saveAndPrint')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bill Print Modal when invoice created */}
      {createdInvoice && (
        <BillPrintModal
          invoice={createdInvoice}
          onClose={() => setCreatedInvoice(null)}
        />
      )}

      {/* IMEI Scanner Modal */}
      <ImeiScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleScannedCode}
        title={
          scannerTarget === 'search'
            ? 'Scan Box Barcode to Lookup Handset'
            : scannerTarget === 'formImei1'
            ? 'Scan Phone Primary IMEI 1'
            : 'Scan Phone Secondary IMEI 2'
        }
      />
    </div>
  );
};
