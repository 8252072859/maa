import React, { useState } from 'react';
import {
  Repeat,
  Plus,
  Search,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Coins
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { ExchangeRecord } from '../../types/erp';
import { formatCurrency, formatDate, getTodayDateString, exportToCSV } from '../../utils/formatters';

export const ExchangeManagement: React.FC = () => {
  const { exchangeRecords, recordExchange } = useERP();
  const { t } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [oldBrand, setOldBrand] = useState('Samsung');
  const [oldModel, setOldModel] = useState('');
  const [oldImei, setOldImei] = useState('');
  const [condition, setCondition] = useState<ExchangeRecord['condition']>('Good');
  const [estimatedValue, setEstimatedValue] = useState<number>(0);
  const [exchangeBonus, setExchangeBonus] = useState<number>(500);
  const [newBillInvoiceNumber, setNewBillInvoiceNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const totalExchangePayable = estimatedValue + exchangeBonus;

  const filteredExchanges = exchangeRecords.filter(
    (e) =>
      e.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.oldModel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.oldImei.includes(searchTerm) ||
      e.oldBrand.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalExchangedValue = exchangeRecords.reduce((sum, e) => sum + e.totalExchangeValue, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !oldModel.trim() || estimatedValue <= 0) {
      setErrorMsg('Customer name, phone model, and estimated value are required.');
      return;
    }

    try {
      await recordExchange({
        date: getTodayDateString(),
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        oldBrand: oldBrand.trim(),
        oldModel: oldModel.trim(),
        oldImei: oldImei.trim(),
        condition,
        estimatedValue,
        exchangeBonus,
        totalExchangeValue: totalExchangePayable,
        newBillInvoiceNumber: newBillInvoiceNumber.trim() || undefined,
        notes: notes.trim() || undefined
      });

      setIsModalOpen(false);
      setCustomerName('');
      setCustomerPhone('');
      setOldModel('');
      setOldImei('');
      setEstimatedValue(0);
      setExchangeBonus(500);
      setNewBillInvoiceNumber('');
      setNotes('');
      setErrorMsg(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to record exchange.');
    }
  };

  const handleExportCSV = () => {
    const rows = exchangeRecords.map((e) => ({
      'Date': e.date,
      'Customer': e.customerName,
      'Phone': e.customerPhone,
      'Old Phone': `${e.oldBrand} ${e.oldModel}`,
      'Old IMEI': e.oldImei,
      'Condition': e.condition,
      'Estimated Value': e.estimatedValue,
      'Exchange Bonus': e.exchangeBonus,
      'Total Exchange Value': e.totalExchangeValue,
      'New Bill #': e.newBillInvoiceNumber || ''
    }));
    exportToCSV('MaaDurga_Exchange_History', rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Repeat className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('exchange')} & USED MOBILE MANAGEMENT
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Exchange old smartphones, give exchange bonus & auto-add to Used Mobile Stock for resale.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>New Exchange Entry</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Mobiles Exchanged</span>
          <div className="text-xl sm:text-2xl font-black text-slate-100 font-mono-code mt-1">
            {exchangeRecords.length} Handsets
          </div>
          <span className="text-[10px] text-slate-500">Customer Trade-ins</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Exchange Valuation</span>
          <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono-code mt-1">
            {formatCurrency(totalExchangedValue)}
          </div>
          <span className="text-[10px] text-slate-500">Credit Adjusted in New Sales</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Inventory Status</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono-code mt-1">
            Auto-Cataloged
          </div>
          <span className="text-[10px] text-slate-500">Added into Used Stock</span>
        </div>
      </div>

      {/* Search Toolbar */}
      <div className="flex items-center justify-between gap-3 p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search exchanges by Customer, Old Brand, Model or IMEI..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        </div>

        <button
          onClick={handleExportCSV}
          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition"
        >
          Export CSV
        </button>
      </div>

      {/* Exchange List Table */}
      <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
        {filteredExchanges.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No exchange records found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Customer Name & Phone</th>
                  <th className="p-3.5">Exchanged Mobile Model</th>
                  <th className="p-3.5">Old IMEI</th>
                  <th className="p-3.5 text-center">Condition</th>
                  <th className="p-3.5 text-right">Estimated Value</th>
                  <th className="p-3.5 text-right">Exchange Bonus</th>
                  <th className="p-3.5 text-right">Total Exchange Credit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-code">
                {filteredExchanges.map((ex) => (
                  <tr key={ex.id} className="hover:bg-slate-800/30">
                    <td className="p-3.5 text-slate-400 font-sans">
                      {formatDate(ex.date)}
                    </td>

                    <td className="p-3.5 font-sans">
                      <div className="font-bold text-slate-100">{ex.customerName}</div>
                      <div className="text-[11px] text-slate-400 font-mono-code">{ex.customerPhone}</div>
                    </td>

                    <td className="p-3.5 font-sans">
                      <span className="font-bold text-slate-200">
                        {ex.oldBrand} {ex.oldModel}
                      </span>
                    </td>

                    <td className="p-3.5 text-amber-300">
                      {ex.oldImei || 'N/A'}
                    </td>

                    <td className="p-3.5 text-center font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        ex.condition === 'Flawless'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : ex.condition === 'Good'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {ex.condition}
                      </span>
                    </td>

                    <td className="p-3.5 text-right text-slate-300">
                      {formatCurrency(ex.estimatedValue)}
                    </td>

                    <td className="p-3.5 text-right text-emerald-400">
                      + {formatCurrency(ex.exchangeBonus)}
                    </td>

                    <td className="p-3.5 text-right font-bold text-amber-300">
                      {formatCurrency(ex.totalExchangeValue)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* NEW EXCHANGE MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100 font-royal">
                Evaluate & Exchange Old Mobile
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            {errorMsg && (
              <div className="mx-6 mt-4 p-3 rounded-xl bg-red-950/70 border border-red-500 text-red-200 text-xs">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="p-6 space-y-3.5 text-xs overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Customer Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sunil Tiwari"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="9876543210"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Old Mobile Brand *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Apple, Vivo, Samsung"
                    value={oldBrand}
                    onChange={(e) => setOldBrand(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Old Mobile Model *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. iPhone 12 (64GB)"
                    value={oldModel}
                    onChange={(e) => setOldModel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Old Handset IMEI</label>
                  <input
                    type="text"
                    placeholder="15-digit IMEI"
                    value={oldImei}
                    onChange={(e) => setOldImei(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Device Physical Condition</label>
                  <select
                    value={condition}
                    onChange={(e) => setCondition(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  >
                    <option value="Flawless">Flawless (No scratches, 100% working)</option>
                    <option value="Good">Good (Minor scratches, all parts working)</option>
                    <option value="Average">Average (Wear & tear, weak battery)</option>
                    <option value="Damaged">Damaged / Broken Screen</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Estimated Value (₹) *</label>
                  <input
                    type="number"
                    value={estimatedValue}
                    onChange={(e) => setEstimatedValue(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Exchange Bonus (₹)</label>
                  <input
                    type="number"
                    value={exchangeBonus}
                    onChange={(e) => setExchangeBonus(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1 font-mono-code">
                <div className="flex justify-between text-slate-400">
                  <span>Total Exchange Credit to Customer:</span>
                  <span className="text-amber-300 font-bold text-sm">{formatCurrency(totalExchangePayable)}</span>
                </div>
                <div className="text-[10px] text-slate-500 font-sans">
                  * A Used Mobile Stock item will be automatically created in inventory for resale.
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Record Exchange & Create Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
