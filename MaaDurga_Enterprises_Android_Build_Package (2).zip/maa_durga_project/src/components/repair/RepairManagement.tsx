import React, { useState } from 'react';
import {
  Wrench,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  Printer,
  Share2,
  AlertCircle,
  FileSpreadsheet,
  Smartphone,
  UserCheck
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { RepairJob, RepairStatus } from '../../types/erp';
import { formatCurrency, formatDate, getTodayDateString, buildWhatsAppBillUrl, exportToCSV } from '../../utils/formatters';

export const RepairManagement: React.FC = () => {
  const { repairJobs, createRepairJob, updateRepairJobStatus, payRepairRemaining, settings } = useERP();
  const { t } = useLanguage();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedJobForPrint, setSelectedJobForPrint] = useState<RepairJob | null>(null);

  // New Job Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [mobileModel, setMobileModel] = useState('');
  const [imeiOrSerial, setImeiOrSerial] = useState('');
  const [lockPattern, setLockPattern] = useState('');
  const [selectedProblems, setSelectedProblems] = useState<string[]>([]);
  const [customProblem, setCustomProblem] = useState('');
  const [repairCharges, setRepairCharges] = useState<number>(0);
  const [advancePaid, setAdvancePaid] = useState<number>(0);
  const [technicianName, setTechnicianName] = useState('Sonu Technician');
  const [estDeliveryDate, setEstDeliveryDate] = useState(getTodayDateString());
  const [warrantyDays, setWarrantyDays] = useState<number>(30);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Deliver Job Modal
  const [jobToDeliver, setJobToDeliver] = useState<RepairJob | null>(null);
  const [deliveryCollectedAmount, setDeliveryCollectedAmount] = useState<number>(0);

  const commonProblems = [
    'Screen / Touch Cracked',
    'Charging Jack / Port',
    'Battery Drain / Swollen',
    'Speaker / Mic Low Voice',
    'Camera Blurry / Broken',
    'Water Damaged',
    'Dead / Not Turning On',
    'Software / Pattern Unlock'
  ];

  const toggleProblem = (p: string) => {
    if (selectedProblems.includes(p)) {
      setSelectedProblems(selectedProblems.filter((item) => item !== p));
    } else {
      setSelectedProblems([...selectedProblems, p]);
    }
  };

  const filteredJobs = repairJobs.filter((job) => {
    const matchesSearch =
      job.jobTicketNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.customerPhone.includes(searchTerm) ||
      job.mobileModel.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || job.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const remainingDue = Math.max(0, repairCharges - advancePaid);

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !mobileModel.trim() || repairCharges <= 0) {
      setErrorMsg('Customer Name, Mobile Model, and Repair Charges are required.');
      return;
    }

    const allProblems = [...selectedProblems];
    if (customProblem.trim()) allProblems.push(customProblem.trim());

    if (allProblems.length === 0) {
      setErrorMsg('Please select or specify at least one problem.');
      return;
    }

    try {
      await createRepairJob({
        jobTicketNo: `REP-2026-${String(repairJobs.length + 1).padStart(3, '0')}`,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        mobileModel: mobileModel.trim(),
        imeiOrSerial: imeiOrSerial.trim() || undefined,
        securityLockPattern: lockPattern.trim() || undefined,
        problems: allProblems,
        repairCharges,
        advancePaid,
        remainingAmount: remainingDue,
        technicianName: technicianName.trim(),
        receivedDate: getTodayDateString(),
        estimatedDeliveryDate: estDeliveryDate,
        status: 'Received',
        warrantyDays
      });

      setIsModalOpen(false);
      setCustomerName('');
      setCustomerPhone('');
      setMobileModel('');
      setImeiOrSerial('');
      setSelectedProblems([]);
      setCustomProblem('');
      setRepairCharges(0);
      setAdvancePaid(0);
      setErrorMsg(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create job ticket.');
    }
  };

  const handleConfirmDeliver = async () => {
    if (!jobToDeliver) return;
    if (deliveryCollectedAmount > 0) {
      await payRepairRemaining(jobToDeliver.id, deliveryCollectedAmount);
    }
    await updateRepairJobStatus(jobToDeliver.id, 'Delivered', getTodayDateString());
    setJobToDeliver(null);
  };

  const handleExportCSV = () => {
    const rows = repairJobs.map((r) => ({
      'Ticket No': r.jobTicketNo,
      'Customer': r.customerName,
      'Phone': r.customerPhone,
      'Mobile': r.mobileModel,
      'IMEI/Serial': r.imeiOrSerial || '',
      'Problems': r.problems.join('; '),
      'Charges': r.repairCharges,
      'Advance Paid': r.advancePaid,
      'Remaining Due': r.remainingAmount,
      'Technician': r.technicianName,
      'Status': r.status,
      'Received Date': r.receivedDate,
      'Delivery Date': r.actualDeliveredDate || r.estimatedDeliveryDate
    }));
    exportToCSV('MaaDurga_Repair_Jobs', rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Wrench className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('repairs')} (SERVICE CENTER)
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Job tokens, problem checklists, advance tracking & technician dispatch.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 active:scale-95 transition"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>New Repair Job Ticket</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Repair Jobs</span>
          <div className="text-xl sm:text-2xl font-black text-slate-100 font-mono-code mt-1">
            {repairJobs.length} Handsets
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">In Progress / Pending</span>
          <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono-code mt-1">
            {repairJobs.filter((r) => r.status !== 'Delivered').length} Jobs
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Ready for Delivery</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono-code mt-1">
            {repairJobs.filter((r) => r.status === 'Ready').length} Handsets
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Delivered & Closed</span>
          <div className="text-xl sm:text-2xl font-black text-blue-400 font-mono-code mt-1">
            {repairJobs.filter((r) => r.status === 'Delivered').length} Handsets
          </div>
        </div>
      </div>

      {/* Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            placeholder="Search by Job Ticket #, Customer, Phone or Mobile Model..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-xs focus:outline-none focus:border-amber-400"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-300 text-xs focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Statuses</option>
            <option value="Received">Received</option>
            <option value="In Progress">In Progress</option>
            <option value="Parts Pending">Parts Pending</option>
            <option value="Ready">Ready for Delivery</option>
            <option value="Delivered">Delivered</option>
          </select>

          <button
            onClick={handleExportCSV}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition"
          >
            Export CSV
          </button>
        </div>
      </div>

      {/* Repair Jobs List */}
      <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
        {filteredJobs.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No repair job tickets found. Click 'New Repair Job Ticket' to intake a mobile for service.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5">Ticket #</th>
                  <th className="p-3.5">Customer & Phone</th>
                  <th className="p-3.5">Handset & Problems</th>
                  <th className="p-3.5">Technician</th>
                  <th className="p-3.5 text-right">Charges</th>
                  <th className="p-3.5 text-right">Advance / Due</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-code">
                {filteredJobs.map((job) => (
                  <tr key={job.id} className="hover:bg-slate-800/30">
                    <td className="p-3.5 font-bold text-amber-300">
                      {job.jobTicketNo}
                      <div className="text-[10px] text-slate-500 font-normal font-sans">
                        {formatDate(job.receivedDate)}
                      </div>
                    </td>

                    <td className="p-3.5 font-sans">
                      <div className="font-bold text-slate-100">{job.customerName}</div>
                      <div className="text-[11px] text-slate-400 font-mono-code">{job.customerPhone}</div>
                    </td>

                    <td className="p-3.5 font-sans max-w-xs">
                      <div className="font-semibold text-slate-200">{job.mobileModel}</div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {job.problems.join(', ')}
                      </div>
                    </td>

                    <td className="p-3.5 font-sans text-slate-300">
                      {job.technicianName}
                    </td>

                    <td className="p-3.5 text-right font-bold text-slate-100">
                      {formatCurrency(job.repairCharges)}
                    </td>

                    <td className="p-3.5 text-right">
                      <div className="text-emerald-400 font-bold">
                        Adv: {formatCurrency(job.advancePaid)}
                      </div>
                      {job.remainingAmount > 0 && (
                        <div className="text-red-400 text-[10px]">
                          Due: {formatCurrency(job.remainingAmount)}
                        </div>
                      )}
                    </td>

                    <td className="p-3.5 text-center font-sans">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        job.status === 'Delivered'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                          : job.status === 'Ready'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : job.status === 'In Progress'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}>
                        {job.status}
                      </span>
                    </td>

                    <td className="p-3.5 text-right font-sans">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Status Change Dropdown */}
                        {job.status !== 'Delivered' && (
                          <select
                            value={job.status}
                            onChange={(e) => {
                              const newSt = e.target.value as RepairStatus;
                              if (newSt === 'Delivered') {
                                setJobToDeliver(job);
                                setDeliveryCollectedAmount(job.remainingAmount);
                              } else {
                                updateRepairJobStatus(job.id, newSt);
                              }
                            }}
                            className="px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-[11px] text-slate-200"
                          >
                            <option value="Received">Received</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Parts Pending">Parts Pending</option>
                            <option value="Ready">Ready</option>
                            <option value="Delivered">Deliver</option>
                          </select>
                        )}

                        {/* Print Job Token Receipt */}
                        <button
                          onClick={() => setSelectedJobForPrint(job)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                          title="Print Job Card Token"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* DELIVER MOBILE & COLLECT DUE MODAL */}
      {jobToDeliver && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-blue-500/40 rounded-2xl p-6 shadow-2xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-100 font-royal">
              Deliver Repaired Handset
            </h3>
            <p className="text-slate-400">
              {jobToDeliver.customerName} · {jobToDeliver.mobileModel} ({jobToDeliver.jobTicketNo})
            </p>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">
                Collect Remaining Charges (₹)
              </label>
              <input
                type="number"
                value={deliveryCollectedAmount}
                onChange={(e) => setDeliveryCollectedAmount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code font-bold text-sm focus:outline-none focus:border-blue-400"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setJobToDeliver(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDeliver}
                className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold"
              >
                Confirm Delivery
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REPAIR JOB TOKEN PRINT MODAL */}
      {selectedJobForPrint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-white text-slate-900 rounded-2xl shadow-2xl p-6 font-mono-code text-xs space-y-3">
            <div className="flex justify-between items-start no-print">
              <button
                onClick={() => window.print()}
                className="px-4 py-1.5 bg-amber-500 text-slate-950 font-bold rounded-lg text-xs"
              >
                Print Token
              </button>
              <button
                onClick={() => setSelectedJobForPrint(null)}
                className="text-slate-500 hover:text-black font-bold"
              >
                ✕
              </button>
            </div>

            {/* Printable Content */}
            <div className="printable-bill-wrapper text-center border-b pb-3 border-dashed border-slate-400">
              <div className="text-base font-black font-royal">{settings.shopName}</div>
              <div className="text-[10px] text-slate-600">MOBILE SERVICE & REPAIR CENTER</div>
              <div className="text-[10px]">Ph: {settings.phone}</div>
              <div className="mt-2 text-xs font-bold bg-slate-100 py-1 rounded">
                REPAIR JOB TOKEN #{selectedJobForPrint.jobTicketNo}
              </div>
            </div>

            <div className="space-y-1 text-[11px] border-b pb-3 border-dashed border-slate-400">
              <div>Customer: <span className="font-bold">{selectedJobForPrint.customerName}</span></div>
              <div>Phone: <span className="font-bold">{selectedJobForPrint.customerPhone}</span></div>
              <div>Model: <span className="font-bold">{selectedJobForPrint.mobileModel}</span></div>
              {selectedJobForPrint.imeiOrSerial && <div>IMEI: {selectedJobForPrint.imeiOrSerial}</div>}
              <div>Received: {formatDate(selectedJobForPrint.receivedDate)}</div>
              <div>Estimated Delivery: {formatDate(selectedJobForPrint.estimatedDeliveryDate)}</div>
            </div>

            <div className="border-b pb-3 border-dashed border-slate-400">
              <div className="font-bold text-[11px] mb-1">Reported Problems:</div>
              <ul className="list-disc list-inside text-[10px] text-slate-700">
                {selectedJobForPrint.problems.map((p, i) => (
                  <li key={i}>{p}</li>
                ))}
              </ul>
            </div>

            <div className="space-y-1 text-[11px] border-b pb-3 border-dashed border-slate-400 font-bold">
              <div className="flex justify-between">
                <span>Estimated Charges:</span>
                <span>{formatCurrency(selectedJobForPrint.repairCharges)}</span>
              </div>
              <div className="flex justify-between text-emerald-700">
                <span>Advance Paid:</span>
                <span>{formatCurrency(selectedJobForPrint.advancePaid)}</span>
              </div>
              <div className="flex justify-between text-red-600">
                <span>Remaining Due:</span>
                <span>{formatCurrency(selectedJobForPrint.remainingAmount)}</span>
              </div>
            </div>

            <div className="text-[9px] text-slate-600 leading-tight">
              <p className="font-bold text-slate-800">Repair Terms:</p>
              <p>{settings.repairTerms || "1. Handset must be claimed within 30 days.\n2. Shop is not responsible for data loss."}</p>
            </div>

            <div className="text-center font-bold text-slate-800 pt-2 text-[10px]">
              Customer Copy · Thank you for trusting us!
            </div>
          </div>
        </div>
      )}

      {/* NEW REPAIR JOB MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-amber-500/30 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100 font-royal">
                Intake Mobile for Repairing (Job Sheet)
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            {errorMsg && (
              <div className="mx-6 mt-4 p-3 rounded-xl bg-red-950/70 border border-red-500 text-red-200 text-xs">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleCreateJob} className="p-6 space-y-3.5 text-xs overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Customer Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramesh Sharma"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="9876543210"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/[^0-9]/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mobile Model *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Samsung M33 / Realme 9"
                    value={mobileModel}
                    onChange={(e) => setMobileModel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">IMEI or Serial Number</label>
                  <input
                    type="text"
                    placeholder="Handset IMEI or S/N"
                    value={imeiOrSerial}
                    onChange={(e) => setImeiOrSerial(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>
              </div>

              {/* Problem Checklist */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">
                  Reported Problem Checklist *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {commonProblems.map((prob) => {
                    const isChecked = selectedProblems.includes(prob);
                    return (
                      <button
                        key={prob}
                        type="button"
                        onClick={() => toggleProblem(prob)}
                        className={`py-1.5 px-2.5 rounded-lg border text-left flex items-center justify-between transition ${
                          isChecked
                            ? 'bg-amber-500/20 border-amber-400 text-amber-300 font-semibold'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        <span className="truncate">{prob}</span>
                        {isChecked && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Additional description */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Other Fault / Detailed Description</label>
                <input
                  type="text"
                  placeholder="e.g. Needs display folder + charging board replacement"
                  value={customProblem}
                  onChange={(e) => setCustomProblem(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                />
              </div>

              {/* Pricing, Advance and Technician */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Total Charges (₹) *</label>
                  <input
                    type="number"
                    value={repairCharges}
                    onChange={(e) => setRepairCharges(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Advance Received (₹)</label>
                  <input
                    type="number"
                    value={advancePaid}
                    onChange={(e) => setAdvancePaid(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 font-mono-code"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Technician</label>
                  <input
                    type="text"
                    value={technicianName}
                    onChange={(e) => setTechnicianName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-slate-100"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Create Job Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
