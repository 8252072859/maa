import React from 'react';
import {
  LayoutDashboard,
  Receipt,
  FileText,
  Boxes,
  Truck,
  BookOpen,
  Landmark,
  Repeat,
  Wrench,
  WalletCards,
  BarChart3,
  Settings,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';

interface SidebarProps {
  isOpen: boolean;
  onCloseMobile: () => void;
  onOpenSettings: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onCloseMobile,
  onOpenSettings
}) => {
  const { activeTab, setActiveTab, products, repairJobs, customers } = useERP();
  const { t } = useLanguage();

  // Badges calculation
  const lowStockCount = products.filter(p => p.currentStock <= p.minStockAlert).length;
  const pendingRepairsCount = repairJobs.filter(r => r.status !== 'Delivered').length;
  const customersWithUdhaarCount = customers.filter(c => c.currentUdhaar > 0).length;

  const menuItems = [
    {
      id: 'dashboard',
      label: t('dashboard'),
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'new-bill',
      label: t('newBill'),
      icon: Receipt,
      highlight: true
    },
    {
      id: 'bills-history',
      label: t('billsHistory'),
      icon: FileText,
      badge: null
    },
    {
      id: 'stock',
      label: t('stock'),
      icon: Boxes,
      badge: lowStockCount > 0 ? `${lowStockCount} Low` : null,
      badgeColor: 'bg-red-500/10 text-red-400 border border-red-500/30'
    },
    {
      id: 'purchases',
      label: t('purchases'),
      icon: Truck,
      badge: null
    },
    {
      id: 'udhaar',
      label: t('udhaarKhata'),
      icon: BookOpen,
      badge: customersWithUdhaarCount > 0 ? `${customersWithUdhaarCount}` : null,
      badgeColor: 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
    },
    {
      id: 'emi',
      label: t('emiFinance'),
      icon: Landmark,
      badge: null
    },
    {
      id: 'exchange',
      label: t('exchange'),
      icon: Repeat,
      badge: null
    },
    {
      id: 'repairs',
      label: t('repairs'),
      icon: Wrench,
      badge: pendingRepairsCount > 0 ? `${pendingRepairsCount}` : null,
      badgeColor: 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
    },
    {
      id: 'expenses',
      label: t('expenses'),
      icon: WalletCards,
      badge: null
    },
    {
      id: 'reports',
      label: t('reports'),
      icon: BarChart3,
      badge: null
    }
  ];

  const handleSelectTab = (tabId: string) => {
    setActiveTab(tabId);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 lg:top-16 z-40 h-full lg:h-[calc(100vh-4rem)] w-64 bg-[#0a0f1d] border-r border-amber-500/15 flex flex-col justify-between transition-transform duration-200 ease-in-out no-print ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-bold text-amber-400/80 uppercase tracking-widest font-royal">
            MAIN NAVIGATION
          </div>

          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-900/60 to-slate-900 text-amber-300 border border-amber-500/40 shadow-sm'
                    : item.highlight
                    ? 'bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 border border-amber-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                      isActive
                        ? 'bg-amber-500/20 text-amber-400'
                        : item.highlight
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer Settings Button */}
        <div className="p-3 border-t border-slate-800/80 bg-slate-950/40">
          <button
            onClick={() => {
              onOpenSettings();
              onCloseMobile();
            }}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/70 border border-slate-800 transition ${
              activeTab === 'settings' ? 'border-amber-500/40 text-amber-300' : ''
            }`}
          >
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400">
                <Settings className="w-4 h-4" />
              </div>
              <span>{t('settings')}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>
        </div>
      </aside>
    </>
  );
};
