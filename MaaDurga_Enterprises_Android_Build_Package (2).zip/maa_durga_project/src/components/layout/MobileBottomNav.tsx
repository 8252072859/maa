import React from 'react';
import { 
  LayoutDashboard, 
  Receipt, 
  Boxes, 
  BookOpen, 
  Smartphone,
  Menu,
  Download,
  Sparkles
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { sounds } from '../../utils/soundEffects';

interface MobileBottomNavProps {
  onOpenMobileMenu: () => void;
  onOpenApkModal: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  onOpenMobileMenu,
  onOpenApkModal
}) => {
  const { activeTab, setActiveTab, products, customers } = useERP();
  const { t } = useLanguage();

  const lowStockCount = products.filter(p => p.currentStock <= p.minStockAlert).length;
  const customersWithUdhaarCount = customers.filter(c => c.currentUdhaar > 0).length;

  const handleTabChange = (tabId: any) => {
    sounds.playTap();
    setActiveTab(tabId);
  };

  return (
    <nav 
      aria-label="Mobile Bottom Navigation"
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#070b14]/95 backdrop-blur-xl border-t border-amber-500/30 px-2 py-1.5 shadow-[0_-10px_25px_-5px_rgba(0,0,0,0.8)] no-print pb-safe"
    >
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {/* Dashboard */}
        <button
          onClick={() => handleTabChange('dashboard')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition ${
            activeTab === 'dashboard'
              ? 'text-amber-400 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <LayoutDashboard className={`w-5 h-5 ${activeTab === 'dashboard' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          </div>
          <span className="text-[10px] mt-1 tracking-tight">Dashboard</span>
        </button>

        {/* Stock Inventory */}
        <button
          onClick={() => handleTabChange('stock')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition relative ${
            activeTab === 'stock'
              ? 'text-amber-400 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <Boxes className={`w-5 h-5 ${activeTab === 'stock' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            {lowStockCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1 py-0.2 bg-red-500 text-white text-[9px] font-black rounded-full leading-none">
                {lowStockCount}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-1 tracking-tight">Stock</span>
        </button>

        {/* Center: BIG NEW BILL / POS BUTTON */}
        <button
          onClick={() => handleTabChange('new-bill')}
          className="relative -top-4 flex flex-col items-center group active:scale-90 transition"
          aria-label="Create New Bill"
        >
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-300 p-[2px] shadow-lg shadow-amber-500/40 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#0a0f1d] group-hover:bg-amber-500 rounded-[14px] flex items-center justify-center transition-colors">
              <Receipt className="w-6 h-6 text-amber-400 group-hover:text-slate-950 transition-colors stroke-[2.5]" />
            </div>
          </div>
          <span className="text-[10px] font-black text-amber-400 mt-1 uppercase tracking-wider">
            + New Bill
          </span>
        </button>

        {/* Khata / Udhaar */}
        <button
          onClick={() => handleTabChange('udhaar')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition relative ${
            activeTab === 'udhaar'
              ? 'text-amber-400 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <BookOpen className={`w-5 h-5 ${activeTab === 'udhaar' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            {customersWithUdhaarCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1 py-0.2 bg-amber-500 text-slate-950 text-[9px] font-black rounded-full leading-none">
                {customersWithUdhaarCount}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-1 tracking-tight">Khata</span>
        </button>

        {/* APK / Mobile App Install Center */}
        <button
          onClick={() => {
            sounds.playScanBeep();
            onOpenApkModal();
          }}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-xl text-emerald-400 hover:text-emerald-300 transition"
        >
          <div className="relative flex items-center justify-center w-5 h-5">
            <Smartphone className="w-5 h-5 text-emerald-400 stroke-2" />
            <span className="absolute -top-1 -right-2 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>
          <span className="text-[10px] mt-1 font-bold tracking-tight text-emerald-300">App APK</span>
        </button>

        {/* More / Menu Drawer */}
        <button
          onClick={() => {
            sounds.playTap();
            onOpenMobileMenu();
          }}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-xl text-slate-400 hover:text-white transition"
          aria-label="Open Full Menu"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] mt-1 tracking-tight">Menu</span>
        </button>
      </div>
    </nav>
  );
};
