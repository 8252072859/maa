import React, { useState, useEffect } from 'react';
import { 
  PlusCircle, 
  Lock, 
  Languages, 
  Menu, 
  X, 
  ShieldCheck, 
  Clock, 
  Sparkles,
  Smartphone,
  LogOut,
  Download
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { ApkInstallModal } from '../common/ApkInstallModal';

interface NavbarProps {
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleSidebar,
  isSidebarOpen,
  onOpenSettings
}) => {
  const { settings, setActiveTab, setIsLocked } = useERP();
  const { language, setLanguage, t } = useLanguage();
  const { logout, adminUser } = useAuth();
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
      setDateStr(now.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Keyboard shortcut listener (F2 -> New Bill)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        setActiveTab('new-bill');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setActiveTab]);

  return (
    <header className="sticky top-0 z-30 h-16 bg-[#070b14]/90 backdrop-blur-md border-b border-amber-500/20 px-3 sm:px-6 flex items-center justify-between no-print">
      {/* Left: Brand & Logo */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800 transition"
          aria-label="Toggle Menu"
        >
          {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        {/* Heraldic Crown / Trishul Logo */}
        <div 
          onClick={() => setActiveTab('dashboard')} 
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 via-amber-400 to-amber-200 p-[1.5px] shadow-lg shadow-amber-500/20">
            <div className="w-full h-full bg-[#0a0f1d] rounded-[10px] flex items-center justify-center">
              <span className="text-amber-400 font-royal font-black text-lg select-none group-hover:scale-110 transition-transform">
                🔱
              </span>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm sm:text-base font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-amber-100 tracking-wider font-royal">
                {settings.shopName || "MAA DURGA ENTERPRISES"}
              </h1>
              <span className="hidden sm:inline-block px-1.5 py-0.2 text-[9px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded uppercase tracking-wider">
                Showroom ERP
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium hidden md:block">
              {settings.shopTagline || "Mobile Showroom Billing & Inventory ERP"}
            </p>
          </div>
        </div>
      </div>

      {/* Middle: Live Clock (Desktop) */}
      <div className="hidden xl:flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs text-slate-400 font-mono-code">
        <Clock className="w-3.5 h-3.5 text-amber-400" />
        <span>{dateStr}</span>
        <span className="text-slate-600">|</span>
        <span className="text-amber-300 font-semibold">{timeStr}</span>
      </div>

      {/* Right: Quick Bill CTA, Language, Lock, Settings & Logout */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* BIG NEW BILL BUTTON (F2) */}
        <button
          onClick={() => setActiveTab('new-bill')}
          className="relative inline-flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 text-slate-950 hover:brightness-110 shadow-lg shadow-amber-500/25 active:scale-95 transition"
        >
          <PlusCircle className="w-4 h-4 stroke-[2.5]" />
          <span>{t('newBill')}</span>
        </button>

        {/* Language Toggle */}
        <button
          onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-amber-400/50 text-slate-300 hover:text-white text-xs font-semibold transition"
          title="Change Language"
        >
          <Languages className="w-3.5 h-3.5 text-amber-400" />
          <span className="uppercase text-[11px]">{language === 'hi' ? 'ENG' : 'हिंदी'}</span>
        </button>

        {/* INSTALL ANDROID APK / APP BUTTON */}
        <button
          onClick={() => setIsApkModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600/30 to-blue-600/30 border border-emerald-500/40 text-emerald-300 hover:text-white text-xs font-bold transition shadow-sm"
          title="Install Android App / Download APK"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Install APK / App</span>
          <span className="sm:hidden">APK</span>
        </button>

        {/* Lock Screen Button */}
        <button
          onClick={() => setIsLocked(true)}
          className="p-2 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-amber-400/50 text-slate-300 hover:text-amber-400 text-xs transition"
          title="Lock POS Terminal"
        >
          <Lock className="w-4 h-4" />
        </button>

        {/* Admin Phone Badge */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-blue-950/60 border border-blue-500/30 text-xs text-blue-300">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-mono-code text-[11px] font-bold">
            {adminUser?.phone || '+91 8252072859'}
          </span>
        </div>

        {/* Logout Button */}
        <button
          onClick={() => logout()}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 hover:text-red-200 text-xs font-semibold transition"
          title="Logout from ERP"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Logout</span>
        </button>
      </div>

      {/* APK Installation Modal */}
      <ApkInstallModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />
    </header>
  );
};
