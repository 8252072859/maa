import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Coins,
  FileSpreadsheet,
  Calendar,
  CreditCard,
  Smartphone,
  ArrowUpRight,
  PieChart
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { useLanguage } from '../../context/LanguageContext';
import { formatCurrency, formatDate, exportToCSV } from '../../utils/formatters';

export const ReportsAnalytics: React.FC = () => {
  const { invoices, products, purchases, expenses, customers, emiRecords } = useERP();
  const { t } = useLanguage();

  const [dateRange, setDateRange] = useState<'all' | 'today' | 'this_month'>('all');

  // Filter invoices by range
  const todayStr = new Date().toISOString().slice(0, 10);
  const currentMonthPrefix = todayStr.slice(0, 7); // YYYY-MM

  const activeInvoices = invoices.filter((inv) => {
    if (inv.isCancelled) return false;
    if (dateRange === 'today') return inv.date === todayStr;
    if (dateRange === 'this_month') return inv.date.startsWith(currentMonthPrefix);
    return true;
  });

  const rangeExpenses = expenses.filter((exp) => {
    if (dateRange === 'today') return exp.date === todayStr;
    if (dateRange === 'this_month') return exp.date.startsWith(currentMonthPrefix);
    return true;
  });

  // Financial Computations
  const totalGrossSales = activeInvoices.reduce((sum, inv) => sum + inv.grandTotal, 0);

  // Exact Cost of Goods Sold (COGS)
  let totalCOGS = 0;
  activeInvoices.forEach((inv) => {
    inv.items.forEach((item) => {
      totalCOGS += (item.purchasePrice || 0) * item.quantity;
    });
  });

  const grossProfit = Math.max(0, totalGrossSales - totalCOGS);
  const totalExpensesSum = rangeExpenses.reduce((sum, exp) => sum + exp.amount, 0);
  const netProfit = Math.max(0, grossProfit - totalExpensesSum);

  // Total Tax Collected
  const totalCgst = activeInvoices.reduce((sum, inv) => sum + (inv.cgst || 0), 0);
  const totalSgst = activeInvoices.reduce((sum, inv) => sum + (inv.sgst || 0), 0);
  const totalTaxCollected = totalCgst + totalSgst;

  // Payment Breakdown
  const paymentBreakdown = {
    cash: 0,
    upi: 0,
    card: 0,
    bank: 0,
    udhar: 0
  };

  activeInvoices.forEach((inv) => {
    if (inv.paymentMode in paymentBreakdown) {
      paymentBreakdown[inv.paymentMode as keyof typeof paymentBreakdown] += inv.grandTotal;
    }
  });

  // Best Selling Products calculation
  const productSalesMap: Record<string, { name: string; brand: string; qty: number; revenue: number; profit: number }> = {};

  activeInvoices.forEach((inv) => {
    inv.items.forEach((item) => {
      const key = `${item.brand} ${item.productName}`;
      if (!productSalesMap[key]) {
        productSalesMap[key] = {
          name: item.productName,
          brand: item.brand,
          qty: 0,
          revenue: 0,
          profit: 0
        };
      }
      productSalesMap[key].qty += item.quantity;
      productSalesMap[key].revenue += item.amount;
      productSalesMap[key].profit += (item.amount - ((item.purchasePrice || 0) * item.quantity));
    });
  });

  const topSellingProducts = Object.values(productSalesMap).sort((a, b) => b.revenue - a.revenue);

  const handleExportFullSalesReport = () => {
    const rows = activeInvoices.map((inv) => ({
      'Invoice No': inv.invoiceNumber,
      'Date': inv.date,
      'Time': inv.time,
      'Customer': inv.customerName,
      'Phone': inv.customerPhone,
      'Subtotal': inv.subtotal,
      'CGST': inv.cgst,
      'SGST': inv.sgst,
      'Grand Total': inv.grandTotal,
      'Paid Amount': inv.paidAmount,
      'Due Balance': inv.dueAmount,
      'Payment Mode': inv.paymentMode
    }));
    exportToCSV(`MaaDurga_Financial_Sales_${dateRange}`, rows);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-[#0d1322] border border-amber-500/25 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-royal tracking-wide">
              {t('reports')} & BUSINESS ANALYTICS
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Realized gross profit, net earnings after overheads, payment collections & tax reports.
          </p>
        </div>

        {/* Date Filter & Export */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setDateRange('today')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                dateRange === 'today' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Today
            </button>
            <button
              onClick={() => setDateRange('this_month')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                dateRange === 'this_month' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              This Month
            </button>
            <button
              onClick={() => setDateRange('all')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                dateRange === 'all' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Time
            </button>
          </div>

          <button
            onClick={handleExportFullSalesReport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Export Excel</span>
          </button>
        </div>
      </div>

      {/* 4 Financial Performance Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Total Sales Turnover</span>
          <div className="text-xl sm:text-2xl font-black text-slate-100 font-mono-code mt-1">
            {formatCurrency(totalGrossSales)}
          </div>
          <span className="text-[10px] text-slate-500">{activeInvoices.length} Bills Processed</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Gross Margin (Sales - Cost)</span>
          <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono-code mt-1">
            {formatCurrency(grossProfit)}
          </div>
          <span className="text-[10px] text-slate-500">
            {totalGrossSales > 0 ? `${Math.round((grossProfit / totalGrossSales) * 100)}% Gross Margin` : '0%'}
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Shop Overheads (Expenses)</span>
          <div className="text-xl sm:text-2xl font-black text-rose-400 font-mono-code mt-1">
            - {formatCurrency(totalExpensesSum)}
          </div>
          <span className="text-[10px] text-slate-500">Rent, Salary, Electric, Spares</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#0d1322] border border-emerald-500/30 bg-emerald-500/5">
          <span className="text-[11px] font-semibold text-emerald-300">Net Profit in Pocket</span>
          <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono-code mt-1">
            {formatCurrency(netProfit)}
          </div>
          <span className="text-[10px] text-slate-400">True Realized Earning</span>
        </div>
      </div>

      {/* Payment Modes & Tax Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Payment Inflow Breakdown */}
        <div className="p-5 rounded-2xl bg-[#0d1322] border border-slate-800 space-y-4 shadow-sm">
          <div className="flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-bold text-slate-100">
              Payment Inflow Breakdown
            </h3>
          </div>

          <div className="space-y-2.5 font-mono-code text-xs">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-300 font-sans font-semibold">Cash (Counter Cash)</span>
              <span className="text-emerald-400 font-bold">{formatCurrency(paymentBreakdown.cash)}</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-300 font-sans font-semibold">UPI (PhonePe / GPay / Paytm)</span>
              <span className="text-blue-400 font-bold">{formatCurrency(paymentBreakdown.upi)}</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-300 font-sans font-semibold">Debit & Credit Cards</span>
              <span className="text-slate-200 font-bold">{formatCurrency(paymentBreakdown.card)}</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-300 font-sans font-semibold">Bank / NEFT / RTGS</span>
              <span className="text-slate-200 font-bold">{formatCurrency(paymentBreakdown.bank)}</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-300 font-sans font-semibold">Pending Udhaar (Credit)</span>
              <span className="text-red-400 font-bold">{formatCurrency(paymentBreakdown.udhar)}</span>
            </div>
          </div>
        </div>

        {/* GST Tax Breakdown */}
        <div className="p-5 rounded-2xl bg-[#0d1322] border border-slate-800 space-y-4 shadow-sm">
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-slate-100">
              GST Tax Ledger (HSN 8517)
            </h3>
          </div>

          <div className="space-y-3 font-mono-code text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400 font-sans">Central GST (CGST @ 9%):</span>
              <span className="text-slate-100 font-bold">{formatCurrency(totalCgst)}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
              <span className="text-slate-400 font-sans">State GST (SGST @ 9%):</span>
              <span className="text-slate-100 font-bold">{formatCurrency(totalSgst)}</span>
            </div>

            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex justify-between items-baseline text-sm">
              <span className="text-amber-300 font-sans font-bold">Total GST Collected:</span>
              <span className="text-amber-400 font-black text-base">{formatCurrency(totalTaxCollected)}</span>
            </div>

            <p className="text-[11px] text-slate-500 font-sans leading-relaxed">
              * Ready for GSTR-1 and GSTR-3B monthly tax filing. Export full Excel sheet for your Chartered Accountant.
            </p>
          </div>
        </div>
      </div>

      {/* Top Best-Selling Products Table */}
      <div className="rounded-2xl bg-[#0d1322] border border-slate-800 overflow-hidden shadow-sm">
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-slate-100">
              Top Selling Handsets & Accessories
            </h3>
          </div>
          <span className="text-[11px] text-slate-500">Sorted by revenue contribution</span>
        </div>

        {topSellingProducts.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs">
            No sales records in this date range.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-950/80 border-b border-slate-800 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5">#</th>
                  <th className="p-3.5">Product Name</th>
                  <th className="p-3.5">Brand</th>
                  <th className="p-3.5 text-center">Units Sold</th>
                  <th className="p-3.5 text-right">Total Revenue</th>
                  <th className="p-3.5 text-right">Total Profit Realized</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono-code">
                {topSellingProducts.map((p, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30">
                    <td className="p-3.5 text-slate-500">{idx + 1}</td>
                    <td className="p-3.5 font-sans font-bold text-slate-100">{p.name}</td>
                    <td className="p-3.5 font-sans text-amber-300 font-semibold">{p.brand}</td>
                    <td className="p-3.5 text-center text-slate-200">{p.qty} pcs</td>
                    <td className="p-3.5 text-right font-bold text-slate-100">{formatCurrency(p.revenue)}</td>
                    <td className="p-3.5 text-right font-black text-emerald-400">+{formatCurrency(p.profit)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
