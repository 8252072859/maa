export type ProductCategory = 
  | 'smartphone' 
  | 'feature_phone' 
  | 'used_phone' 
  | 'exchanged_phone' 
  | 'tablet' 
  | 'smartwatch' 
  | 'audio' 
  | 'charger_cable' 
  | 'accessories';

export interface Product {
  id: string;
  name: string;
  brand: string;
  model: string;
  ram?: string;
  storage?: string;
  color?: string;
  imeiList: string[]; // List of unique IMEIs available in stock
  serialNumber?: string;
  category: ProductCategory;
  purchasePrice: number;
  sellingPrice: number;
  currentStock: number;
  minStockAlert: number;
  isUsed?: boolean;
  isExchange?: boolean;
  warrantyMonths: number;
  image?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BillItem {
  productId: string;
  productName: string;
  brand: string;
  model: string;
  ramStorage?: string;
  color?: string;
  imei1?: string;
  imei2?: string;
  serialNumber?: string;
  quantity: number;
  rate: number;
  discount: number; // in Rupees
  amount: number; // (rate * qty) - discount
  purchasePrice: number; // for exact profit calculation
  gstRate: number; // e.g. 18% or 0%
  category?: ProductCategory;
}

export type PaymentMode = 'cash' | 'upi' | 'card' | 'bank' | 'udhar' | 'split';

export interface Invoice {
  id: string;
  invoiceNumber: string; // e.g. MDE-2026-0001
  date: string; // YYYY-MM-DD
  time: string; // HH:MM AM/PM
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  items: BillItem[];
  subtotal: number;
  gstType: 'gst' | 'non_gst';
  gstRate: number; // usually 18
  cgst: number;
  sgst: number;
  igst: number;
  totalDiscount: number;
  roundOff: number;
  grandTotal: number;
  paymentMode: PaymentMode;
  splitDetails?: {
    cashAmount?: number;
    upiAmount?: number;
    cardAmount?: number;
    udharAmount?: number;
  };
  paidAmount: number;
  dueAmount: number; // added to customer udhaar khata
  notes?: string;
  isCancelled?: boolean;
  cancelReason?: string;
  createdBy: string;
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address?: string;
  totalPurchases: number;
  totalPaid: number;
  currentUdhaar: number;
  createdAt: string;
  lastPurchaseDate?: string;
  notes?: string;
}

export interface CustomerPayment {
  id: string;
  customerId: string;
  customerName: string;
  date: string;
  time: string;
  amount: number;
  paymentMode: 'cash' | 'upi' | 'bank' | 'other';
  referenceNo?: string;
  invoiceId?: string;
  notes?: string;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address?: string;
  gstin?: string;
  totalPurchased: number;
  totalPaid: number;
  pendingBalance: number;
  createdAt: string;
}

export interface PurchaseItem {
  productName: string;
  brand: string;
  model: string;
  ram?: string;
  storage?: string;
  color?: string;
  category: ProductCategory;
  imeiList: string[];
  quantity: number;
  purchaseRate: number;
  sellingRateTarget: number;
  amount: number;
}

export interface PurchaseBill {
  id: string;
  purchaseNumber: string; // e.g. PUR-2026-001
  supplierId: string;
  supplierName: string;
  supplierContact?: string;
  supplierInvoiceNumber: string;
  date: string;
  items: PurchaseItem[];
  subtotal: number;
  taxAmount: number;
  grandTotal: number;
  paidAmount: number;
  pendingAmount: number;
  notes?: string;
  createdAt: string;
}

export type FinanceCompany = 
  | 'Bajaj Finserv' 
  | 'TVS Credit' 
  | 'IDFC First Bank' 
  | 'Home Credit' 
  | 'DMI Finance' 
  | 'Shop Self-Finance' 
  | 'Other';

export interface EMIInstallment {
  installmentNumber: number;
  dueDate: string;
  amount: number;
  status: 'pending' | 'paid';
  paidDate?: string;
  paymentMode?: string;
  receiptNumber?: string;
}

export interface EMIRecord {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  financeCompany: FinanceCompany;
  loanAccountNumber?: string;
  mobileModel: string;
  imei: string;
  totalMobilePrice: number;
  downPayment: number;
  financedAmount: number;
  installmentAmount: number;
  totalInstallments: number;
  paidInstallments: number;
  firstEmiDate: string;
  nextDueDate: string;
  status: 'active' | 'completed' | 'overdue';
  installments: EMIInstallment[];
  notes?: string;
  createdAt: string;
}

export interface ExchangeRecord {
  id: string;
  date: string;
  customerName: string;
  customerPhone: string;
  oldBrand: string;
  oldModel: string;
  oldImei: string;
  condition: 'Flawless' | 'Good' | 'Average' | 'Damaged';
  estimatedValue: number;
  exchangeBonus: number;
  totalExchangeValue: number;
  newBillInvoiceNumber?: string;
  usedStockProductId?: string;
  notes?: string;
}

export type RepairStatus = 'Received' | 'In Progress' | 'Parts Pending' | 'Ready' | 'Delivered';

export interface RepairJob {
  id: string;
  jobTicketNo: string; // e.g. REP-2026-001
  customerName: string;
  customerPhone: string;
  mobileModel: string;
  imeiOrSerial?: string;
  securityLockPattern?: string;
  problems: string[];
  problemDescription?: string;
  repairCharges: number;
  advancePaid: number;
  remainingAmount: number;
  technicianName: string;
  receivedDate: string;
  estimatedDeliveryDate: string;
  actualDeliveredDate?: string;
  status: RepairStatus;
  warrantyDays: number;
  partsReplaced?: string;
  notes?: string;
}

export interface Expense {
  id: string;
  date: string;
  category: 
    | 'Shop Rent' 
    | 'Electricity Bill' 
    | 'Staff Salary' 
    | 'Transport & Courier' 
    | 'Repair Spares & Tools' 
    | 'Tea & Refreshment' 
    | 'Marketing & Ads' 
    | 'Other Expenses';
  title: string;
  amount: number;
  paymentMode: 'cash' | 'upi' | 'bank';
  notes?: string;
}

export interface ShopSettings {
  shopName: string;
  shopTagline: string;
  ownerName: string;
  phone: string;
  altPhone?: string;
  email?: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  gstin: string;
  upiId: string; // e.g. maadurga@okaxis or 9876543210@paytm
  invoicePrefix: string; // e.g. MDE-2026-
  nextInvoiceSeq: number;
  invoiceTerms: string;
  repairTerms: string;
  currencySymbol: string;
  defaultGstRate: number;
  pinLockEnabled: boolean;
  pinCode: string;
  userRole: 'admin' | 'staff';
  language: 'hi' | 'en';
  themeMode: 'dark' | 'light';
  autoBackupPrompt: boolean;
}
